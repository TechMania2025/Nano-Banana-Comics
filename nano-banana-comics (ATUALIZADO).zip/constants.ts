


import { AppState, CameraFraming, ArtistStyle, CharacterEmotion, SpeechBalloonType } from './types';

export const INITIAL_APP_STATE: AppState = {
    comicTitle: '',
    displayTitleOnPanel: false,
    artistStyle: '',
    maintainReferenceStyle: false,
    generateInPortuguese: false,
    referenceImages: [],
    textCharacters: [],
    characterDetailsEnabled: false,
    numPages: 1,
    numPanels: 1,
    panelConfigs: [
        { 
            prompt: '',
            framing: 'Automatic',
            contentContext: 'Automatic',
            atmosphere: 'Automatic',
            removeAccessories: false,
            noDialogue: false,
            noOnomatopoeia: false,
            excludedCharacters: [],
            panelSize: 'Automatic',
            extrasCount: 'Automatic',
            detailLevel: 'Automatic',
            characterAngle: 'Automatic',
            scenarioDescription: '',
            objectImages: [],
            characterDialogues: {},
            characterBehaviors: {},
            characterEmotions: {},
            characterBalloons: {},
            extrasBehavior: '',
        },
    ],
    isLoading: false,
    loadingMessage: '',
    output: null,
    error: null,
    currentCreationId: null,
    isColor: false,
    comicStyle: 'Manga',
    genre: 'Action',
    appearanceMemory: {},
    useGlobalScenario: false,
    fillPanelCompletely: false,
};

export const CAMERA_FRAMING_OPTIONS: CameraFraming[] = [
    'Automatic',
    'Extreme Close-up',
    'Close-up',
    'Medium Shot',
    'Full Shot',
    'Wide Shot',
    'Establishing Shot',
    'Dutch Angle',
    'Over-the-Shoulder Shot',
    'Point of View (POV)',
    'Low-Angle Shot',
    'High-Angle Shot',
    'Worm\'s-eye View'
];

export const CAMERA_FRAMING_MAP: { [key in CameraFraming]: string } = {
    'Automatic': 'Automático',
    'Extreme Close-up': 'Close-up Extremo',
    'Close-up': 'Close-up',
    'Medium Shot': 'Plano Médio',
    'Full Shot': 'Plano Americano',
    'Wide Shot': 'Plano Geral',
    'Establishing Shot': 'Plano de Estabelecimento',
    'Dutch Angle': 'Ângulo Holandês',
    'Over-the-Shoulder Shot': 'Plano Sobre o Ombro',
    'Point of View (POV)': 'Ponto de Vista (POV)',
    'Low-Angle Shot': 'Ângulo Baixo',
    'High-Angle Shot': 'Ângulo Alto',
    'Worm\'s-eye View': 'Visão de Verme'
};

export const CHARACTER_EMOTION_OPTIONS: CharacterEmotion[] = [
    'Automatic',
    'Neutral',
    'Happy',
    'Joyful',
    'Sad',
    'Crying',
    'Angry',
    'Furious',
    'Surprised',
    'Shocked',
    'Scared',
    'Terrified',
    'Confused',
    'Determined',
    'Smirking',
    'Shy / Blushing',
    'Arrogant / Smug'
];

export const CHARACTER_EMOTION_MAP: { [key in CharacterEmotion]: string } = {
    'Automatic': 'Automático',
    'Neutral': 'Neutro',
    'Happy': 'Feliz',
    'Joyful': 'Radiante',
    'Sad': 'Triste',
    'Crying': 'Chorando',
    'Angry': 'Irritado',
    'Furious': 'Furioso',
    'Surprised': 'Surpreso',
    'Shocked': 'Chocado',
    'Scared': 'Assustado',
    'Terrified': 'Aterrorizado',
    'Confused': 'Confuso',
    'Determined': 'Determinado',
    'Smirking': 'Com Deboche',
    'Shy / Blushing': 'Tímido / Corado',
    'Arrogant / Smug': 'Arrogante / Presunçoso'
};

export const SPEECH_BALLOON_OPTIONS: SpeechBalloonType[] = [
    'Automatic',
    'Normal',
    'Shout',
    'Whisper',
    'Thought',
    'Electronic',
    'Monstrous',
    'Flashback',
    'Narration Box'
];

export const SPEECH_BALLOON_MAP: { [key in SpeechBalloonType]: string } = {
    'Automatic': 'Automático',
    'Normal': 'Normal',
    'Shout': 'Grito (Pontudo)',
    'Whisper': 'Sussurro (Tracejado)',
    'Thought': 'Pensamento (Nuvem)',
    'Electronic': 'Eletrônico (Quadrado)',
    'Monstrous': 'Monstruoso (Irregular)',
    'Flashback': 'Flashback (Ondulado)',
    'Narration Box': 'Caixa de Narração'
};


export const GENRE_OPTIONS: string[] = [
    'Action',
    'Adventure',
    'Comedy',
    'Drama',
    'Fantasy',
    'Horror',
    'Mahou Shoujo',
    'Martial Arts',
    'Mecha',
    'Music',
    'Mystery',
    'Psychological',
    'Romance',
    'Sci-Fi',
    'Slice of Life',
    'Sports',
    'Superhero',
    'Thriller',
];

export const GENRE_MAP: { [key: string]: string } = {
    'Action': 'Ação',
    'Adventure': 'Aventura',
    'Comedy': 'Comédia',
    'Drama': 'Drama',
    'Fantasy': 'Fantasia',
    'Horror': 'Terror',
    'Mahou Shoujo': 'Mahou Shoujo',
    'Martial Arts': 'Artes Marciais',
    'Mecha': 'Mecha',
    'Music': 'Musical',
    'Mystery': 'Mistério',
    'Psychological': 'Psicológico',
    'Romance': 'Romance',
    'Sci-Fi': 'Ficção Científica',
    'Slice of Life': 'Slice of Life',
    'Sports': 'Esportes',
    'Superhero': 'Super-herói',
    'Thriller': 'Suspense',
};


export const ARTIST_STYLES: ArtistStyle[] = [
    { name: 'Kentaro Miura', work: 'Berserk' },
    { name: 'Akira Toriyama', work: 'Dragon Ball' },
    { name: 'Takehiko Inoue', work: 'Vagabond, Slam Dunk' },
    { name: 'Eiichiro Oda', work: 'One Piece' },
    { name: 'Masashi Kishimoto', work: 'Naruto' },
    { name: 'Hiromu Arakawa', work: 'Fullmetal Alchemist' },
    { name: 'Yoshihiro Togashi', work: 'Hunter x Hunter' },
    { name: 'Hajime Isayama', work: 'Attack on Titan' },
    { name: 'Junji Ito', work: 'Uzumaki' },
    { name: 'Naoko Takeuchi', work: 'Sailor Moon' },
    { name: 'Osamu Tezuka', work: 'Astro Boy' },
    { name: 'Katsuhiro Otomo', work: 'Akira' },
    { name: 'Tite Kubo', work: 'Bleach' },
    { name: 'Sui Ishida', work: 'Tokyo Ghoul' },
    { name: 'Rumiko Takahashi', work: 'Inuyasha' },
    { name: 'CLAMP', work: 'Cardcaptor Sakura' },
    { name: 'Masamune Shirow', work: 'Ghost in the Shell' },
    { name: 'Q Hayashida', work: 'Dorohedoro' },
    // FIX: Corrected a typo in the object property from `gite` to `name`.
    { name: 'Gege Akutami', work: 'Jujutsu Kaisen' },
    { name: 'Tsutomu Nihei', work: 'Blame!' },
];