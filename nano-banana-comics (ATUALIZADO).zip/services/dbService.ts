import { Creation } from '../types';

const DB_NAME = 'NanoBananaDB';
const DB_VERSION = 1;
const STORE_NAME = 'creations';

let db: IDBDatabase;

const initDB = (): Promise<IDBDatabase> => {
    return new Promise((resolve, reject) => {
        if (db) {
            return resolve(db);
        }

        const request = indexedDB.open(DB_NAME, DB_VERSION);

        request.onerror = (event) => {
            console.error('Database error:', request.error);
            reject('Database error');
        };

        request.onsuccess = (event) => {
            db = (event.target as IDBOpenDBRequest).result;
            resolve(db);
        };

        request.onupgradeneeded = (event) => {
            const dbInstance = (event.target as IDBOpenDBRequest).result;
            if (!dbInstance.objectStoreNames.contains(STORE_NAME)) {
                dbInstance.createObjectStore(STORE_NAME, { keyPath: 'id', autoIncrement: true });
            }
        };
    });
};

export const addCreation = async (creation: Creation): Promise<number> => {
    const db = await initDB();
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(STORE_NAME, 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.add(creation);
        
        request.onsuccess = () => resolve(request.result as number);
        request.onerror = () => {
            console.error('Error adding creation:', request.error);
            reject(request.error);
        };
    });
};

export const getCreations = async (): Promise<Creation[]> => {
    const db = await initDB();
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(STORE_NAME, 'readonly');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.getAll();

        request.onsuccess = () => {
            // Sort descending by timestamp
            const sorted = request.result.sort((a, b) => b.timestamp - a.timestamp);
            resolve(sorted);
        }
        request.onerror = () => {
            console.error('Error getting creations:', request.error);
            reject(request.error);
        };
    });
};

export const deleteCreation = async (id: number): Promise<void> => {
    const db = await initDB();
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(STORE_NAME, 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.delete(id);
        
        request.onsuccess = () => resolve();
        request.onerror = () => {
            console.error('Error deleting creation:', request.error);
            reject(request.error);
        };
    });
};

export const updateCreation = async (id: number, updatedCreation: Creation): Promise<void> => {
    const db = await initDB();
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(STORE_NAME, 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        const dataToStore = { ...updatedCreation, id };
        const request = store.put(dataToStore);
        
        request.onsuccess = () => resolve();
        request.onerror = () => {
            console.error('Error updating creation:', request.error);
            reject(request.error);
        };
    });
};