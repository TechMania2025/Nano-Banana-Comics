import React, { useState, useCallback, useEffect } from 'react';
import { AppState, Creation, ImageData, CameraFraming, CorrectionPayload, PanelConfig, PanelOutput, TextCharacter } from './types';
import { INITIAL_APP_STATE } from './constants';
import * as geminiService from './services/geminiService';
import * as dbService from './services/dbService';
import { cropImageBorders, fileToBase64 } from './utils';

import Header from './components/Header';
import ControlPanel from './components/ControlPanel';
import MediaDisplay from './components/MediaDisplay';
import CreationsGalleryModal from './components/CreationsGalleryModal';
import PromptEditorModal from './components/PromptEditorModal';
import PromptHelperModal from './components/PromptHelperModal';
import TextCorrectionModal from './components/TextCorrectionModal';
import FullPanelViewerModal from './components/FullPanelViewerModal';
import HowItWorksModal from './components/HowItWorksModal';
import Button from './components/Button';
import Modal from './components/Modal';

// Modal component for the new real-time editing feature
const PanelEditModal: React.FC<{
    panelImageUrl: string;
    onClose: () => void;
    onApply: (editText: string) => Promise<void>;
    isLoading: boolean;
    error: string | null;
}> = ({ panelImageUrl, onClose, onApply, isLoading, error }) => {
    const [editText, setEditText] = useState('');

    const handleApply = () => {
        if (!editText.trim()) return;
        onApply(editText);
    };

    return (
        <Modal title="Editar Painel em Tempo Real" onClose={onClose} size="3xl">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex flex-col items-center">
                    <h3 className="text-lg font-semibold mb-2 text-slate-300">Painel Atual</h3>
                    <img src={panelImageUrl} alt="Panel to edit" className="rounded-md w-full max-w-md object-contain bg-white" />
                </div>
                <div className="flex flex-col space-y-4">
                    <h3 className="text-lg font-semibold text-slate-300">O que você gostaria de alterar?</h3>
                    <p className="text-sm text-slate-400">
                        Descreva a alteração que você deseja. Por exemplo: "Adicione um chapéu de pirata no personagem da esquerda" ou "Mude o céu para noite".
                    </p>
                    <div>
                        <label htmlFor="edit-text" className="sr-only">Descrição da Alteração</label>
                        <textarea
                            id="edit-text"
                            value={editText}
                            onChange={(e) => setEditText(e.target.value)}
                            placeholder="Descreva sua alteração aqui..."
                            className="w-full h-48 p-2 bg-slate-700 border border-slate-600 rounded-md focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
                            disabled={isLoading}
                        />
                    </div>
                     {error && (
                        <p className="text-sm text-red-400 bg-red-900/50 p-3 rounded-md">{error}</p>
                    )}
                    <div className="flex justify-end space-x-4 pt-2">
                        <Button onClick={onClose} variant="secondary" disabled={isLoading}>Cancelar</Button>
                        <Button onClick={handleApply} isLoading={isLoading} disabled={!editText.trim()}>
                            Aplicar Alteração
                        </Button>
                    </div>
                </div>
            </div>
        </Modal>
    );
};


const App: React.FC = () => {
    const [appState, setAppState] = useState<AppState>(INITIAL_APP_STATE);
    const [isGalleryOpen, setGalleryOpen] = useState(false);
    const [isPromptEditorOpen, setPromptEditorOpen] = useState(false);
    const [isPromptHelperOpen, setPromptHelperOpen] = useState(false);
    const [isHowItWorksOpen, setHowItWorksOpen] = useState(false);
    const [creations, setCreations] = useState<Creation[]>([]);

    const [promptEditorTargetPanel, setPromptEditorTargetPanel] = useState<number | null>(null);
    const [promptHelperTargetPanel, setPromptHelperTargetPanel] = useState<number | null>(null);

    const [isCorrectionModalOpen, setCorrectionModalOpen] = useState(false);
    const [correctionTarget, setCorrectionTarget] = useState<{ page: number; panel: number; } | null>(null);
    const [isCorrecting, setIsCorrecting] = useState(false);
    const [isExtractingText, setIsExtractingText] = useState(false);
    const [extractedText, setExtractedText] = useState<string | null>(null);

    const [isFullPanelViewerOpen, setFullPanelViewerOpen] = useState(false);
    const [viewingPanel, setViewingPanel] = useState<PanelOutput | null>(null);
    
    const [isEditModalOpen, setEditModalOpen] = useState(false);
    const [editTarget, setEditTarget] = useState<{ page: number; panel: number; } | null>(null);
    const [isEditing, setIsEditing] = useState(false);


    const fetchCreations = useCallback(async () => {
        const items = await dbService.getCreations();
        setCreations(items);
    }, []);

    useEffect(() => {
        fetchCreations();
    }, [fetchCreations]);

    const handleStateChange = useCallback(<K extends keyof AppState>(key: K, value: AppState[K]) => {
        setAppState(prevState => ({ ...prevState, [key]: value }));
    }, []);

    const handlePanelConfigChange = (index: number, newConfig: PanelConfig) => {
        const newConfigs = [...appState.panelConfigs];
        newConfigs[index] = newConfig;
        handleStateChange('panelConfigs', newConfigs);
    };

    const handleAddPanel = () => {
        setAppState(prevState => {
            if (prevState.numPanels >= 9) return prevState; // Max 9 panels
            
            const newPanelConfig: PanelConfig = {
                prompt: '',
                framing: 'Automatic',
                contentContext: 'Automatic',
                atmosphere: 'Automatic',
                removeAccessories: false,
                noDialogue: false,
                noOnomatopoeia: false,
                excludedCharacters: [],
                panelSize: 'Automatic',
                extrasCount: 'Automatic',
                detailLevel: 'Automatic',
                characterAngle: 'Automatic',
                scenarioDescription: '',
                scenarioImage: undefined,
                objectImages: [],
                characterDialogues: {},
                characterBehaviors: {},
                characterEmotions: {},
                characterBalloons: {},
                extrasBehavior: '',
            };

            const newConfigs = [...prevState.panelConfigs, newPanelConfig];
            
            return {
                ...prevState,
                numPanels: prevState.numPanels + 1,
                panelConfigs: newConfigs,
            };
        });
    };

    const handleRemovePanel = (indexToRemove: number) => {
        setAppState(prevState => {
            if (prevState.numPanels <= 1) return prevState; // Min 1 panel
            const newConfigs = prevState.panelConfigs.filter((_, index) => index !== indexToRemove);
            return {
                ...prevState,
                numPanels: prevState.numPanels - 1,
                panelConfigs: newConfigs,
            };
        });
    };
    
    const handleImageNameChange = (id: string, name: string) => {
        const newImages = appState.referenceImages.map(img => 
            img.id === id ? { ...img, name } : img
        );
        handleStateChange('referenceImages', newImages);
    };

    const handleImagePersonaChange = (id: string, index: number, value: string) => {
        const newImages = appState.referenceImages.map(img => {
            if (img.id === id) {
                const newPersonas = [...(img.personas || ['', '', ''])];
                newPersonas[index] = value;
                return { ...img, personas: newPersonas };
            }
            return img;
        });
        handleStateChange('referenceImages', newImages);
    };

    const handleAddTextCharacter = () => {
        setAppState(prevState => {
            const newCharacter: TextCharacter = {
                id: `char-${Date.now()}-${Math.random()}`,
                name: '',
                appearance: '',
                personas: ['', '', ''],
            };
            return {
                ...prevState,
                referenceImages: [], // Enforce mutual exclusivity
                textCharacters: [...prevState.textCharacters, newCharacter],
            };
        });
    };

    const handleRemoveTextCharacter = (id: string) => {
        setAppState(prevState => ({
            ...prevState,
            textCharacters: prevState.textCharacters.filter(char => char.id !== id),
        }));
    };

    const handleUpdateTextCharacter = (id: string, field: keyof Omit<TextCharacter, 'id' | 'personas'>, value: string) => {
        setAppState(prevState => ({
            ...prevState,
            textCharacters: prevState.textCharacters.map(char =>
                char.id === id ? { ...char, [field]: value } : char
            ),
        }));
    };
    
    const handleUpdateTextCharacterPersona = (id: string, index: number, value: string) => {
        setAppState(prevState => ({
            ...prevState,
            textCharacters: prevState.textCharacters.map(char => {
                if (char.id === id) {
                    const newPersonas = [...(char.personas || ['', '', ''])];
                    newPersonas[index] = value;
                    return { ...char, personas: newPersonas };
                }
                return char;
            })
        }));
    };


    const handleClearTextCharacters = () => {
        handleStateChange('textCharacters', []);
    };


    const handleApiError = useCallback((error: any, context: string) => {
        console.error(`${context} failed:`, error);
        // Translate context string for user display
        const contextPt: { [key: string]: string } = {
            'Generation': 'Geração',
            'Translation': 'Tradução',
            'Prompt detailing': 'Detalhamento de Prompt',
            'Prompt building': 'Construção de Prompt',
            'Text Extraction': 'Extração de Texto',
            'Text Correction': 'Correção de Texto',
            'Appearance Analysis': 'Análise de Aparência',
            'Panel Regeneration': 'Regeneração de Painel',
            'Image Validation': 'Validação de Imagem',
            'Panel Splitting': 'Divisão de Painel',
            'Inconsistency Analysis': 'Análise de Incoerência',
            'Panel Editing': 'Edição de Painel',
        };
        const translatedContext = contextPt[context] || context.toLowerCase();
        
        let errorMessage = `Ocorreu um erro desconhecido durante a ${translatedContext}.`;

        const apiErrorDetails = error?.error;

        if (apiErrorDetails?.status === 'RESOURCE_EXHAUSTED') {
            errorMessage = 'Cota da API excedida. Por favor, aguarde um momento e tente novamente.';
        } else if (apiErrorDetails?.message) {
            errorMessage = apiErrorDetails.message;
        } else if (error.message) {
            errorMessage = error.message;
        }
        
        handleStateChange('error', errorMessage);
    }, [handleStateChange]);

    const validateImagePlacements = async (): Promise<string[]> => {
        const warnings: string[] = [];
        const { panelConfigs } = appState;
    
        handleStateChange('isLoading', true);
        handleStateChange('loadingMessage', 'Validando imagens...');
        handleStateChange('error', null);
    
        try {
            for (let i = 0; i < panelConfigs.length; i++) {
                const config = panelConfigs[i];
                const isGlobalScenario = appState.useGlobalScenario && i > 0;
    
                // Validate Scenario Image (only for panel 0 if global is active)
                if (config.scenarioImage && !isGlobalScenario) {
                    const classification = await geminiService.classifyImageContent(
                        config.scenarioImage.dataUrl.split(',')[1],
                        config.scenarioImage.mimeType
                    );
                    if (classification === 'CHARACTER') {
                        warnings.push(`Painel ${i + 1}: A imagem de fundo parece ser um personagem. Recomenda-se usar uma imagem de ambiente.`);
                    }
                }
    
                // Validate Object Images for every panel
                if (config.objectImages && config.objectImages.length > 0) {
                    for (const objectImage of config.objectImages) {
                        const classification = await geminiService.classifyImageContent(
                            objectImage.dataUrl.split(',')[1],
                            objectImage.mimeType
                        );
                        const imageName = objectImage.name || 'sem nome';
                        if (classification === 'CHARACTER') {
                            warnings.push(`Painel ${i + 1}: O objeto de cena '${imageName}' parece ser um personagem. Recomenda-se usar imagens de itens.`);
                        } else if (classification === 'SCENARIO') {
                            warnings.push(`Painel ${i + 1}: O objeto de cena '${imageName}' parece ser um cenário. Recomenda-se usar imagens de itens específicos.`);
                        }
                    }
                }
            }
        } catch(error: any) {
            handleApiError(error, 'Image Validation');
            // Return an error message as a warning to stop generation
            return ["Ocorreu um erro durante a validação da imagem. Por favor, tente novamente."];
        } finally {
            handleStateChange('isLoading', false);
            handleStateChange('loadingMessage', '');
        }
    
        return warnings;
    };
    
    const handleGenerate = async () => {
        const warnings = await validateImagePlacements();
        if (warnings.length > 0) {
            const warningMessage = "Avisos da IA:\n\n" + warnings.join('\n') + "\n\nDeseja continuar com a geração mesmo assim?";
            if (!window.confirm(warningMessage)) {
                return; // Abort generation
            }
        }

        setAppState(prev => ({ ...prev, isLoading: true, error: null, output: null, currentCreationId: null }));

        let allPagesOutput: { url: string; mimeType: string; }[][][] = [];

        try {
            for (let i = 0; i < appState.numPages; i++) {
                handleStateChange('loadingMessage', `Gerando Página ${i + 1} de ${appState.numPages}...`);
                const pagePanels = await geminiService.generateMangaPage(appState, (panelIndex) => {
                    handleStateChange('loadingMessage', `Gerando Página ${i + 1}, Painel ${panelIndex + 1}/${appState.numPanels}...`);
                });
                allPagesOutput.push(pagePanels);
            }

            if (appState.fillPanelCompletely) {
                handleStateChange('loadingMessage', 'Finalizando e aparando painéis...');
                const allPanelsFlat = allPagesOutput.flat().map(p => p[0]);
                const cropPromises = allPanelsFlat.map(panel => cropImageBorders({ url: `data:${panel.mimeType};base64,${panel.url}`, mimeType: panel.mimeType }));
                const croppedPanelsFlat = await Promise.all(cropPromises);

                let flatIndex = 0;
                allPagesOutput = allPagesOutput.map(page =>
                    page.map(() => {
                        const panel = croppedPanelsFlat[flatIndex];
                        const base64 = panel.url.split(',')[1];
                        flatIndex++;
                        return [{ url: base64, mimeType: panel.mimeType }];
                    })
                );
            }
            
            const finalOutput = allPagesOutput.map(page => 
                page.map(panel => ({
                    url: `data:${panel[0].mimeType};base64,${panel[0].url}`,
                    mimeType: panel[0].mimeType,
                }))
            );

            const finalState = { ...appState, output: finalOutput, isLoading: false, loadingMessage: ''};

            const creation: Creation = {
                ...finalState,
                timestamp: Date.now(),
            };
            
            const newId = await dbService.addCreation(creation);
            setAppState({ ...finalState, currentCreationId: newId });

            fetchCreations();

        } catch (error: any) {
            handleApiError(error, 'Generation');
            setAppState(prev => ({ ...prev, isLoading: false, loadingMessage: '' }));
        }
    };

    const clearAll = () => {
        setAppState(INITIAL_APP_STATE);
    };
    
    const reloadCreation = (creation: Creation) => {
        const { id, timestamp, ...creationState } = creation;
        const reloadedState = { ...creationState } as any; // Use any for migration

        // --- Backwards Compatibility ---
        const oldPrompt = reloadedState.prompt ?? '';
        const oldContentContext = reloadedState.contentContext ?? 'None';
        const oldNoExtras = reloadedState.noExtras ?? false;

        // --- New state structure with defaults ---
        const finalState: AppState = {
            comicTitle: reloadedState.comicTitle ?? '', 
            characterDetailsEnabled: reloadedState.characterDetailsEnabled ?? false,
            displayTitleOnPanel: reloadedState.displayTitleOnPanel ?? false,
            artistStyle: reloadedState.artistStyle,
            maintainReferenceStyle: reloadedState.maintainReferenceStyle,
            generateInPortuguese: reloadedState.generateInPortuguese,
            referenceImages: [], // will populate below
            textCharacters: [], // will populate below
            numPages: reloadedState.numPages,
            numPanels: reloadedState.numPanels,
            panelConfigs: [], // will populate below
            isLoading: false, 
            loadingMessage: '',
            output: reloadedState.output,
            error: null,
            currentCreationId: id || null,
            isColor: reloadedState.isColor ?? false,
            comicStyle: reloadedState.comicStyle ?? 'Manga',
            genre: reloadedState.genre ?? 'Action',
            useGlobalScenario: reloadedState.useGlobalScenario ?? false,
            fillPanelCompletely: reloadedState.fillPanelCompletely ?? false,
            // Handle new appearanceMemory structure
            appearanceMemory: (reloadedState.appearanceMemory && typeof reloadedState.appearanceMemory === 'object' && !Array.isArray(reloadedState.appearanceMemory))
                ? reloadedState.appearanceMemory 
                : {}, // Discard old string-based memory
        };
        
        // Migrate reference images (personality -> personas)
        finalState.referenceImages = (reloadedState.referenceImages || []).map((img: any): ImageData => {
            let personas = img.personas || ['', '', ''];
            // Migrate old format
            if (img.personality && !img.personas) {
                personas = [img.personality, '', ''];
            }
            // Ensure it's always an array of 3 strings for the UI to map over
            const finalPersonas = [...personas, '', '', ''].slice(0, 3);
            return {
                dataUrl: img.dataUrl,
                mimeType: img.mimeType,
                id: img.id,
                name: img.name,
                personas: finalPersonas,
                clothingReference: img.clothingReference || undefined,
            };
        });

        // Migrate text characters (persona -> personas)
        finalState.textCharacters = (reloadedState.textCharacters || []).map((char: any): TextCharacter => {
            let personas = char.personas || ['', '', ''];
            if (char.persona && !char.personas) {
                personas = [char.persona, '', ''];
            }
            const finalPersonas = [...personas, '', '', ''].slice(0, 3);
            return {
                id: char.id,
                name: char.name,
                appearance: char.appearance,
                personas: finalPersonas,
                clothingReference: char.clothingReference || undefined,
            };
        });


        // Populate panelConfigs, ensuring all new fields have defaults for old saves
        finalState.panelConfigs = Array.from({ length: finalState.numPanels }, (_, i) => {
            const existingConfig = reloadedState.panelConfigs?.[i];
            const panelSize = existingConfig?.panelSize || 'Automatic';
            // Prevent loading action-based panel sizes
            const finalPanelSize = ['Split Horizontally', 'Split Vertically'].includes(panelSize) ? 'Automatic' : panelSize;

            return {
                // Migrate old top-level fields to panel-specific fields
                prompt: existingConfig?.prompt || oldPrompt,
                contentContext: existingConfig?.contentContext || oldContentContext,
                // New fields get defaults
                atmosphere: existingConfig?.atmosphere || 'Automatic',
                panelSize: finalPanelSize,
                extrasCount: existingConfig?.extrasCount || (oldNoExtras ? 'None' : 'Automatic'),
                detailLevel: existingConfig?.detailLevel || 'Automatic',
                characterAngle: existingConfig?.characterAngle || 'Automatic',
                scenarioImage: existingConfig?.scenarioImage || undefined,
                objectImages: existingConfig?.objectImages || [],
                // Existing fields
                framing: existingConfig?.framing || 'Automatic' as CameraFraming,
                removeAccessories: existingConfig?.removeAccessories ?? false,
                noDialogue: existingConfig?.noDialogue ?? false,
                noOnomatopoeia: existingConfig?.noOnomatopoeia ?? false,
                excludedCharacters: existingConfig?.excludedCharacters || [],
                // Add defaults for newly added fields
                scenarioDescription: existingConfig?.scenarioDescription || '',
                characterDialogues: existingConfig?.characterDialogues || {},
                characterBehaviors: existingConfig?.characterBehaviors || {},
                characterEmotions: existingConfig?.characterEmotions || {},
                characterBalloons: existingConfig?.characterBalloons || {},
                extrasBehavior: existingConfig?.extrasBehavior || '',
            };
        });

        // Migrate old globalScenario to the first panel's description if it was used
        if (reloadedState.useGlobalScenario && reloadedState.globalScenario && finalState.panelConfigs.length > 0) {
            finalState.panelConfigs[0].scenarioDescription = reloadedState.globalScenario;
        }

        setAppState(finalState);
        setGalleryOpen(false);
    };


    const deleteCreation = async (id: number) => {
        if (window.confirm('Tem certeza de que deseja excluir permanentemente esta criação?')) {
            await dbService.deleteCreation(id);
            fetchCreations();
        }
    };

    const handleTranslate = async (text: string, panelIndex: number) => {
        if (!text) return;
        try {
            const characterNames = appState.referenceImages
                .map(img => img.name)
                .filter((name): name is string => !!name && name.trim() !== '');

            const translatedText = await geminiService.translateText(text, characterNames);
            const panelConfig = appState.panelConfigs[panelIndex];
            handlePanelConfigChange(panelIndex, { ...panelConfig, prompt: translatedText });
        } catch(error: any) {
            handleApiError(error, 'Translation');
        }
    };

    const handleDetailPrompt = async (panelIndex: number) => {
        const panelConfig = appState.panelConfigs[panelIndex];
        if (!panelConfig.prompt) return;
        // Don't set global loading, maybe a per-panel indicator later
        try {
            const detailedPrompt = await geminiService.detailPrompt(panelConfig.prompt);
            handlePanelConfigChange(panelIndex, { ...panelConfig, prompt: detailedPrompt });
        } catch(error: any) {
            handleApiError(error, 'Prompt detailing');
        }
    };

    const buildPrompt = async (keywords: string) => {
        if (promptHelperTargetPanel === null) return;
        try {
            const newPrompt = await geminiService.buildPrompt(keywords);
            const panelConfig = appState.panelConfigs[promptHelperTargetPanel];
            handlePanelConfigChange(promptHelperTargetPanel, { ...panelConfig, prompt: newPrompt });
            setPromptHelperOpen(false);
        } catch (error: any) {
            handleApiError(error, 'Prompt building');
        }
    };

    const handleOpenPromptEditor = (panelIndex: number) => {
        setPromptEditorTargetPanel(panelIndex);
        setPromptEditorOpen(true);
    };

    const handleSavePromptEditor = (prompt: string) => {
        if (promptEditorTargetPanel === null) return;
        const panelConfig = appState.panelConfigs[promptEditorTargetPanel];
        handlePanelConfigChange(promptEditorTargetPanel, { ...panelConfig, prompt });
        setPromptEditorOpen(false);
    };
    
    const handleOpenPromptHelper = (panelIndex: number) => {
        setPromptHelperTargetPanel(panelIndex);
        setPromptHelperOpen(true);
    };

    const handleInsertToPromptHelper = (text: string) => {
        if (promptHelperTargetPanel === null) return;
        const panelConfig = appState.panelConfigs[promptHelperTargetPanel];
        const newPrompt = panelConfig.prompt + text;
        handlePanelConfigChange(promptHelperTargetPanel, { ...panelConfig, prompt: newPrompt });
    };

    const handleOpenCorrectionModal = async (pageIndex: number, panelIndex: number) => {
        if (appState.output?.[pageIndex]?.[panelIndex]) {
            setCorrectionTarget({ page: pageIndex, panel: panelIndex });
            setCorrectionModalOpen(true);
            setExtractedText(null); // Reset
            handleStateChange('error', null);
            setIsExtractingText(true);

            try {
                const targetPanel = appState.output[pageIndex][panelIndex];
                const base64Data = targetPanel.url.split(',')[1];
                const text = await geminiService.extractTextFromPanel(base64Data, targetPanel.mimeType);
                setExtractedText(text);
            } catch (error: any) {
                handleApiError(error, 'Text Extraction');
            } finally {
                setIsExtractingText(false);
            }
        }
    };
    
    const handleCloseCorrectionModal = () => {
        setCorrectionModalOpen(false);
        setCorrectionTarget(null);
        setExtractedText(null); // Clean up
    };

    const handleApplyCorrection = async (correction: CorrectionPayload) => {
        if (!correctionTarget || !appState.output || !appState.currentCreationId) return;
        
        setIsCorrecting(true);
        handleStateChange('error', null);

        try {
            const targetPanel = appState.output[correctionTarget.page][correctionTarget.panel];
            const base64Data = targetPanel.url.split(',')[1];

            const correctedPanel = await geminiService.correctPanelText(
                base64Data,
                targetPanel.mimeType,
                correction
            );
            
            const newImageUrl = `data:${correctedPanel.mimeType};base64,${correctedPanel.url}`;

            // Update state immutably
            const newOutput = appState.output.map((page, pIndex) => {
                if (pIndex !== correctionTarget.page) return page;
                return page.map((panel, panIndex) => {
                    if (panIndex !== correctionTarget.panel) return panel;
                    return { url: newImageUrl, mimeType: correctedPanel.mimeType };
                });
            });

            const newAppState = { ...appState, output: newOutput };
            setAppState(newAppState);
            
            // Save updated creation to DB
            const updatedCreationState: Creation = {
                ...newAppState,
                timestamp: Date.now(), // update timestamp
            };
            await dbService.updateCreation(appState.currentCreationId, updatedCreationState);
            
            fetchCreations(); // Refresh gallery
            handleCloseCorrectionModal();

        } catch (error: any) {
            handleApiError(error, 'Text Correction');
            // Don't close modal on error, so user can retry
        } finally {
            setIsCorrecting(false);
        }
    };

    const handleSetAppearanceMemory = (characterName: string, panel: PanelOutput) => {
        setAppState(prev => ({
            ...prev,
            appearanceMemory: {
                ...prev.appearanceMemory,
                [characterName]: panel,
            }
        }));
    };
    
    const handleClearAppearanceMemory = (characterName: string) => {
        setAppState(prev => {
            const newMemory = { ...prev.appearanceMemory };
            delete newMemory[characterName];
            return {
                ...prev,
                appearanceMemory: newMemory,
            };
        });
    };

    const handleSetClothingReference = async (characterId: string, characterType: 'image' | 'text', file: File) => {
        const imageData = await fileToBase64(file);
        
        if (characterType === 'image') {
            setAppState(prev => ({
                ...prev,
                referenceImages: prev.referenceImages.map(char => 
                    char.id === characterId ? { ...char, clothingReference: imageData } : char
                ),
            }));
        } else {
             setAppState(prev => ({
                ...prev,
                textCharacters: prev.textCharacters.map(char => 
                    char.id === characterId ? { ...char, clothingReference: imageData } : char
                ),
            }));
        }
    };

    const handleRemoveClothingReference = (characterId: string, characterType: 'image' | 'text') => {
         if (characterType === 'image') {
            setAppState(prev => ({
                ...prev,
                referenceImages: prev.referenceImages.map(char => 
                    char.id === characterId ? { ...char, clothingReference: undefined } : char
                ),
            }));
        } else {
             setAppState(prev => ({
                ...prev,
                textCharacters: prev.textCharacters.map(char => 
                    char.id === characterId ? { ...char, clothingReference: undefined } : char
                ),
            }));
        }
    };


    const handleRedoPanel = async (pageIndex: number, panelIndex: number) => {
        if (!appState.output || !appState.currentCreationId) return;

        const panelConfig = appState.panelConfigs[panelIndex];
        if (!panelConfig) return;

        handleStateChange('isLoading', true);
        handleStateChange('loadingMessage', `Refazendo Página ${pageIndex + 1}, Painel ${panelIndex + 1}...`);
        handleStateChange('error', null);

        try {
            let regeneratedPanelParts = await geminiService.generateSinglePanel(
                appState,
                panelConfig,
                panelIndex
            );

            let regeneratedPanel = regeneratedPanelParts[0];
            const originalOutputPanel = { url: `data:${regeneratedPanel.mimeType};base64,${regeneratedPanel.url}`, mimeType: regeneratedPanel.mimeType };

            if (appState.fillPanelCompletely) {
                handleStateChange('loadingMessage', `Finalizando e aparando painel...`);
                const croppedPanel = await cropImageBorders(originalOutputPanel);
                regeneratedPanel = { url: croppedPanel.url.split(',')[1], mimeType: croppedPanel.mimeType };
            }

            const newImageUrl = `data:${regeneratedPanel.mimeType};base64,${regeneratedPanel.url}`;
            const newMimeType = regeneratedPanel.mimeType;

            // Update state immutably
            const newOutput = appState.output.map((page, pIndex) => {
                if (pIndex !== pageIndex) return page;
                return page.map((panel, panIndex) => {
                    if (panIndex !== panelIndex) return panel;
                    return { url: newImageUrl, mimeType: newMimeType };
                });
            });

            const newAppState = { ...appState, output: newOutput };
            setAppState(newAppState);
            
            // Save updated creation to DB
            const updatedCreationState: Creation = {
                ...newAppState,
                timestamp: Date.now(),
            };
            await dbService.updateCreation(appState.currentCreationId, updatedCreationState);
            
            fetchCreations(); // Refresh gallery

        } catch (error: any) {
            handleApiError(error, 'Panel Regeneration');
        } finally {
            handleStateChange('isLoading', false);
            handleStateChange('loadingMessage', '');
        }
    };

    const handleAnalyzeInconsistency = async (pageIndex: number, panelIndex: number) => {
        if (!appState.output || !appState.currentCreationId) return;
    
        handleStateChange('isLoading', true);
        handleStateChange('loadingMessage', `Analisando incoerências no Painel ${panelIndex + 1}...`);
        handleStateChange('error', null);
    
        try {
            const targetPanel = appState.output[pageIndex][panelIndex];
            const base64Data = targetPanel.url.split(',')[1];
    
            const correctedPanel = await geminiService.analyzeAndCorrectInconsistency(
                base64Data,
                targetPanel.mimeType
            );
            
            const newImageUrl = `data:${correctedPanel.mimeType};base64,${correctedPanel.url}`;
    
            // Update state immutably
            const newOutput = appState.output.map((page, pIndex) => {
                if (pIndex !== pageIndex) return page;
                return page.map((panel, panIndex) => {
                    if (panIndex !== panelIndex) return panel;
                    return { url: newImageUrl, mimeType: correctedPanel.mimeType };
                });
            });
    
            const newAppState = { ...appState, output: newOutput };
            setAppState(newAppState);
            
            // Save updated creation to DB
            const updatedCreationState: Creation = {
                ...newAppState,
                timestamp: Date.now(),
            };
            await dbService.updateCreation(appState.currentCreationId, updatedCreationState);
            
            fetchCreations(); // Refresh gallery
    
        } catch (error: any) {
            handleApiError(error, 'Inconsistency Analysis');
        } finally {
            handleStateChange('isLoading', false);
            handleStateChange('loadingMessage', '');
        }
    };

    const handleSplitPanel = (panelIndex: number, direction: 'Split Horizontally' | 'Split Vertically') => {
        if (appState.numPanels >= 9) {
            alert("Número máximo de painéis (9) atingido.");
            return;
        }

        const originalConfig = appState.panelConfigs[panelIndex];
        
        const newPrompt = window.prompt("Descreva a cena para o segundo painel (a segunda metade):");

        if (newPrompt === null || newPrompt.trim() === '') {
            // User cancelled or entered nothing
            return;
        }

        setAppState(prevState => {
            const newConfigs = [...prevState.panelConfigs];
            
            const newPanelConfig: PanelConfig = { 
                ...originalConfig, 
                prompt: newPrompt.trim(),
                panelSize: 'Automatic', // Reset panel size for the new panel
            };
            newConfigs.splice(panelIndex + 1, 0, newPanelConfig);

            // Also reset the original panel's size property
            newConfigs[panelIndex] = { ...newConfigs[panelIndex], panelSize: 'Automatic' };

            return {
                ...prevState,
                numPanels: prevState.numPanels + 1,
                panelConfigs: newConfigs,
            };
        });
    };

    const handleOpenFullPanelViewer = (pageIndex: number, panelIndex: number) => {
        if (appState.output?.[pageIndex]?.[panelIndex]) {
            setViewingPanel(appState.output[pageIndex][panelIndex]);
            setFullPanelViewerOpen(true);
        }
    };

    const handleCloseFullPanelViewer = () => {
        setFullPanelViewerOpen(false);
        setViewingPanel(null);
    };

    const handleOpenEditModal = (pageIndex: number, panelIndex: number) => {
        if (appState.output?.[pageIndex]?.[panelIndex]) {
            setEditTarget({ page: pageIndex, panel: panelIndex });
            setEditModalOpen(true);
            handleStateChange('error', null); // Clear previous errors
        }
    };

    const handleCloseEditModal = () => {
        setEditModalOpen(false);
        setEditTarget(null);
    };

    const handleApplyEdit = async (editText: string) => {
        if (!editTarget || !appState.output || !appState.currentCreationId) return;
        
        setIsEditing(true);
        handleStateChange('error', null);

        try {
            const targetPanel = appState.output[editTarget.page][editTarget.panel];
            const base64Data = targetPanel.url.split(',')[1];

            const editedPanel = await geminiService.editPanelWithText(
                base64Data,
                targetPanel.mimeType,
                editText
            );
            
            const newImageUrl = `data:${editedPanel.mimeType};base64,${editedPanel.url}`;

            // Update state immutably
            const newOutput = appState.output.map((page, pIndex) => {
                if (pIndex !== editTarget.page) return page;
                return page.map((panel, panIndex) => {
                    if (panIndex !== editTarget.panel) return panel;
                    return { url: newImageUrl, mimeType: editedPanel.mimeType };
                });
            });

            const newAppState = { ...appState, output: newOutput };
            setAppState(newAppState);
            
            // Save updated creation to DB
            const updatedCreationState: Creation = {
                ...newAppState,
                timestamp: Date.now(),
            };
            await dbService.updateCreation(appState.currentCreationId, updatedCreationState);
            
            fetchCreations(); // Refresh gallery
            handleCloseEditModal();

        } catch (error: any) {
            handleApiError(error, 'Panel Editing');
        } finally {
            setIsEditing(false);
        }
    };


    const namedCharacters = (appState.referenceImages.length > 0 ? appState.referenceImages : appState.textCharacters)
        .filter(c => c.name && c.name.trim() !== '');


    return (
        <div className="min-h-screen bg-slate-900 text-slate-200 flex flex-col">
            <Header
                onGalleryClick={() => setGalleryOpen(true)}
                onHowItWorksClick={() => setHowItWorksOpen(true)}
            />
            <main className="flex-grow container mx-auto p-4 md:p-6 lg:p-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-1">
                    <ControlPanel
                        appState={appState}
                        onStateChange={handleStateChange}
                        onGenerate={handleGenerate}
                        onClearAll={clearAll}
                        onImageNameChange={handleImageNameChange}
                        onImagePersonaChange={handleImagePersonaChange}
                        onAddPanel={handleAddPanel}
                        onRemovePanel={handleRemovePanel}
                        onPanelConfigChange={handlePanelConfigChange}
                        onSplitPanel={handleSplitPanel}
                        onTranslatePanel={handleTranslate}
                        onDetailPanel={handleDetailPrompt}
                        onOpenPromptEditor={handleOpenPromptEditor}
                        onOpenPromptHelper={handleOpenPromptHelper}
                        onAddTextCharacter={handleAddTextCharacter}
                        onRemoveTextCharacter={handleRemoveTextCharacter}
                        onUpdateTextCharacter={handleUpdateTextCharacter}
                        onUpdateTextCharacterPersona={handleUpdateTextCharacterPersona}
                        onClearTextCharacters={handleClearTextCharacters}
                        onClearAppearanceMemory={handleClearAppearanceMemory}
                        onSetClothingReference={handleSetClothingReference}
                        onRemoveClothingReference={handleRemoveClothingReference}
                    />
                </div>
                <div className="lg:col-span-2">
                    <MediaDisplay
                        output={appState.output}
                        isLoading={appState.isLoading}
                        loadingMessage={appState.loadingMessage}
                        error={appState.error}
                        onCorrectText={handleOpenCorrectionModal}
                        onSetAppearanceMemory={handleSetAppearanceMemory}
                        onRedoPanel={handleRedoPanel}
                        onAnalyzeInconsistency={handleAnalyzeInconsistency}
                        onViewFullPanel={handleOpenFullPanelViewer}
                        onOpenEditModal={handleOpenEditModal}
                        namedCharacters={namedCharacters}
                    />
                </div>
            </main>

            {isGalleryOpen && (
                <CreationsGalleryModal
                    creations={creations}
                    onClose={() => setGalleryOpen(false)}
                    onReload={reloadCreation}
                    onDelete={deleteCreation}
                />
            )}

            {isPromptEditorOpen && promptEditorTargetPanel !== null && (
                <PromptEditorModal
                    initialPrompt={appState.panelConfigs[promptEditorTargetPanel]?.prompt || ''}
                    onSave={handleSavePromptEditor}
                    onClose={() => setPromptEditorOpen(false)}
                />
            )}
            
            {isPromptHelperOpen && (
                <PromptHelperModal
                    onClose={() => setPromptHelperOpen(false)}
                    onInsertText={handleInsertToPromptHelper}
                    onBuildPrompt={buildPrompt}
                />
            )}

            {isCorrectionModalOpen && correctionTarget && appState.output && (
                <TextCorrectionModal
                    panelImageUrl={appState.output[correctionTarget.page][correctionTarget.panel].url}
                    onClose={handleCloseCorrectionModal}
                    onApply={handleApplyCorrection}
                    isLoading={isCorrecting}
                    error={appState.error}
                    isExtractingText={isExtractingText}
                    initialExtractedText={extractedText}
                />
            )}

            {isFullPanelViewerOpen && (
                <FullPanelViewerModal
                    panel={viewingPanel}
                    onClose={handleCloseFullPanelViewer}
                />
            )}

            {isHowItWorksOpen && (
                <HowItWorksModal onClose={() => setHowItWorksOpen(false)} />
            )}

            {isEditModalOpen && editTarget && appState.output && (
                <PanelEditModal
                    panelImageUrl={appState.output[editTarget.page][editTarget.panel].url}
                    onClose={handleCloseEditModal}
                    onApply={handleApplyEdit}
                    isLoading={isEditing}
                    error={appState.error}
                />
            )}
        </div>
    );
};

export default App;