
import React, { DragEvent, useCallback, useState } from 'react';
import { ImageData, PanelOutput } from '../types';
import * as geminiService from '../services/geminiService';
import Spinner from './Spinner';

interface MultiImageUploaderProps {
    images: ImageData[];
    onImageUpload: (files: FileList) => void;
    onImageClear: (id: string) => void;
    onImageNameChange: (id: string, name: string) => void;
    onImagePersonaChange: (id: string, index: number, value: string) => void;
    characterDetailsEnabled: boolean;
    disabled?: boolean;
    appearanceMemory: { [characterName: string]: PanelOutput | null };
    onClearAppearanceMemory: (characterName: string) => void;
    onSetClothingReference: (characterId: string, characterType: 'image', file: File) => void;
    onRemoveClothingReference: (characterId: string, characterType: 'image') => void;
}

const UploadIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
    </svg>
);

const TranslateIcon = () => ( <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}> <path strokeLinecap="round" strokeLinejoin="round" d="M3 5h12M9 3v2m4 13l4-4M19 17l-4-4M3 19h12a2 2 0 002-2V7a2 2 0 00-2-2H3a2 2 0 00-2 2v10a2 2 0 002 2z" /> </svg> );
const DescribeIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
    </svg>
);


const MultiImageUploader: React.FC<MultiImageUploaderProps> = (props) => {
    const { images, onImageUpload, onImageClear, onImageNameChange, onImagePersonaChange, characterDetailsEnabled, disabled, appearanceMemory, onClearAppearanceMemory, onSetClothingReference, onRemoveClothingReference } = props;
    const [isDragging, setIsDragging] = useState(false);
    const [translatingId, setTranslatingId] = useState<string | null>(null);
    const [descriptions, setDescriptions] = useState<Record<string, string>>({});
    const [describingId, setDescribingId] = useState<string | null>(null);
    const [descriptionError, setDescriptionError] = useState<string | null>(null);
    const [translatingDescriptionId, setTranslatingDescriptionId] = useState<string | null>(null);
    const [clothingDescriptions, setClothingDescriptions] = useState<Record<string, string>>({});
    const [describingClothingId, setDescribingClothingId] = useState<string | null>(null);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            onImageUpload(e.target.files);
        }
        // Reset input value to allow re-uploading the same file
        e.target.value = '';
    };
    
    const handleDrag = useCallback((e: DragEvent<HTMLDivElement>, enter: boolean) => {
        e.preventDefault();
        e.stopPropagation();
        if (!disabled) setIsDragging(enter);
    }, [disabled]);

    const handleDrop = useCallback((e: DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
        if (!disabled && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            onImageUpload(e.dataTransfer.files);
        }
    }, [disabled, onImageUpload]);

    const handleTranslate = async (id: string, text: string, personaIndex: number) => {
        if (!text || translatingId) return;
        const uniqueId = `${id}-persona-${personaIndex}`;
        setTranslatingId(uniqueId);
        try {
            const namesToPreserve = images.map(i => i.name).filter(Boolean) as string[];
            const translatedText = await geminiService.translateText(text, namesToPreserve);
            onImagePersonaChange(id, personaIndex, translatedText);
        } catch (error) {
            console.error(`Translation for ${uniqueId} failed`, error);
        } finally {
            setTranslatingId(null);
        }
    };

    const handleDescribeAppearance = async (image: ImageData) => {
        setDescribingId(image.id);
        setDescriptionError(null);
        try {
            const description = await geminiService.describeCharacterAppearance(image.dataUrl.split(',')[1], image.mimeType);
            setDescriptions(prev => ({...prev, [image.id]: description}));
        } catch (error: any) {
            console.error("Failed to describe character", error);
            const errorMessage = error?.message || 'Falha ao descrever a aparência do personagem.';
            setDescriptionError(errorMessage);
        } finally {
            setDescribingId(null);
        }
    };
    
    const handleTranslateDescription = async (id: string, text: string, type: 'appearance' | 'clothing') => {
        if (!text || translatingDescriptionId) return;
        setTranslatingDescriptionId(`${id}-${type}`);
        try {
            const translatedText = await geminiService.translateText(text, []);
            if (type === 'appearance') {
                setDescriptions(prev => ({...prev, [id]: translatedText}));
            } else {
                setClothingDescriptions(prev => ({...prev, [id]: translatedText}));
            }
        } catch (error) {
            console.error(`Translation for description ${id} failed`, error);
        } finally {
            setTranslatingDescriptionId(null);
        }
    };

    const handleDescribeClothing = async (characterId: string, clothingImage: ImageData) => {
        setDescribingClothingId(characterId);
        setDescriptionError(null);
        try {
            const description = await geminiService.describeClothing(clothingImage.dataUrl.split(',')[1], clothingImage.mimeType);
            setClothingDescriptions(prev => ({...prev, [characterId]: description}));
        } catch(error: any) {
             console.error("Failed to describe clothing", error);
            const errorMessage = error?.message || 'Falha ao descrever a roupa.';
            setDescriptionError(errorMessage);
        } finally {
            setDescribingClothingId(null);
        }
    };

    const handleClothingReferenceUpload = (e: React.ChangeEvent<HTMLInputElement>, characterId: string) => {
        if (e.target.files && e.target.files[0]) {
            onSetClothingReference(characterId, 'image', e.target.files[0]);
        }
        e.target.value = '';
    };


    return (
        <div className="space-y-3">
            <label className="text-sm font-medium text-slate-300">Imagens de Referência (Opcional)</label>
            {descriptionError && <p className="text-xs text-red-400 mt-1">{descriptionError}</p>}
            <div 
                className={`relative w-full min-h-[100px] rounded-md border-2 border-dashed flex items-center justify-center text-center transition-colors p-2 ${isDragging ? 'border-yellow-500 bg-slate-700' : 'border-slate-600'} ${disabled ? 'opacity-50' : ''}`}
                onDragEnter={(e) => handleDrag(e, true)}
                onDragLeave={(e) => handleDrag(e, false)}
                onDragOver={(e) => handleDrag(e, true)}
                onDrop={handleDrop}
            >
                {images.length === 0 ? (
                    <label htmlFor="reference-images-input" className={`p-4 text-center w-full h-full flex flex-col justify-center items-center ${disabled ? 'cursor-not-allowed' : 'cursor-pointer hover:border-slate-500'}`}>
                        <UploadIcon />
                        <p className="text-xs text-slate-400 mt-2">Arraste e Solte ou <span className="font-semibold text-yellow-400">Clique para Enviar</span></p>
                    </label>
                ) : (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-2 lg:grid-cols-3 gap-3 w-full">
                        {images.map(image => {
                            const memorizedAppearance = image.name ? appearanceMemory[image.name] : null;
                            return (
                             <div key={image.id} className="p-2 bg-slate-800/50 rounded-lg flex flex-col gap-2">
                                <div className="relative aspect-square">
                                    <img src={image.dataUrl} alt="Reference" className="w-full h-full object-cover rounded-md" />
                                    <button
                                        onClick={() => onImageClear(image.id)}
                                        className="absolute top-1 right-1 bg-black/50 text-white rounded-full p-0 w-5 h-5 flex items-center justify-center leading-none text-md hover:bg-black/75"
                                        disabled={disabled}
                                    >
                                        &times;
                                    </button>
                                </div>
                                <input
                                    type="text"
                                    placeholder="Nome..."
                                    value={image.name || ''}
                                    onChange={(e) => onImageNameChange(image.id, e.target.value)}
                                    disabled={disabled}
                                    className="w-full text-xs p-1 bg-slate-700 border border-slate-600 rounded-md text-center text-slate-200 placeholder-slate-400 focus:ring-1 focus:ring-yellow-500 focus:border-yellow-500"
                                />
                                 {memorizedAppearance && image.name && (
                                    <div className="p-2 bg-slate-900/50 rounded-md space-y-2">
                                        <h4 className="text-xs font-semibold text-yellow-400">Aparência Memorizada</h4>
                                        <img src={memorizedAppearance.url} alt={`Aparência memorizada para ${image.name}`} className="w-full aspect-square object-cover rounded-md" />
                                        <button onClick={() => onClearAppearanceMemory(image.name!)} disabled={disabled} className="w-full text-xs p-1 bg-slate-600 hover:bg-red-500/80 rounded-md transition-colors">Esquecer</button>
                                    </div>
                                )}
                                <div className={`flex flex-col gap-1 transition-opacity ${!characterDetailsEnabled ? 'opacity-60' : ''}`}>
                                    {(image.personas || ['', '', '']).map((persona, index) => (
                                        <div key={index} className="relative">
                                            <input
                                                type="text"
                                                placeholder={`Persona ${index + 1}...`}
                                                value={persona}
                                                onChange={(e) => onImagePersonaChange(image.id, index, e.target.value)}
                                                disabled={disabled || !characterDetailsEnabled}
                                                title={!characterDetailsEnabled ? 'Habilite "Detalhes do Personagem" para editar' : ''}
                                                className="w-full text-xs p-1 bg-slate-700 border border-slate-600 rounded-md text-center text-slate-200 placeholder-slate-400 focus:ring-1 focus:ring-yellow-500 focus:border-yellow-500 pr-6 disabled:cursor-not-allowed"
                                            />
                                            <button
                                                onClick={() => handleTranslate(image.id, persona, index)}
                                                disabled={!persona.trim() || !!translatingId || disabled || !characterDetailsEnabled}
                                                className="absolute top-1/2 right-1 -translate-y-1/2 text-slate-400 hover:text-yellow-400 disabled:opacity-50 disabled:cursor-not-allowed"
                                                title="Traduzir para o inglês"
                                            >
                                                {translatingId === `${image.id}-persona-${index}` ? <Spinner className="h-4 w-4" /> : <TranslateIcon />}
                                            </button>
                                        </div>
                                    ))}
                                </div>
                                <div className="mt-1">
                                    <button
                                        onClick={() => handleDescribeAppearance(image)}
                                        disabled={disabled || !!describingId}
                                        className="w-full text-xs p-1.5 bg-slate-600 hover:bg-slate-500 text-slate-200 rounded-md flex items-center justify-center transition-colors disabled:opacity-50 disabled:cursor-wait"
                                    >
                                        {describingId === image.id ? <Spinner className="h-4 w-4" /> : <><DescribeIcon /> Descrever Aparência</>}
                                    </button>
                                </div>
                                {descriptions[image.id] && (
                                    <div className="p-2 bg-slate-900/50 rounded-md">
                                        <div className="flex justify-between items-center mb-1">
                                            <h4 className="text-xs font-semibold text-yellow-400">Descrição da Aparência</h4>
                                            <button onClick={() => setDescriptions(p => ({...p, [image.id]: ''}))} className="text-slate-500 hover:text-white" title="Fechar">&times;</button>
                                        </div>
                                        <textarea value={descriptions[image.id]} onChange={(e) => setDescriptions(p => ({ ...p, [image.id]: e.target.value }))} className="w-full h-24 p-1.5 text-xs bg-slate-700 border-slate-600 rounded-md text-slate-300 resize-none" />
                                        <div className="mt-1 flex space-x-2">
                                            <button onClick={() => navigator.clipboard.writeText(descriptions[image.id])} className="w-1/2 text-xs p-1 bg-slate-600 hover:bg-slate-500 rounded-md">Copiar</button>
                                            <button onClick={() => handleTranslateDescription(image.id, descriptions[image.id], 'appearance')} disabled={disabled || !!translatingDescriptionId} className="w-1/2 text-xs p-1 bg-slate-600 hover:bg-slate-500 rounded-md flex items-center justify-center"> {translatingDescriptionId === `${image.id}-appearance` ? <Spinner className="h-4 w-4" /> : <><TranslateIcon /> <span className="ml-1">Traduzir</span></>} </button>
                                        </div>
                                    </div>
                                )}
                                {/* Clothing Reference Section */}
                                <div className="mt-2 pt-2 border-t border-slate-700 space-y-2">
                                    <h4 className="text-xs font-semibold text-center text-slate-400">Roupa Casual (Referência)</h4>
                                    {image.clothingReference ? (
                                        <div className="space-y-2">
                                            <div className="relative aspect-square">
                                                <img src={image.clothingReference.dataUrl} alt="Clothing Reference" className="w-full h-full object-cover rounded-md" />
                                                <button onClick={() => onRemoveClothingReference(image.id, 'image')} className="absolute top-1 right-1 bg-black/50 text-white rounded-full p-0 w-5 h-5 flex items-center justify-center">&times;</button>
                                            </div>
                                            <button onClick={() => handleDescribeClothing(image.id, image.clothingReference!)} disabled={disabled || !!describingClothingId} className="w-full text-xs p-1.5 bg-slate-600 hover:bg-slate-500 rounded-md flex items-center justify-center">
                                                {describingClothingId === image.id ? <Spinner className="h-4 w-4" /> : 'Descrever Roupa'}
                                            </button>
                                        </div>
                                    ) : (
                                        <label htmlFor={`clothing-upload-${image.id}`} className={`group block w-full p-3 text-center border-2 border-dashed rounded-md transition-colors border-slate-600 ${disabled ? 'cursor-not-allowed opacity-50' : 'cursor-pointer hover:border-yellow-500 hover:bg-slate-800'}`}>
                                            <p className="text-[10px] text-slate-500 mb-2">Se não anexada, a IA usará a roupa da imagem principal.</p>
                                            <div className="inline-block text-xs px-4 py-1.5 bg-slate-700 group-hover:bg-slate-600 rounded-md text-slate-300 font-semibold">
                                                Carregar Roupa
                                            </div>
                                        </label>
                                    )}
                                     <input type="file" id={`clothing-upload-${image.id}`} className="hidden" accept="image/png, image/jpeg, image/webp" onChange={(e) => handleClothingReferenceUpload(e, image.id)} disabled={disabled} />
                                     {clothingDescriptions[image.id] && (
                                        <div className="p-2 bg-slate-900/50 rounded-md">
                                            <div className="flex justify-between items-center mb-1">
                                                <h4 className="text-xs font-semibold text-yellow-400">Descrição da Roupa</h4>
                                                <button onClick={() => setClothingDescriptions(p => ({...p, [image.id]: ''}))} className="text-slate-500 hover:text-white" title="Fechar">&times;</button>
                                            </div>
                                            <textarea value={clothingDescriptions[image.id]} onChange={(e) => setClothingDescriptions(p => ({ ...p, [image.id]: e.target.value }))} className="w-full h-24 p-1.5 text-xs bg-slate-700 border-slate-600 rounded-md text-slate-300 resize-none" />
                                            <div className="mt-1 flex space-x-2">
                                                <button onClick={() => navigator.clipboard.writeText(clothingDescriptions[image.id])} className="w-1/2 text-xs p-1 bg-slate-600 hover:bg-slate-500 rounded-md">Copiar</button>
                                                <button onClick={() => handleTranslateDescription(image.id, clothingDescriptions[image.id], 'clothing')} disabled={disabled || !!translatingDescriptionId} className="w-1/2 text-xs p-1 bg-slate-600 hover:bg-slate-500 rounded-md flex items-center justify-center"> {translatingDescriptionId === `${image.id}-clothing` ? <Spinner className="h-4 w-4" /> : <><TranslateIcon /> <span className="ml-1">Traduzir</span></>} </button>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        )})}
                         <label htmlFor="reference-images-input" className={`relative aspect-square flex items-center justify-center bg-slate-800 rounded-md border-2 border-dashed transition-colors ${disabled ? 'cursor-not-allowed opacity-50' : 'cursor-pointer border-slate-600 hover:border-yellow-500'}`}>
                            <span className="text-3xl font-light text-slate-500">+</span>
                        </label>
                    </div>
                )}
            </div>
             <input
                type="file"
                id="reference-images-input"
                className="hidden"
                onChange={handleFileChange}
                accept="image/png, image/jpeg, image/webp"
                disabled={disabled}
                multiple
            />
        </div>
    );
};

export default MultiImageUploader;