import React, { useState, useEffect, useRef } from 'react';
import { PanelOutput, ImageData, TextCharacter } from '../types';
import Spinner from './Spinner';

interface MediaDisplayProps {
    output: PanelOutput[][] | null;
    isLoading: boolean;
    loadingMessage: string;
    error: string | null;
    onCorrectText: (pageIndex: number, panelIndex: number) => void;
    onSetAppearanceMemory: (characterName: string, panel: PanelOutput) => void;
    onRedoPanel: (pageIndex: number, panelIndex: number) => void;
    onAnalyzeInconsistency: (pageIndex: number, panelIndex: number) => void;
    onViewFullPanel: (pageIndex: number, panelIndex: number) => void;
    onOpenEditModal: (pageIndex: number, panelIndex: number) => void;
    namedCharacters: (ImageData | TextCharacter)[];
}

const ViewFullIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5v-4m0 0h-4m4 0l-5-5" />
    </svg>
);

const RedoIcon = () => (
     <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h5M20 11A8.1 8.1 0 0012 4a8.1 8.1 0 00-7.058 11.942" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M20 20v-5h-5M4 13a8.1 8.1 0 008 8 8.1 8.1 0 007.058-11.942" />
    </svg>
);

const CorrectTextIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
    </svg>
);

const ClothingIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
      <path d="M17.707 3.293a1 1 0 00-1.414 0L15 4.586V3a1 1 0 00-1-1H6a1 1 0 00-1 1v1.586L3.707 3.293a1 1 0 00-1.414 1.414L3 5.414V17a1 1 0 001 1h12a1 1 0 001-1V5.414l.707-.707a1 1 0 000-1.414zM7 4h6v1H7V4z" />
    </svg>
);

const AnalyzeIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
    </svg>
);

const EditIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 6V4m0 16v-2m8-8h2M4 12H2m15.364 6.364l1.414 1.414M4.222 4.222l1.414 1.414m12.728 0l-1.414 1.414M5.636 18.364l-1.414 1.414M12 16a4 4 0 110-8 4 4 0 010 8z" />
    </svg>
);

const AppearanceMemoryManager: React.FC<{
    characters: (ImageData | TextCharacter)[];
    selectedPanel: PanelOutput | null;
    onSetMemory: (characterName: string, panel: PanelOutput) => void;
    isLoading: boolean;
}> = ({ characters, selectedPanel, onSetMemory, isLoading }) => {
    const [isOpen, setIsOpen] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleSelect = (charName: string) => {
        if (selectedPanel) {
            onSetMemory(charName, selectedPanel);
            setIsOpen(false);
        }
    };

    const isDisabled = !selectedPanel || isLoading || characters.length === 0;

    return (
        <div className="relative" ref={dropdownRef}>
            <button
                onClick={() => setIsOpen(prev => !prev)}
                disabled={isDisabled}
                className="inline-flex items-center px-4 py-2 bg-slate-600 hover:bg-slate-500 text-white rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                title={characters.length === 0 ? "Adicione e nomeie personagens para usar esta função." : undefined}
            >
                <ClothingIcon /> Lembrar Aparência
            </button>
            {isOpen && !isDisabled && (
                <div className="absolute bottom-full mb-2 w-56 bg-slate-700 border border-slate-600 rounded-md shadow-lg z-10">
                    <div className="p-2 text-xs text-slate-300 border-b border-slate-600">Lembrar para qual personagem?</div>
                    <ul className="py-1 max-h-48 overflow-y-auto">
                        {characters.map(char => (
                            <li key={char.id}>
                                <button
                                    onClick={() => handleSelect(char.name!)}
                                    className="w-full text-left px-3 py-1.5 text-sm text-slate-200 hover:bg-slate-600"
                                >
                                    {char.name}
                                </button>
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};


const MediaDisplay: React.FC<MediaDisplayProps> = ({ output, isLoading, loadingMessage, error, onCorrectText, onSetAppearanceMemory, onRedoPanel, onAnalyzeInconsistency, onViewFullPanel, onOpenEditModal, namedCharacters }) => {
    const [currentPage, setCurrentPage] = useState(0);
    const [selectedPanelIndex, setSelectedPanelIndex] = useState<number | null>(null);
    const pageRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        // Reset to first page and clear selection when new output is generated
        setCurrentPage(0);
        setSelectedPanelIndex(null);
    }, [output]);

    useEffect(() => {
        // Clear selection when page changes
        setSelectedPanelIndex(null);
    }, [currentPage]);

    const WelcomeScreen = () => (
        <div className="text-center text-slate-400">
            <h2 className="text-3xl font-bold text-slate-200 mb-4">Bem-vindo ao Nano Banana Comics</h2>
            <p className="max-w-md mx-auto">
                Descreva sua cena, defina o estilo do artista e configure seus painéis à esquerda. Vamos criar um mangá!
            </p>
        </div>
    );
    
    const LoadingScreen = () => (
        <div className="text-center">
            <Spinner />
            <p className="mt-4 text-lg font-semibold text-slate-300 animate-pulse">{loadingMessage || 'Processando...'}</p>
        </div>
    );

    const getGridClasses = (panelCount: number) => {
        switch(panelCount) {
            case 1: return 'grid-cols-1 grid-rows-1';
            case 2: return 'grid-cols-1 grid-rows-2';
            case 3: return 'grid-cols-1 grid-rows-3';
            case 4: return 'grid-cols-2 grid-rows-2';
            case 5: case 6: return 'grid-cols-2 grid-rows-3';
            case 7: case 8: case 9: return 'grid-cols-3 grid-rows-3';
            default: return 'grid-cols-2 grid-rows-2';
        }
    };

    const pageToDisplay = output?.[currentPage];
    const selectedPanel = (selectedPanelIndex !== null && pageToDisplay) ? pageToDisplay[selectedPanelIndex] : null;

    return (
        <div className="bg-slate-800/50 rounded-lg shadow-lg w-full h-full flex flex-col items-center justify-center p-4 min-h-[400px] lg:min-h-0">
            {isLoading ? <LoadingScreen /> :
             error ? <p className="text-red-400 text-center">{error}</p> :
             !output ? <WelcomeScreen /> :
             (
                <div className="w-full h-full flex flex-col items-center space-y-4">
                    {/* Page Content Wrapper: Allows content to shrink and prevents overflow */}
                    <div className="flex-grow w-full flex items-center justify-center min-h-0">
                        {/* Page Content: Constrained by wrapper, maintaining aspect ratio */}
                        <div className="w-full max-w-[80vh] aspect-[2/3] bg-slate-900/50 p-2">
                            <div
                                ref={pageRef}
                                className={`grid ${getGridClasses(pageToDisplay.length)} gap-2 h-full w-full`}
                            >
                                {pageToDisplay.map((panel, idx) => (
                                    <div 
                                        key={idx} 
                                        className={`relative cursor-pointer transition-all duration-200 rounded-sm overflow-hidden ${selectedPanelIndex === idx ? 'ring-2 ring-yellow-400 shadow-lg' : 'ring-0 ring-transparent'}`}
                                        onClick={() => setSelectedPanelIndex(idx)}
                                    >
                                        <img src={panel.url} alt={`Painel ${idx + 1}`} className="w-full h-full object-contain bg-white" />
                                        {selectedPanelIndex === idx && (
                                            <div className="absolute inset-0 bg-black/50 flex items-center justify-center pointer-events-none">
                                                <span className="text-white font-bold text-lg bg-black/70 px-4 py-2 rounded">Selecionado</span>
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                    {/* Controls: Prevents shrinking */}
                    <div className="flex-shrink-0 flex items-center space-x-4">
                         {output.length > 1 && (
                            <>
                                <button onClick={() => setCurrentPage(p => Math.max(0, p - 1))} disabled={currentPage === 0} className="px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded disabled:opacity-50">{'< Ant'}</button>
                                <span className="font-semibold">{`Página ${currentPage + 1} de ${output.length}`}</span>
                                <button onClick={() => setCurrentPage(p => Math.min(output.length - 1, p + 1))} disabled={currentPage === output.length - 1} className="px-4 py-2 bg-slate-700 hover:bg-slate-600 rounded disabled:opacity-50">{'Próx >'}</button>
                            </>
                        )}
                        <button 
                            onClick={() => onViewFullPanel(currentPage, selectedPanelIndex!)}
                            disabled={selectedPanelIndex === null}
                            className="inline-flex items-center px-4 py-2 bg-yellow-600 hover:bg-yellow-700 text-white rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                           <ViewFullIcon /> Ver Painel Completo
                        </button>
                        <button
                            onClick={() => onRedoPanel(currentPage, selectedPanelIndex!)}
                            disabled={selectedPanelIndex === null || isLoading}
                            className="inline-flex items-center px-4 py-2 bg-slate-600 hover:bg-slate-500 text-white rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            <RedoIcon /> Refazer
                        </button>
                        <button
                            onClick={() => onAnalyzeInconsistency(currentPage, selectedPanelIndex!)}
                            disabled={selectedPanelIndex === null || isLoading}
                            className="inline-flex items-center px-4 py-2 bg-slate-600 hover:bg-slate-500 text-white rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            <AnalyzeIcon /> Analisar Incoerência
                        </button>
                        <AppearanceMemoryManager
                            characters={namedCharacters}
                            selectedPanel={selectedPanel}
                            onSetMemory={onSetAppearanceMemory}
                            isLoading={isLoading}
                        />
                        <button 
                            onClick={() => onCorrectText(currentPage, selectedPanelIndex!)}
                            disabled={selectedPanelIndex === null}
                            className="inline-flex items-center px-4 py-2 bg-slate-600 hover:bg-slate-500 text-white rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            <CorrectTextIcon /> Corrigir Texto
                        </button>
                         <button
                            onClick={() => onOpenEditModal(currentPage, selectedPanelIndex!)}
                            disabled={selectedPanelIndex === null || isLoading}
                            className="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            <EditIcon /> Editar Painel
                        </button>
                    </div>
                </div>
             )
            }
        </div>
    );
};

export default MediaDisplay;