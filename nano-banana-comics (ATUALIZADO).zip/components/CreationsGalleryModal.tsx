import React from 'react';
import { Creation } from '../types';
import Modal from './Modal';

interface CreationsGalleryModalProps {
    creations: Creation[];
    onClose: () => void;
    onReload: (creation: Creation) => void;
    onDelete: (id: number) => void;
}

const ReloadIcon = () => (
     <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h5M20 11A8.1 8.1 0 0012 4a8.1 8.1 0 00-7.058 11.942" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M20 20v-5h-5M4 13a8.1 8.1 0 008 8 8.1 8.1 0 007.058-11.942" />
    </svg>
);

const DeleteIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
    </svg>
);

const CreationsGalleryModal: React.FC<CreationsGalleryModalProps> = ({ creations, onClose, onReload, onDelete }) => {
    return (
        <Modal title="Minhas Criações" onClose={onClose} size="5xl">
            {creations.length === 0 ? (
                <p className="text-center text-slate-400">Suas criações aparecerão aqui assim que você criar algo.</p>
            ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                    {creations.map((creation) => {
                        const thumbnailUrl = creation.output?.[0]?.[0]?.url;
                        // FIX: The 'Creation' type no longer has a top-level 'prompt'.
                        // Use the prompt from the first panel config, or the comic title as a fallback.
                        const displayPrompt = creation.panelConfigs?.[0]?.prompt || creation.comicTitle || '';
                        return (
                            <div key={creation.id} className="group relative aspect-[2/3] bg-slate-700 rounded-lg overflow-hidden">
                                {thumbnailUrl && (
                                    <img src={thumbnailUrl} alt={displayPrompt} className="w-full h-full object-cover" />
                                )}
                                <div className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-between p-3">
                                    <p className="text-xs text-white line-clamp-4">{displayPrompt}</p>
                                    <div className="flex justify-end space-x-2">
                                        <button onClick={() => onReload(creation)} className="p-2 bg-slate-600 hover:bg-slate-500 rounded-full text-white transition-colors" title="Recarregar Criação"><ReloadIcon /></button>
                                        <button onClick={() => onDelete(creation.id!)} className="p-2 bg-red-600 hover:bg-red-500 rounded-full text-white transition-colors" title="Excluir Criação"><DeleteIcon /></button>
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}
        </Modal>
    );
};

export default CreationsGalleryModal;
