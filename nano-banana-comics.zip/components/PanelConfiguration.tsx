







import React, { useState } from 'react';
import { PanelConfig, CameraFraming, ImageData, ContentContext, Atmosphere, AppState, TextCharacter, CharacterEmotion, SpeechBalloonType } from '../types';
import { CAMERA_FRAMING_OPTIONS, CAMERA_FRAMING_MAP, CHARACTER_EMOTION_OPTIONS, CHARACTER_EMOTION_MAP, SPEECH_BALLOON_OPTIONS, SPEECH_BALLOON_MAP } from '../constants';
import { fileToBase64 } from '../utils';
import * as geminiService from '../services/geminiService';
import Spinner from './Spinner';

interface PanelConfigurationProps {
    configs: PanelConfig[];
    referenceImages: ImageData[];
    textCharacters: TextCharacter[];
    genre: string;
    onConfigChange: (index: number, newConfig: PanelConfig) => void;
    onAddPanel: () => void;
    onRemovePanel: (index: number) => void;
    onSplitPanel: (index: number, direction: 'Split Horizontally' | 'Split Vertically') => void;
    onTranslatePanel: (text: string, panelIndex: number) => void;
    onDetailPanel: (panelIndex: number) => void;
    onOpenPromptEditor: (panelIndex: number) => void;
    onOpenPromptHelper: (panelIndex: number) => void;
    isLoading: boolean;
    useGlobalScenario: boolean;
    onStateChange: <K extends keyof AppState>(key: K, value: AppState[K]) => void;
}

const AddIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
    </svg>
);

const RemoveIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
);

const TranslateIcon = () => ( <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}> <path strokeLinecap="round" strokeLinejoin="round" d="M3 5h12M9 3v2m4 13l4-4M19 17l-4-4M3 19h12a2 2 0 002-2V7a2 2 0 00-2-2H3a2 2 0 00-2 2v10a2 2 0 002 2z" /> </svg> );
const DetailIcon = () => ( <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}> <path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L15.232 5.232z" /> <path strokeLinecap="round" strokeLinejoin="round" d="M19 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h6" /> </svg> );
const ExpandIcon = () => ( <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}> <path strokeLinecap="round" strokeLinejoin="round" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5v-4m0 0h-4m4 0l-5-5" /> </svg> );

const SmallTranslateIcon = () => ( <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}> <path strokeLinecap="round" strokeLinejoin="round" d="M3 5h12M9 3v2m4 13l4-4M19 17l-4-4M3 19h12a2 2 0 002-2V7a2 2 0 00-2-2H3a2 2 0 00-2 2v10a2 2 0 002 2z" /> </svg> );
const SmallDetailIcon = () => ( <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}> <path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L15.232 5.232z" /> </svg> );

const DescribeIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
    </svg>
);

interface SelectProps<T extends string> extends React.SelectHTMLAttributes<HTMLSelectElement> {
    label: string;
    value: T;
    onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
    options: readonly T[];
    translations?: { [key in T]?: string };
}

const SelectControl = <T extends string>({label, value, onChange, options, translations, ...rest}: SelectProps<T>) => (
    <div>
        <label htmlFor={`${label}-select`} className="text-sm font-medium text-slate-300 block mb-1">
            {label}
        </label>
        <select
            id={`${label}-select`}
            value={value}
            onChange={onChange}
            className="w-full p-2 text-sm bg-slate-700 border border-slate-600 rounded-md focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
            {...rest}
        >
            {options.map(option => (
                <option key={option} value={option}>
                    {translations && translations[option] ? translations[option] : option}
                </option>
            ))}
        </select>
    </div>
);


const PanelConfiguration: React.FC<PanelConfigurationProps> = (props) => {
    const { configs, referenceImages, textCharacters, genre, onConfigChange, onAddPanel, onRemovePanel, onSplitPanel, onTranslatePanel, onDetailPanel, onOpenPromptEditor, onOpenPromptHelper, isLoading, useGlobalScenario, onStateChange } = props;
    const [translatingExtras, setTranslatingExtras] = useState<number | null>(null);
    const [detailingExtras, setDetailingExtras] = useState<number | null>(null);
    const [translatingScenario, setTranslatingScenario] = useState<number | null>(null);
    const [detailingScenario, setDetailingScenario] = useState<number | null>(null);
    const [loadingAction, setLoadingAction] = useState<string | null>(null);
    const [imageDescriptions, setImageDescriptions] = useState<Record<string, string>>({});
    const [describingImageId, setDescribingImageId] = useState<string | null>(null);
    const [descriptionError, setDescriptionError] = useState<string | null>(null);
    const [translatingDescriptionId, setTranslatingDescriptionId] = useState<string | null>(null);

    const namedCharacters = (referenceImages.length > 0 ? referenceImages : textCharacters)
        .filter(char => char.name && char.name.trim() !== '');

    const handleTranslateExtrasBehavior = async (panelIndex: number) => {
        const textToTranslate = configs[panelIndex].extrasBehavior;
        if (!textToTranslate || isLoading || translatingExtras !== null) return;

        setTranslatingExtras(panelIndex);
        try {
            const namedCharacterNames = namedCharacters.map(c => c.name).filter((n): n is string => !!n);
            const translatedText = await geminiService.translateText(textToTranslate, namedCharacterNames);
            const currentConfig = configs[panelIndex];
            onConfigChange(panelIndex, { ...currentConfig, extrasBehavior: translatedText });
        } catch (error) {
            console.error("Failed to translate extras behavior:", error);
        } finally {
            setTranslatingExtras(null);
        }
    };

    const handleDetailExtrasBehavior = async (panelIndex: number) => {
        const config = configs[panelIndex];
        const behaviorText = config.extrasBehavior;
        const sceneContext = config.prompt;
        if (!behaviorText || !sceneContext || isLoading || detailingExtras !== null) return;

        setDetailingExtras(panelIndex);
        try {
            const detailedText = await geminiService.detailExtrasBehavior(behaviorText, sceneContext);
            onConfigChange(panelIndex, { ...config, extrasBehavior: detailedText });
        } catch (error) {
            console.error("Failed to detail extras behavior:", error);
        } finally {
            setDetailingExtras(null);
        }
    };

    const handleTranslateScenario = async (panelIndex: number) => {
        const textToTranslate = configs[panelIndex].scenarioDescription;
        if (!textToTranslate || isLoading || translatingScenario !== null) return;

        setTranslatingScenario(panelIndex);
        try {
            const namedCharacterNames = namedCharacters.map(c => c.name).filter((n): n is string => !!n);
            const translatedText = await geminiService.translateText(textToTranslate, namedCharacterNames);
            const currentConfig = configs[panelIndex];
            onConfigChange(panelIndex, { ...currentConfig, scenarioDescription: translatedText });
        } catch (error) {
            console.error("Failed to translate scenario description:", error);
        } finally {
            setTranslatingScenario(null);
        }
    };

    const handleDetailScenario = async (panelIndex: number) => {
        const textToDetail = configs[panelIndex].scenarioDescription;
        if (!textToDetail || isLoading || detailingScenario !== null) return;

        setDetailingScenario(panelIndex);
        try {
            const detailedText = await geminiService.detailScenario(textToDetail);
            const currentConfig = configs[panelIndex];
            onConfigChange(panelIndex, { ...currentConfig, scenarioDescription: detailedText });
        } catch (error) {
            console.error("Failed to detail scenario description:", error);
        } finally {
            setDetailingScenario(null);
        }
    };

    const handleTranslateCharacterField = async (panelIndex: number, charName: string, field: 'dialogue' | 'behavior', text: string) => {
        if (!text || loadingAction) return;
        const uniqueId = `${panelIndex}-${charName}-${field}-translate`;
        setLoadingAction(uniqueId);
        try {
            const namedCharacterNames = namedCharacters.map(c => c.name).filter((n): n is string => !!n);
            const translatedText = await geminiService.translateText(text, namedCharacterNames);
            const currentConfig = configs[panelIndex];
            if (field === 'dialogue') {
                const newDialogues = {...(currentConfig.characterDialogues || {}), [charName]: translatedText };
                onConfigChange(panelIndex, { ...currentConfig, characterDialogues: newDialogues });
            } else {
                const newBehaviors = {...(currentConfig.characterBehaviors || {}), [charName]: translatedText };
                onConfigChange(panelIndex, { ...currentConfig, characterBehaviors: newBehaviors });
            }
        } catch (error) {
            console.error(`Failed to translate ${field}`, error);
        } finally {
            setLoadingAction(null);
        }
    };

    const handleDetailCharacterField = async (panelIndex: number, character: (ImageData | TextCharacter), field: 'dialogue' | 'behavior') => {
        const config = configs[panelIndex];
        const sceneContext = config.prompt;
        if (!sceneContext || !character.name || loadingAction) return;

        const text = field === 'dialogue' ? config.characterDialogues?.[character.name] : config.characterBehaviors?.[character.name];
        if (!text) return;

        const uniqueId = `${panelIndex}-${character.id}-${field}-detail`;
        setLoadingAction(uniqueId);
        try {
            if (field === 'dialogue') {
                const personas = (character.personas || []).filter(p => p.trim());
                const detailedText = await geminiService.detailCharacterDialogue(text, personas, sceneContext);
                const newDialogues = {...(config.characterDialogues || {}), [character.name]: detailedText };
                onConfigChange(panelIndex, { ...config, characterDialogues: newDialogues });
            } else {
                const detailedText = await geminiService.detailCharacterBehavior(text, sceneContext);
                const newBehaviors = {...(config.characterBehaviors || {}), [character.name]: detailedText };
                onConfigChange(panelIndex, { ...config, characterBehaviors: newBehaviors });
            }
        } catch (error) {
            console.error(`Failed to detail ${field}`, error);
        } finally {
            setLoadingAction(null);
        }
    };

    const handleDescribeImage = async (image: ImageData) => {
        setDescribingImageId(image.id);
        setDescriptionError(null);
        try {
            const description = await geminiService.describeScenarioOrObject(image.dataUrl.split(',')[1], image.mimeType);
            setImageDescriptions(prev => ({...prev, [image.id]: description}));
        } catch (error: any) {
            console.error("Failed to describe image", error);
            const errorMessage = error?.message || 'Falha ao descrever a imagem.';
            setDescriptionError(errorMessage);
        } finally {
            setDescribingImageId(null);
        }
    };
    
    const handleTranslateDescription = async (id: string, text: string) => {
        if (!text || translatingDescriptionId) return;
        setTranslatingDescriptionId(id);
        try {
            const translatedText = await geminiService.translateText(text, []);
            setImageDescriptions(prev => ({...prev, [id]: translatedText}));
        } catch (error) {
            console.error(`Translation for description ${id} failed`, error);
        } finally {
            setTranslatingDescriptionId(null);
        }
    };


    const handleCharacterExclusionChange = (panelIndex: number, characterName: string, isExcluded: boolean) => {
        const currentConfig = configs[panelIndex];
        const currentExclusions = currentConfig.excludedCharacters || [];
        const newExclusions = isExcluded
            ? [...currentExclusions, characterName]
            : currentExclusions.filter(name => name !== characterName);
        onConfigChange(panelIndex, { ...currentConfig, excludedCharacters: newExclusions });
    };

    const handleScenarioImageUpload = async (panelIndex: number, file: File) => {
        const imageData = await fileToBase64(file);
        const currentConfig = configs[panelIndex];
        onConfigChange(panelIndex, { ...currentConfig, scenarioImage: imageData });
    };
    
    const handleObjectImagesUpload = async (panelIndex: number, files: FileList) => {
        const newImages = await Promise.all(
            Array.from(files).map(file => fileToBase64(file))
        );
        const currentConfig = configs[panelIndex];
        const existingObjects = currentConfig.objectImages || [];
        onConfigChange(panelIndex, { ...currentConfig, objectImages: [...existingObjects, ...newImages] });
    };

    const handleImageClear = (panelIndex: number, imageId: string, type: 'scenario' | 'object') => {
        const currentConfig = configs[panelIndex];
        if (type === 'scenario') {
            onConfigChange(panelIndex, { ...currentConfig, scenarioImage: undefined });
        } else {
            const newObjects = (currentConfig.objectImages || []).filter(img => img.id !== imageId);
            onConfigChange(panelIndex, { ...currentConfig, objectImages: newObjects });
        }
    };

    const getContentContextOptions = (currentGenre: string): ContentContext[] => {
        const baseOptions: ContentContext[] = ['Automatic', 'None', 'Intense Action/Battle', 'School Uniform', 'Casual Wear', 'Gym Clothes', 'Pajamas', 'Kimono', 'Summer Clothes', 'Adventure Gear', 'Camping Outfit', 'Rain Gear', 'Winter Clothes', 'One-Piece Swimsuit', 'Two-Piece Swimsuit', 'Tropical Beachwear', 'Yukata', 'Sports Uniform', 'Christmas Outfit', 'Travel Outfit', 'Party Outfit'];
        if (currentGenre === 'Mahou Shoujo') {
            return [...baseOptions, 'Mahou Shoujo Outfit'];
        }
        if (currentGenre === 'Superhero') {
            return [...baseOptions, 'Superhero Costume'];
        }
        return baseOptions;
    };

    const getAtmosphereOptions = (genre: string, contentContext: ContentContext): Atmosphere[] => {
        const options: Atmosphere[] = ['Automatic', 'None'];

        switch (genre) {
            case 'Horror':
            case 'Thriller':
            case 'Psychological':
                options.push('Tension', 'Somber', 'Mysterious', 'Dark', 'Intimate');
                break;
            case 'Action':
            case 'Superhero':
            case 'Martial Arts':
            case 'Mecha':
                if (contentContext === 'Intense Action/Battle') {
                    options.push('Chaos');
                }
                options.push('Tension', 'Energetic', 'Epic', 'Dark', 'Romantic');
                break;
            case 'Romance':
                options.push('Romantic', 'Peaceful', 'Somber', 'Intimate');
                break;
            case 'Fantasy':
            case 'Mystery':
                options.push('Mysterious', 'Somber', 'Tension', 'Peaceful', 'Epic', 'Dark');
                break;
            case 'Slice of Life':
            case 'Comedy':
                options.push('Peaceful', 'Energetic', 'Romantic', 'Playful', 'Intimate', 'Somber');
                break;
            case 'Sports':
            case 'Music':
                options.push('Energetic', 'Tension', 'Epic');
                break;
            case 'Drama':
                options.push('Somber', 'Tension', 'Romantic', 'Peaceful', 'Intimate');
                break;
            default:
                 options.push('Energetic', 'Peaceful', 'Tension', 'Mysterious', 'Epic', 'Romantic');
                break;
        }
        return [...new Set(options)];
    };

    React.useEffect(() => {
        configs.forEach((config, index) => {
            const validAtmosphereOptions = getAtmosphereOptions(genre, config.contentContext);
            if (!validAtmosphereOptions.includes(config.atmosphere)) {
                onConfigChange(index, { ...config, atmosphere: 'Automatic' });
            }
        });
        // This effect depends on configs, which is complex. Disabling exhaustive-deps
        // to prevent potential infinite loops if parent doesn't memoize props correctly.
        // The logic will still run on every relevant re-render.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [genre, configs]);


    const contentContextOptions = getContentContextOptions(genre);
    
    const translations = {
        panelSize: {
            'Automatic': 'Automático',
            'Standard': 'Padrão',
            'Tall': 'Alto',
            'Wide': 'Largo',
            'Small Square': 'Quadrado Pequeno',
            'Split Horizontally': 'Dividir em 2 (Horizontal)',
            'Split Vertically': 'Dividir em 2 (Vertical)',
        },
        characterAngle: {
            'Automatic': 'Automático',
            'Front-facing': 'De frente',
            'From behind': 'De costas',
            'Side view': 'De lado'
        },
        detailLevel: {
            'Automatic': 'Automático',
            'Medium': 'Médio',
            'Low': 'Baixo',
            'High': 'Alto'
        },
        extrasCount: {
            'Automatic': 'Automático',
            'None': 'Nenhum',
            'A few (1-3)': 'Poucos (1-3)',
            'A small crowd (4-10)': 'Grupo pequeno (4-10)'
        },
        contentContext: {
            'Automatic': 'Automático',
            'None': 'Nenhum',
            'Intense Action/Battle': 'Ação Intensa/Batalha',
            'School Uniform': 'Uniforme Escolar',
            'Casual Wear': 'Roupas Casuais',
            'Gym Clothes': 'Roupas de Ginástica',
            'Pajamas': 'Pijamas',
            'Kimono': 'Kimono',
            'Mahou Shoujo Outfit': 'Roupa Mahou Shoujo',
            'Superhero Costume': 'Traje de Super-herói',
            'Summer Clothes': 'Roupas de Verão',
            'Adventure Gear': 'Traje de Aventura',
            'Camping Outfit': 'Roupa de Acampamento',
            'Rain Gear': 'Roupas de Chuva',
            'Winter Clothes': 'Roupas de Inverno',
            'One-Piece Swimsuit': 'Roupas de banho (Maiô)',
            'Two-Piece Swimsuit': 'Roupas de banho (Biquíni)',
            'Tropical Beachwear': 'Roupas de Praia (Tropical)',
            'Yukata': 'Yukata',
            'Sports Uniform': 'Uniforme Esportivo',
            'Christmas Outfit': 'Roupas de Natal',
            'Travel Outfit': 'Roupa de Viagem',
            'Party Outfit': 'Roupa de Festa'
        },
        atmosphere: {
            'Automatic': 'Automático',
            'None': 'Nenhum',
            'Tension': 'Tensão',
            'Chaos': 'Caos',
            'Romantic': 'Romântico',
            'Peaceful': 'Pacífico',
            'Mysterious': 'Misterioso',
            'Somber': 'Melancólico',
            'Energetic': 'Energético',
            'Dark': 'Sombrio',
            'Playful': 'Lúdico',
            'Epic': 'Épico',
            'Intimate': 'Intimista'
        }
    };


    return (
        <div className="space-y-3">
             <h3 className="text-md font-semibold text-slate-200 border-b border-slate-700 pb-2">Controles Específicos do Painel</h3>
             {descriptionError && <p className="text-xs text-red-400 mt-1">{descriptionError}</p>}
             <div className="space-y-4 max-h-[calc(100vh-600px)] min-h-[200px] overflow-y-auto pr-2">
                {configs.map((config, index) => (
                    <div key={index} className="p-3 bg-slate-900/50 rounded-md space-y-4 relative">
                        {configs.length > 1 && (
                            <button 
                                onClick={() => onRemovePanel(index)}
                                className="absolute top-2.5 right-2.5 p-1 text-slate-500 hover:text-red-400 rounded-full hover:bg-slate-700 transition-colors"
                                title="Remover Painel"
                            >
                                <RemoveIcon />
                            </button>
                        )}
                         <div className="flex items-center justify-between">
                            <h4 className="text-sm font-bold text-slate-300">Painel {index + 1}</h4>
                         </div>
                        
                        {/* Scenario Section */}
                        <div className="space-y-3">
                            <div className="flex items-center justify-between">
                                <label className="text-sm font-medium text-slate-300">
                                    Cenário e Objetos
                                </label>
                                {index === 0 && (
                                    <div className="flex items-center space-x-3">
                                        <input
                                            type="checkbox"
                                            id="master-scenario-toggle"
                                            checked={useGlobalScenario}
                                            onChange={(e) => onStateChange('useGlobalScenario', e.target.checked)}
                                            disabled={isLoading}
                                            className="w-4 h-4 text-yellow-600 bg-slate-700 border-slate-600 rounded focus:ring-yellow-500"
                                        />
                                        <label htmlFor="master-scenario-toggle" className="text-sm font-medium text-slate-300"> Cenário Mestre </label>
                                    </div>
                                )}
                            </div>

                            {(useGlobalScenario && index > 0) ? (
                                <div className="text-xs p-2 bg-slate-800 border border-slate-700 rounded-md text-slate-400 text-center">
                                    Cenário Mestre está ativo. A configuração do Painel 1 será usada. Objetos ainda podem ser adicionados a este painel.
                                </div>
                            ) : (
                                <div>
                                    <textarea
                                        id={`scenario-desc-${index}`}
                                        value={config.scenarioDescription || ''}
                                        onChange={(e) => onConfigChange(index, { ...config, scenarioDescription: e.target.value })}
                                        placeholder={useGlobalScenario && index === 0 ? "Descreva o ambiente principal para toda a história..." : `Descreva o ambiente para este painel...`}
                                        className="w-full h-20 p-2 bg-slate-700 border border-slate-600 rounded-md focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
                                        disabled={isLoading}
                                    />
                                    <div className="flex items-center space-x-3 mt-1">
                                    <button onClick={() => handleDetailScenario(index)} disabled={isLoading || detailingScenario === index || !config.scenarioDescription} className="flex items-center text-xs text-yellow-400 hover:text-yellow-300 font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed" title="Detalhar Cenário com IA">
                                        {detailingScenario === index ? <Spinner className="h-4 w-4" /> : <><DetailIcon /> <span className="ml-1">Detalhar</span></>}
                                    </button>
                                    <button onClick={() => handleTranslateScenario(index)} disabled={isLoading || translatingScenario === index || !config.scenarioDescription} className="flex items-center text-xs text-yellow-400 hover:text-yellow-300 font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed" title="Traduzir para o inglês">
                                        {translatingScenario === index ? <Spinner className="h-4 w-4" /> : <><TranslateIcon /> <span className="ml-1">Traduzir para o inglês</span></>}
                                    </button>
                                </div>
                                </div>
                            )}

                            {/* Image Uploaders */}
                            { !config.scenarioDescription && (
                                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div className={`transition-opacity ${(useGlobalScenario && index > 0) ? 'opacity-50' : ''}`}>
                                        <h5 className="text-xs font-semibold text-slate-400 mb-2">Imagem de Fundo (1 máx)</h5>
                                        {config.scenarioImage ? (
                                            <div className="flex flex-col gap-1">
                                                <div className="relative w-full aspect-video">
                                                    <img src={config.scenarioImage.dataUrl} alt="Scenario" className="w-full h-full object-cover rounded-md" />
                                                    <button onClick={() => handleImageClear(index, config.scenarioImage!.id, 'scenario')} disabled={isLoading} title="Remover imagem de cenário" className="absolute top-1 right-1 bg-black/50 text-white rounded-full p-0 w-5 h-5 flex items-center justify-center leading-none text-md hover:bg-black/75">&times;</button>
                                                    <button onClick={() => handleDescribeImage(config.scenarioImage!)} disabled={isLoading || !!describingImageId} className="absolute bottom-1 right-1 text-xs p-1 bg-slate-800/70 hover:bg-slate-700/90 text-slate-200 rounded-md flex items-center justify-center transition-colors disabled:opacity-50 disabled:cursor-wait">
                                                        {describingImageId === config.scenarioImage!.id ? <Spinner className="h-4 w-4"/> : <DescribeIcon />}
                                                    </button>
                                                </div>
                                                {imageDescriptions[config.scenarioImage.id] && (
                                                    <div className="mt-1 p-2 bg-slate-900/50 rounded-md">
                                                        <div className="flex justify-between items-center mb-1">
                                                            <h4 className="text-xs font-semibold text-yellow-400">Descrição da IA</h4>
                                                            <button
                                                                onClick={() => {
                                                                    const newDescriptions = {...imageDescriptions};
                                                                    delete newDescriptions[config.scenarioImage!.id];
                                                                    setImageDescriptions(newDescriptions);
                                                                }}
                                                                className="text-slate-500 hover:text-white"
                                                                title="Fechar descrição"
                                                            >
                                                                &times;
                                                            </button>
                                                        </div>
                                                        <textarea
                                                            value={imageDescriptions[config.scenarioImage.id]}
                                                            onChange={(e) => setImageDescriptions(prev => ({ ...prev, [config.scenarioImage!.id]: e.target.value }))}
                                                            className="w-full h-24 p-1.5 text-xs bg-slate-700 border-slate-600 rounded-md text-slate-300 resize-none"
                                                        />
                                                        <div className="mt-1 flex space-x-2">
                                                            <button
                                                                onClick={() => navigator.clipboard.writeText(imageDescriptions[config.scenarioImage!.id])}
                                                                className="w-1/2 text-xs p-1 bg-slate-600 hover:bg-slate-500 rounded-md transition-colors"
                                                            >
                                                                Copiar Texto
                                                            </button>
                                                            <button
                                                                onClick={() => handleTranslateDescription(config.scenarioImage!.id, imageDescriptions[config.scenarioImage!.id])}
                                                                disabled={isLoading || !!translatingDescriptionId || !imageDescriptions[config.scenarioImage!.id]?.trim()}
                                                                className="w-1/2 text-xs p-1 bg-slate-600 hover:bg-slate-500 text-slate-200 rounded-md flex items-center justify-center transition-colors disabled:opacity-50 disabled:cursor-wait"
                                                            >
                                                                {translatingDescriptionId === config.scenarioImage!.id ? <Spinner className="h-4 w-4" /> : <><TranslateIcon /> <span className="ml-1">Traduzir para o inglês</span></>}
                                                            </button>
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                        ) : (
                                            <label htmlFor={`scenario-upload-${index}`} className={`flex items-center justify-center w-full h-full aspect-video border-2 border-dashed border-slate-600 rounded-md text-xs text-slate-400 transition-colors ${(isLoading || (useGlobalScenario && index > 0)) ? 'cursor-not-allowed opacity-50' : 'cursor-pointer hover:border-yellow-500 hover:bg-slate-800'}`}> Adicionar Fundo </label>
                                        )}
                                        <input id={`scenario-upload-${index}`} type="file" className="hidden" accept="image/png, image/jpeg, image/webp" disabled={isLoading || (useGlobalScenario && index > 0)} onChange={(e) => { if (e.target.files && e.target.files[0]) { handleScenarioImageUpload(index, e.target.files[0]); } e.target.value = ''; }} />
                                    </div>
                                    <div>
                                        <h5 className="text-xs font-semibold text-slate-400 mb-2">Objetos de Cena (múltiplos)</h5>
                                        <div className="grid grid-cols-2 gap-2">
                                            {(config.objectImages || []).map(obj => (
                                                <div key={obj.id} className="flex flex-col gap-1">
                                                    <div className="relative w-full aspect-square">
                                                        <img src={obj.dataUrl} alt="Object" className="w-full h-full object-cover rounded-md" />
                                                        <button onClick={() => handleImageClear(index, obj.id, 'object')} disabled={isLoading} title="Remover objeto" className="absolute top-1 right-1 bg-black/50 text-white rounded-full p-0 w-5 h-5 flex items-center justify-center leading-none text-md hover:bg-black/75">&times;</button>
                                                        <button onClick={() => handleDescribeImage(obj)} disabled={isLoading || !!describingImageId} className="absolute bottom-1 right-1 text-xs p-1 bg-slate-800/70 hover:bg-slate-700/90 text-slate-200 rounded-md flex items-center justify-center transition-colors disabled:opacity-50 disabled:cursor-wait">
                                                            {describingImageId === obj.id ? <Spinner className="h-4 w-4"/> : <DescribeIcon />}
                                                        </button>
                                                    </div>
                                                    {imageDescriptions[obj.id] && (
                                                        <div className="mt-1 p-2 bg-slate-900/50 rounded-md">
                                                            <div className="flex justify-between items-center mb-1">
                                                                <h4 className="text-xs font-semibold text-yellow-400">Descrição da IA</h4>
                                                                <button
                                                                    onClick={() => {
                                                                        const newDescriptions = {...imageDescriptions};
                                                                        delete newDescriptions[obj.id];
                                                                        setImageDescriptions(newDescriptions);
                                                                    }}
                                                                    className="text-slate-500 hover:text-white"
                                                                    title="Fechar descrição"
                                                                >
                                                                    &times;
                                                                </button>
                                                            </div>
                                                            <textarea
                                                                value={imageDescriptions[obj.id]}
                                                                onChange={(e) => setImageDescriptions(prev => ({ ...prev, [obj.id]: e.target.value }))}
                                                                className="w-full h-24 p-1.5 text-xs bg-slate-700 border-slate-600 rounded-md text-slate-300 resize-none"
                                                            />
                                                            <div className="mt-1 flex space-x-2">
                                                                <button
                                                                    onClick={() => navigator.clipboard.writeText(imageDescriptions[obj.id])}
                                                                    className="w-1/2 text-xs p-1 bg-slate-600 hover:bg-slate-500 rounded-md transition-colors"
                                                                >
                                                                    Copiar Texto
                                                                </button>
                                                                <button
                                                                    onClick={() => handleTranslateDescription(obj.id, imageDescriptions[obj.id])}
                                                                    disabled={isLoading || !!translatingDescriptionId || !imageDescriptions[obj.id]?.trim()}
                                                                    className="w-1/2 text-xs p-1 bg-slate-600 hover:bg-slate-500 text-slate-200 rounded-md flex items-center justify-center transition-colors disabled:opacity-50 disabled:cursor-wait"
                                                                >
                                                                    {translatingDescriptionId === obj.id ? <Spinner className="h-4 w-4" /> : <><TranslateIcon /> <span className="ml-1">Traduzir para o inglês</span></>}
                                                                </button>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            ))}
                                            <label htmlFor={`object-upload-${index}`} className={`flex items-center justify-center w-full aspect-square border-2 border-dashed border-slate-600 rounded-md text-3xl font-light text-slate-500 transition-colors ${isLoading ? 'cursor-not-allowed opacity-50' : 'cursor-pointer hover:border-yellow-500 hover:bg-slate-800'}`}>+</label>
                                            <input id={`object-upload-${index}`} type="file" multiple className="hidden" accept="image/png, image/jpeg, image/webp" disabled={isLoading} onChange={(e) => { if (e.target.files && e.target.files.length > 0) { handleObjectImagesUpload(index, e.target.files); } e.target.value = ''; }} />
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>

                        {/* Per-panel Prompt */}
                        <div className="space-y-2">
                            <label htmlFor={`prompt-${index}`} className="flex items-center justify-between text-sm font-medium text-slate-300">
                                <span>Descrição da Cena</span>
                                <div className="flex items-center space-x-3">
                                    <button onClick={() => onDetailPanel(index)} title="Detalhar Prompt com IA" className="flex items-center text-xs text-yellow-400 hover:text-yellow-300 font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed" disabled={isLoading || !config.prompt} >
                                        <DetailIcon /> <span className="ml-1">Detalhar</span>
                                    </button>
                                    <button onClick={() => onTranslatePanel(config.prompt, index)} title="Traduzir para o inglês" className="flex items-center text-xs text-yellow-400 hover:text-yellow-300 font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed" disabled={isLoading || !config.prompt} >
                                        <TranslateIcon /> <span className="ml-1">Traduzir para o inglês</span>
                                    </button>
                                    <button onClick={() => onOpenPromptHelper(index)} className="text-xs text-yellow-400 hover:text-yellow-300 font-semibold transition-colors">Dicas</button>
                                </div>
                            </label>
                            <div className="relative">
                                <textarea
                                    id={`prompt-${index}`}
                                    value={config.prompt}
                                    onChange={(e) => onConfigChange(index, { ...config, prompt: e.target.value })}
                                    placeholder={`ex: Close no rosto determinado do herói.`}
                                    className="w-full h-24 p-2 bg-slate-700 border border-slate-600 rounded-md focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors pr-10"
                                    disabled={isLoading}
                                />
                                <div className="absolute top-2 right-2 flex flex-col space-y-2">
                                    <button onClick={() => onOpenPromptEditor(index)} title="Expandir Editor" className="p-1.5 bg-slate-600 hover:bg-slate-500 rounded text-slate-200 transition-colors"><ExpandIcon /></button>
                                </div>
                            </div>
                        </div>
                        
                        {namedCharacters.length > 0 && (
                            <div className="space-y-4 border-t border-slate-700/50 pt-3">
                                <h5 className="text-sm font-semibold text-slate-300">Controles de Personagem</h5>
                                {namedCharacters.map(char => {
                                    if (!char.name) return null;
                                    const charId = char.id;
                                    const dialogue = config.characterDialogues?.[char.name] || '';
                                    const behavior = config.characterBehaviors?.[char.name] || '';
                                    const emotion = config.characterEmotions?.[char.name] || 'Automatic';
                                    const balloon = config.characterBalloons?.[char.name] || 'Automatic';
                                    return (
                                        <div key={char.id} className="p-3 bg-slate-800/60 rounded-lg space-y-3">
                                            <div className="flex justify-between items-center">
                                                <div className="text-sm font-bold text-yellow-400">{char.name}</div>
                                                <div className="flex items-center space-x-2">
                                                    <input
                                                        type="checkbox"
                                                        id={`exclude-${index}-${char.id}`}
                                                        checked={config.excludedCharacters?.includes(char.name) || false}
                                                        onChange={(e) => handleCharacterExclusionChange(index, char.name!, e.target.checked)}
                                                        className="w-4 h-4 text-yellow-600 bg-slate-700 border-slate-600 rounded focus:ring-yellow-500"
                                                    />
                                                    <label htmlFor={`exclude-${index}-${char.id}`} className="text-xs text-slate-300">Excluir do Painel</label>
                                                </div>
                                            </div>

                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                {/* Behavior */}
                                                <div>
                                                    <div className="flex items-center justify-between mb-1">
                                                        <label htmlFor={`behavior-${index}-${charId}`} className="block text-xs font-medium text-slate-400">Comportamento</label>
                                                        <div className="flex items-center space-x-2">
                                                            <button onClick={() => handleDetailCharacterField(index, char, 'behavior')} disabled={isLoading || !!loadingAction || !behavior || !config.prompt} className="flex items-center text-xs text-yellow-400 hover:text-yellow-300 font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed" title="Detalhar Comportamento com IA">
                                                                {loadingAction === `${index}-${char.id}-behavior-detail` ? <Spinner className="h-3 w-3" /> : <SmallDetailIcon />}<span className="ml-1">Detalhar</span>
                                                            </button>
                                                            <button onClick={() => handleTranslateCharacterField(index, char.name!, 'behavior', behavior)} disabled={isLoading || !!loadingAction || !behavior} className="flex items-center text-xs text-yellow-400 hover:text-yellow-300 font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed" title="Traduzir para o inglês">
                                                                {loadingAction === `${index}-${char.name}-behavior-translate` ? <Spinner className="h-3 w-3" /> : <SmallTranslateIcon />}<span className="ml-1">Traduzir</span>
                                                            </button>
                                                        </div>
                                                    </div>
                                                    <textarea
                                                        id={`behavior-${index}-${charId}`}
                                                        value={behavior}
                                                        onChange={(e) => {
                                                            const newBehaviors = {...(config.characterBehaviors || {})};
                                                            newBehaviors[char.name!] = e.target.value;
                                                            onConfigChange(index, { ...config, characterBehaviors: newBehaviors });
                                                        }}
                                                        placeholder={`Como ${char.name} age...`}
                                                        className="w-full h-24 p-1.5 text-sm bg-slate-700 border border-slate-600 rounded-md focus:ring-1 focus:ring-yellow-500 focus:border-yellow-500"
                                                        disabled={isLoading}
                                                        rows={3}
                                                    />
                                                </div>
                                                
                                                {/* Dialogue */}
                                                <div>
                                                    <div className="flex items-center justify-between mb-1">
                                                        <label htmlFor={`dialogue-${index}-${charId}`} className="block text-xs font-medium text-slate-400">Diálogo</label>
                                                        <div className="flex items-center space-x-2">
                                                            <button onClick={() => handleDetailCharacterField(index, char, 'dialogue')} disabled={isLoading || !!loadingAction || !dialogue || !config.prompt} className="flex items-center text-xs text-yellow-400 hover:text-yellow-300 font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed" title="Detalhar Diálogo com IA">
                                                                {loadingAction === `${index}-${char.id}-dialogue-detail` ? <Spinner className="h-3 w-3" /> : <SmallDetailIcon />}<span className="ml-1">Detalhar</span>
                                                            </button>
                                                            <button onClick={() => handleTranslateCharacterField(index, char.name!, 'dialogue', dialogue)} disabled={isLoading || !!loadingAction || !dialogue} className="flex items-center text-xs text-yellow-400 hover:text-yellow-300 font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed" title="Traduzir para o inglês">
                                                                {loadingAction === `${index}-${char.name}-dialogue-translate` ? <Spinner className="h-3 w-3" /> : <SmallTranslateIcon />}<span className="ml-1">Traduzir</span>
                                                            </button>
                                                        </div>
                                                    </div>
                                                    <textarea
                                                        id={`dialogue-${index}-${charId}`}
                                                        value={dialogue}
                                                        onChange={(e) => {
                                                            const newDialogues = {...(config.characterDialogues || {})};
                                                            newDialogues[char.name!] = e.target.value;
                                                            onConfigChange(index, { ...config, characterDialogues: newDialogues });
                                                        }}
                                                        placeholder={`O que ${char.name} diz...`}
                                                        className="w-full h-24 p-1.5 text-sm bg-slate-700 border border-slate-600 rounded-md focus:ring-1 focus:ring-yellow-500 focus:border-yellow-500"
                                                        disabled={isLoading}
                                                        rows={3}
                                                    />
                                                </div>

                                                {/* Emotion */}
                                                <div>
                                                    <label htmlFor={`emotion-${index}-${charId}`} className="block text-xs font-medium text-slate-400 mb-1">Emoção</label>
                                                    <select
                                                        id={`emotion-${index}-${charId}`}
                                                        value={emotion}
                                                        onChange={(e) => {
                                                            const newEmotions = {...(config.characterEmotions || {})};
                                                            newEmotions[char.name!] = e.target.value as CharacterEmotion;
                                                            onConfigChange(index, { ...config, characterEmotions: newEmotions });
                                                        }}
                                                        className="w-full p-2 text-sm bg-slate-700 border border-slate-600 rounded-md focus:ring-1 focus:ring-yellow-500 focus:border-yellow-500"
                                                        disabled={isLoading}
                                                    >
                                                        {CHARACTER_EMOTION_OPTIONS.map(opt => (
                                                            <option key={opt} value={opt}>{CHARACTER_EMOTION_MAP[opt] || opt}</option>
                                                        ))}
                                                    </select>
                                                </div>
                                                
                                                {/* Speech Balloon */}
                                                <div>
                                                    <label htmlFor={`balloon-${index}-${charId}`} className="block text-xs font-medium text-slate-400 mb-1">Balão de Fala</label>
                                                    <select
                                                        id={`balloon-${index}-${charId}`}
                                                        value={balloon}
                                                        onChange={(e) => {
                                                            const newBalloons = {...(config.characterBalloons || {})};
                                                            newBalloons[char.name!] = e.target.value as SpeechBalloonType;
                                                            onConfigChange(index, { ...config, characterBalloons: newBalloons });
                                                        }}
                                                        className="w-full p-2 text-sm bg-slate-700 border border-slate-600 rounded-md focus:ring-1 focus:ring-yellow-500 focus:border-yellow-500 disabled:opacity-50 disabled:cursor-not-allowed"
                                                        disabled={isLoading || !dialogue}
                                                        title={!dialogue ? "Adicione um diálogo para habilitar esta opção." : ""}
                                                    >
                                                        {SPEECH_BALLOON_OPTIONS.map(opt => (
                                                            <option key={opt} value={opt}>{SPEECH_BALLOON_MAP[opt] || opt}</option>
                                                        ))}
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        )}
                        
                        <div className="space-y-2 border-t border-slate-700/50 pt-3">
                            <label htmlFor={`extras-behavior-${index}`} className="flex items-center justify-between text-sm font-medium text-slate-300">
                                <span>Comportamento dos Figurantes (Opcional)</span>
                                <div className="flex items-center space-x-3">
                                    <button
                                        onClick={() => handleDetailExtrasBehavior(index)}
                                        disabled={isLoading || detailingExtras !== null || !config.extrasBehavior || !config.prompt}
                                        className="flex items-center text-xs text-yellow-400 hover:text-yellow-300 font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                        title="Detalhar Comportamento com IA"
                                    >
                                        {detailingExtras === index ? <Spinner className="h-4 w-4" /> : 
                                            <>
                                                <DetailIcon /> 
                                                <span className="ml-1">Detalhar</span>
                                            </>
                                        }
                                    </button>
                                    <button
                                        onClick={() => handleTranslateExtrasBehavior(index)}
                                        disabled={isLoading || translatingExtras !== null || !config.extrasBehavior}
                                        className="flex items-center text-xs text-yellow-400 hover:text-yellow-300 font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                        title="Traduzir para o inglês"
                                    >
                                        {translatingExtras === index ? <Spinner className="h-4 w-4" /> : 
                                            <>
                                                <TranslateIcon /> 
                                                <span className="ml-1">Traduzir para o inglês</span>
                                            </>
                                        }
                                    </button>
                                </div>
                            </label>
                            <textarea
                                id={`extras-behavior-${index}`}
                                value={config.extrasBehavior || ''}
                                onChange={(e) => onConfigChange(index, { ...config, extrasBehavior: e.target.value })}
                                placeholder="Descreva como os personagens de fundo devem reagir. Se vazio, a IA decide."
                                className="w-full h-16 p-2 bg-slate-700 border border-slate-600 rounded-md focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
                                disabled={isLoading}
                                rows={2}
                            />
                        </div>

                        <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-4 gap-y-3">
                             <SelectControl 
                                label="Enquadramento" 
                                value={config.framing} 
                                onChange={(e) => onConfigChange(index, { ...config, framing: e.target.value as CameraFraming })}
                                options={CAMERA_FRAMING_OPTIONS}
                                disabled={isLoading}
                                translations={CAMERA_FRAMING_MAP}
                             />
                              <SelectControl
                                label="Tamanho no Painel"
                                value={config.panelSize}
                                onChange={(e) => {
                                    const value = e.target.value as PanelConfig['panelSize'];
                                    if (value === 'Split Horizontally' || value === 'Split Vertically') {
                                        onSplitPanel(index, value);
                                    } else {
                                        onConfigChange(index, { ...config, panelSize: value });
                                    }
                                }}
                                options={['Automatic', 'Standard', 'Tall', 'Wide', 'Small Square', 'Split Horizontally', 'Split Vertically']}
                                translations={translations.panelSize}
                                disabled={isLoading}
                            />
                            <SelectControl
                                label="Ângulo do Personagem"
                                value={config.characterAngle}
                                onChange={(e) => onConfigChange(index, { ...config, characterAngle: e.target.value as PanelConfig['characterAngle'] })}
                                options={['Automatic', 'Front-facing', 'From behind', 'Side view']}
                                translations={translations.characterAngle}
                                disabled={isLoading}
                            />
                            <SelectControl
                                label="Nível de Detalhe"
                                value={config.detailLevel}
                                onChange={(e) => onConfigChange(index, { ...config, detailLevel: e.target.value as PanelConfig['detailLevel'] })}
                                options={['Automatic', 'Medium', 'Low', 'High']}
                                translations={translations.detailLevel}
                                disabled={isLoading}
                            />
                            <SelectControl
                                label="Nº de Figurantes"
                                value={config.extrasCount}
                                onChange={(e) => onConfigChange(index, { ...config, extrasCount: e.target.value as PanelConfig['extrasCount'] })}
                                options={['Automatic', 'None', 'A few (1-3)', 'A small crowd (4-10)']}
                                translations={translations.extrasCount}
                                disabled={isLoading}
                            />
                             <SelectControl
                                label="Contexto do Conteúdo"
                                value={config.contentContext}
                                onChange={(e) => onConfigChange(index, { ...config, contentContext: e.target.value as PanelConfig['contentContext'] })}
                                options={contentContextOptions}
                                translations={translations.contentContext}
                                disabled={isLoading}
                            />
                            <SelectControl
                                label="Atmosfera"
                                value={config.atmosphere}
                                onChange={(e) => onConfigChange(index, { ...config, atmosphere: e.target.value as Atmosphere })}
                                options={getAtmosphereOptions(genre, config.contentContext)}
                                translations={translations.atmosphere}
                                disabled={isLoading}
                             />
                        </div>
                        
                        <div className="border-t border-slate-700/50 pt-3">
                             <div className="grid grid-cols-2 lg:grid-cols-3 gap-x-4 gap-y-2 text-sm">
                               <div className="flex items-start space-x-2">
                                    <input type="checkbox" id={`no-dialogue-${index}`} checked={config.noDialogue || false} onChange={(e) => onConfigChange(index, { ...config, noDialogue: e.target.checked })} className="mt-1 w-4 h-4 text-yellow-600 bg-slate-700 border-slate-600 rounded focus:ring-yellow-500" />
                                    <label htmlFor={`no-dialogue-${index}`} className="text-slate-300">Sem Diálogo</label>
                               </div>
                               <div className="flex items-start space-x-2">
                                    <input type="checkbox" id={`no-sfx-${index}`} checked={config.noOnomatopoeia || false} onChange={(e) => onConfigChange(index, { ...config, noOnomatopoeia: e.target.checked })} className="mt-1 w-4 h-4 text-yellow-600 bg-slate-700 border-slate-600 rounded focus:ring-yellow-500" />
                                    <label htmlFor={`no-sfx-${index}`} className="text-slate-300">Sem Efeitos Sonoros</label>
                               </div>
                               <div className="flex items-start space-x-2">
                                    <input type="checkbox" id={`remove-accessories-${index}`} checked={config.removeAccessories || false} onChange={(e) => onConfigChange(index, { ...config, removeAccessories: e.target.checked })} className="mt-1 w-4 h-4 text-yellow-600 bg-slate-700 border-slate-600 rounded focus:ring-yellow-500" />
                                    <label htmlFor={`remove-accessories-${index}`} className="text-slate-300">Remover Acessórios</label>
                               </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
            {configs.length < 9 && (
                <button 
                    onClick={onAddPanel} 
                    className="w-full mt-4 p-2 text-sm font-semibold text-slate-300 bg-slate-700/50 hover:bg-slate-700 rounded-md flex items-center justify-center transition-colors"
                    disabled={isLoading}
                >
                    <AddIcon /> Adicionar Painel
                </button>
            )}
        </div>
    );
};

export default PanelConfiguration;