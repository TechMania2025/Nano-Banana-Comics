
import React, { useState } from 'react';
import Button from '../Button';

interface TabProps {
    onBuildPrompt: (keywords: string) => Promise<void>;
}

const content = {
    title: "Construtor de Prompt Passo a Passo",
    intro: "Preencha os campos abaixo para descrever sua ideia. Usaremos IA para combiná-los em um prompt criativo.",
    subjectLabel: "Assunto / Foco Principal",
    subjectPlaceholder: "ex: um leão majestoso, uma cidade futurista",
    styleLabel: "Estilo / Mídia",
    stylePlaceholder: "ex: pintura a óleo, render 3D, anime",
    detailsLabel: "Detalhes & Modificadores",
    detailsPlaceholder: "ex: iluminação cinematográfica, alto detalhe, usando uma coroa",
    generateButton: "Construir Meu Prompt",
    generating: "Construindo..."
};

const PromptBuilderTab: React.FC<TabProps> = ({ onBuildPrompt }) => {
    const [subject, setSubject] = useState('');
    const [style, setStyle] = useState('');
    const [details, setDetails] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleGenerate = async () => {
        const keywords = [subject, style, details].filter(Boolean).join(', ');
        if (!keywords) return;
        setIsLoading(true);
        await onBuildPrompt(keywords);
        setIsLoading(false);
    };

    const InputField: React.FC<{label: string, value: string, onChange: (val: string) => void, placeholder: string}> = ({ label, value, onChange, placeholder }) => (
        <div className="mb-4">
            <label className="block text-sm font-medium text-slate-300 mb-2">{label}</label>
            <input
                type="text"
                value={value}
                onChange={(e) => onChange(e.target.value)}
                placeholder={placeholder}
                className="w-full p-2 bg-slate-700 border border-slate-600 rounded-md focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
            />
        </div>
    );

    return (
        <div>
            <h3 className="text-2xl font-bold mb-4">{content.title}</h3>
            <p className="text-slate-400 mb-6">{content.intro}</p>
            
            <InputField label={content.subjectLabel} value={subject} onChange={setSubject} placeholder={content.subjectPlaceholder} />
            <InputField label={content.styleLabel} value={style} onChange={setStyle} placeholder={content.stylePlaceholder} />
            <InputField label={content.detailsLabel} value={details} onChange={setDetails} placeholder={content.detailsPlaceholder} />

            <div className="mt-6">
                <Button onClick={handleGenerate} isLoading={isLoading} fullWidth>
                    {isLoading ? content.generating : content.generateButton}
                </Button>
            </div>
        </div>
    );
};

export default PromptBuilderTab;
