import React from 'react';

const content = {
    title: "Editando seu Mangá",
    intro: "Para criar seu mangá, descreva a cena ou ação inteira na caixa de prompt principal. A IA irá interpretar sua descrição para criar cada painel com base nas suas configurações de ângulo de câmera.",
    tip: "Use imagens de referência para personagens e objetos consistentes!"
};

const EditingGuideTab: React.FC = () => {
    return (
        <div>
            <h3 className="text-2xl font-bold mb-4">{content.title}</h3>
            <p className="text-slate-400 mb-6">{content.intro}</p>
             <div className="p-3 bg-slate-700/50 rounded-md mb-6 text-sm text-slate-300">
                <p><strong>Dica:</strong> {content.tip}</p>
            </div>
        </div>
    );
};

export default EditingGuideTab;
