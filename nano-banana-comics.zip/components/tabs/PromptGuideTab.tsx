
import React from 'react';

const content = {
    title: "Criando o Prompt Perfeito",
    intro: "Um bom prompt é claro, detalhado e guia a IA para o resultado desejado. Aqui está uma estrutura básica:",
    structure: "[Assunto], [Estilo], [Ação/Contexto], [Detalhes/Modificadores]",
    example1Title: "Exemplo: Personagem",
    example1Prompt: "Um retrato de um mago velho e sábio com uma longa barba branca, vestindo um manto estrelado, no estilo de uma pintura a óleo de fantasia detalhada, lançando um feitiço brilhante em uma floresta escura e encantada, iluminação cinematográfica, hiper-realista.",
    example2Title: "Exemplo: Cenário",
    example2Prompt: "Um recife de coral vibrante e colorido, cheio de peixes exóticos e vida marinha, fotografia subaquática, foto em grande angular, raios de sol filtrando pela água azul clara, alto detalhe, estilo National Geographic.",
    example3Title: "Exemplo: Abstrato",
    example3Prompt: "O conceito de 'caos e ordem' visualizado, formas geométricas colidindo com linhas orgânicas e fluidas, em um estilo abstrato minimalista, usando uma paleta de cores de preto, branco e dourado, renderização octane, 8k.",
    clickToCopy: "Clique para copiar o prompt",
};

const PromptGuideTab: React.FC = () => {

    const copyToClipboard = (text: string) => {
        navigator.clipboard.writeText(text);
    };

    const PromptExample: React.FC<{ title: string; prompt: string }> = ({ title, prompt }) => (
        <div className="mb-6">
            <h4 className="font-semibold text-slate-300 mb-2">{title}</h4>
            <div 
                className="p-3 bg-slate-700/50 rounded-md text-sm text-slate-300 cursor-pointer hover:bg-slate-700 transition-colors relative group"
                onClick={() => copyToClipboard(prompt)}
            >
                <p>{prompt}</p>
                <span className="absolute -top-2 -right-2 bg-yellow-600 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity">
                    {content.clickToCopy}
                </span>
            </div>
        </div>
    );

    return (
        <div>
            <h3 className="text-2xl font-bold mb-4">{content.title}</h3>
            <p className="text-slate-400 mb-4">{content.intro}</p>
            <div className="p-3 bg-slate-900 rounded-md mb-6">
                <code className="text-yellow-400">{content.structure}</code>
            </div>
            
            <PromptExample title={content.example1Title} prompt={content.example1Prompt} />
            <PromptExample title={content.example2Title} prompt={content.example2Prompt} />
            <PromptExample title={content.example3Title} prompt={content.example3Prompt} />
        </div>
    );
};

export default PromptGuideTab;
