import React from 'react';

interface TabProps {
    onInsertText: (text: string) => void;
}

const content = {
    title: "Usando Palavras-chave Negativas",
    intro: "Você pode dizer à IA o que *evitar* adicionando palavras-chave negativas diretamente na descrição da sua cena principal.",
    tip: "Use `--neg` em seu prompt principal, como: `Um samurai lutando --neg embaçado, espada extra`.",
    commonKeywordsTitle: "Palavras-chave Comuns",
    keywords: [
        { en: "ugly", pt: "feio" }, { en: "blurry", pt: "embaçado" }, { en: "bad anatomy", pt: "anatomia ruim" },
        { en: "extra limbs", pt: "membros extras" }, { en: "poorly drawn hands", pt: "mãos mal desenhadas" },
        { en: "text", pt: "texto" }, { en: "watermark", pt: "marca d'água" }, { en: "low quality", pt: "baixa qualidade" }
    ]
};

const KeywordButton: React.FC<{ pt: string, enInsert: string, onClick: (text: string) => void }> = ({ pt, enInsert, onClick }) => (
    <button
        onClick={() => onClick(` --neg ${enInsert}`)}
        className="px-3 py-1.5 bg-slate-700 text-slate-300 rounded-md text-sm hover:bg-red-600 hover:text-white transition-colors"
    >
        {pt}
    </button>
);

const NegativePromptsTab: React.FC<TabProps> = ({ onInsertText }) => {
    return (
        <div>
            <h3 className="text-2xl font-bold mb-4">{content.title}</h3>
            <p className="text-slate-400 mb-4">{content.intro}</p>
            <div className="p-3 bg-slate-700/50 rounded-md mb-6 text-sm text-slate-300">
                <p><strong>Dica:</strong> {content.tip}</p>
            </div>
            
            <h4 className="font-semibold text-slate-300 mb-3">{content.commonKeywordsTitle}</h4>
            <div className="flex flex-wrap gap-2">
                {content.keywords.map(kw => (
                    <KeywordButton key={kw.en} pt={kw.pt} enInsert={kw.en} onClick={onInsertText} />
                ))}
            </div>
        </div>
    );
};

export default NegativePromptsTab;
