
import React, { ReactNode } from 'react';

interface TabProps {
    onInsertText: (text: string) => void;
}

const keywordData = {
    "Photography Styles": { "EN": "Photography Styles", "PT-BR": "Estilos de Fotografia", keywords: [ { en: "Portrait", pt: "Retrato" }, { en: "Landscape", pt: "Paisagem" }, { en: "Macro", pt: "Macro" }, { en: "Cinematic", pt: "Cinematográfico" }, { en: "Golden Hour", pt: "Hora Dourada" }, { en: "Long Exposure", pt: "Longa Exposição" } ] },
    "Art Styles": { "EN": "Art Styles", "PT-BR": "Estilos de Arte", keywords: [ { en: "Oil Painting", pt: "Pintura a Óleo" }, { en: "Watercolor", pt: "Aquarela" }, { en: "Abstract", pt: "Abstrato" }, { en: "Impressionism", pt: "Impressionismo" }, { en: "Surrealism", pt: "Surrealismo" }, { en: "Pop Art", pt: "Pop Art" }, { en: "Anime", pt: "Anime" } ] },
    "Artists": { "EN": "Artists", "PT-BR": "Artistas", keywords: [ { en: "in the style of Van Gogh", pt: "no estilo de Van Gogh" }, { en: "in the style of Picasso", pt: "no estilo de Picasso" }, { en: "in the style of Salvador Dali", pt: "no estilo de Salvador Dali" }, { en: "in the style of H.R. Giger", pt: "no estilo de H.R. Giger" } ] },
    "Natural Lighting": { "EN": "Natural Lighting", "PT-BR": "Iluminação Natural", keywords: [ { en: "Soft light", pt: "Luz suave" }, { en: "Hard light", pt: "Luz dura" }, { en: "Backlight", pt: "Contraluz" }, { en: "Volumetric lighting", pt: "Iluminação volumétrica" } ] },
    "Creative Effects": { "EN": "Creative Effects", "PT-BR": "Efeitos Criativos", keywords: [ { en: "Hyperrealistic", pt: "Hiper-realista" }, { en: "8k", pt: "8k" }, { en: "Octane Render", pt: "Render Octane" }, { en: "Bokeh", pt: "Bokeh" }, { en: "Lens flare", pt: "Brilho de lente" }, { en: "Double exposure", pt: "Dupla exposição" } ] },
};

const KeywordButton: React.FC<{ pt: string, enInsert: string, onClick: (text: string) => void }> = ({ pt, enInsert, onClick }) => (
    <button
        onClick={() => onClick(`, ${enInsert}`)}
        className="px-3 py-1.5 bg-slate-700 text-slate-300 rounded-md text-sm hover:bg-yellow-600 hover:text-white transition-colors"
    >
        {pt}
    </button>
);

const KeywordCategory: React.FC<{ title: string, children: ReactNode }> = ({ title, children }) => (
    <div className="mb-6">
        <h4 className="font-semibold text-slate-300 mb-3">{title}</h4>
        <div className="flex flex-wrap gap-2">
            {children}
        </div>
    </div>
);

const StylesKeywordsTab: React.FC<TabProps> = ({ onInsertText }) => {
    return (
        <div>
            <h3 className="text-2xl font-bold mb-4">Biblioteca de Estilos & Palavras-chave</h3>
            <p className="text-slate-400 mb-6">Clique em qualquer palavra-chave para adicioná-la ao seu prompt.</p>
            
            {Object.entries(keywordData).map(([category, data]) => (
                <KeywordCategory key={category} title={data["PT-BR"]}>
                    {data.keywords.map(kw => (
                        <KeywordButton key={kw.en} pt={kw.pt} enInsert={kw.en} onClick={onInsertText} />
                    ))}
                </KeywordCategory>
            ))}
        </div>
    );
};

export default StylesKeywordsTab;
