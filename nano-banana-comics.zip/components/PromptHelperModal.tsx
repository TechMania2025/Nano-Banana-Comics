
import React, { useState } from 'react';
import Modal from './Modal';
import PromptGuideTab from './tabs/PromptGuideTab';
import EditingGuideTab from './tabs/EditingGuideTab';
import PromptBuilderTab from './tabs/PromptBuilderTab';
import StylesKeywordsTab from './tabs/StylesKeywordsTab';
import NegativePromptsTab from './tabs/NegativePromptsTab';

interface PromptHelperModalProps {
    onClose: () => void;
    onInsertText: (text: string) => void;
    onBuildPrompt: (keywords: string) => Promise<void>;
}

type Tab = 'Guide' | 'Editing' | 'Builder' | 'Styles' | 'Negative';

const PromptHelperModal: React.FC<PromptHelperModalProps> = (props) => {
    const [activeTab, setActiveTab] = useState<Tab>('Guide');

    const tabs: { id: Tab; label: string }[] = [
        { id: 'Guide', label: 'Guia de Prompt' },
        { id: 'Editing', label: 'Guia de Edição' },
        { id: 'Builder', label: 'Construtor de Prompt' },
        { id: 'Styles', label: 'Estilos & Palavras-chave' },
        { id: 'Negative', label: 'Prompts Negativos' },
    ];

    const renderTabContent = () => {
        const commonProps = { onInsertText: props.onInsertText };
        switch (activeTab) {
            case 'Guide': return <PromptGuideTab />;
            case 'Editing': return <EditingGuideTab />;
            case 'Builder': return <PromptBuilderTab onBuildPrompt={props.onBuildPrompt} />;
            case 'Styles': return <StylesKeywordsTab {...commonProps} />;
            case 'Negative': return <NegativePromptsTab {...commonProps} />;
            default: return null;
        }
    };

    return (
        <Modal title="Ajudante de Prompt" onClose={props.onClose} size="4xl">
            <div className="flex flex-col md:flex-row md:space-x-6 h-[70vh]">
                <div className="flex flex-col border-b md:border-b-0 md:border-r border-slate-700 pb-4 md:pb-0 md:pr-6 mb-4 md:mb-0">
                   <div className="flex items-center justify-between mb-4">
                     <h3 className="text-lg font-semibold text-slate-300">Tópicos</h3>
                   </div>
                    <nav className="flex flex-row md:flex-col space-x-2 md:space-x-0 md:space-y-1 overflow-x-auto md:overflow-x-visible">
                        {tabs.map(tab => (
                            <button
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id)}
                                className={`px-4 py-2 text-left rounded-md whitespace-nowrap transition-colors text-sm ${activeTab === tab.id ? 'bg-yellow-600 text-white font-semibold' : 'text-slate-300 hover:bg-slate-700'}`}
                            >
                                {tab.label}
                            </button>
                        ))}
                    </nav>
                </div>
                <div className="flex-grow overflow-y-auto">
                    {renderTabContent()}
                </div>
            </div>
        </Modal>
    );
};

export default PromptHelperModal;
