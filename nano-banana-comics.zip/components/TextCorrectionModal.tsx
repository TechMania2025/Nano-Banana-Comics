

import React, { useState, useEffect, useCallback } from 'react';
import Modal from './Modal';
import Button from './Button';
import Spinner from './Spinner';
import { CorrectionMode, CorrectionPayload } from '../types';
import * as geminiService from '../services/geminiService';

interface TextCorrectionModalProps {
    panelImageUrl: string;
    onClose: () => void;
    onApply: (correction: CorrectionPayload) => Promise<void>;
    isLoading: boolean;
    error: string | null;
    isExtractingText: boolean;
    initialExtractedText: string | null;
}

const TextCorrectionModal: React.FC<TextCorrectionModalProps> = ({
    panelImageUrl,
    onClose,
    onApply,
    isLoading,
    error,
    isExtractingText,
    initialExtractedText
}) => {
    const [mode, setMode] = useState<CorrectionMode>('suggestion');
    const [deleteText, setDeleteText] = useState('');
    const [deleteOption, setDeleteOption] = useState<'textOnly' | 'textAndBalloons'>('textOnly');
    
    const [dialogueSuggestions, setDialogueSuggestions] = useState<string[]>([]);
    const [correctionSuggestions, setCorrectionSuggestions] = useState<string[]>([]);

    const [isFetchingSuggestions, setIsFetchingSuggestions] = useState(false);

    const fetchSuggestions = useCallback(async () => {
        if (!initialExtractedText) return;
        
        setIsFetchingSuggestions(true);
        const base64Data = panelImageUrl.split(',')[1];
        const mimeType = panelImageUrl.match(/data:(.*);/)?.[1] || 'image/png';
        
        try {
            if (mode === 'suggestion') {
                const suggestions = await geminiService.getDialogueSuggestions(base64Data, mimeType, initialExtractedText);
                setDialogueSuggestions(suggestions);
            } else if (mode === 'correction') {
                const corrections = await geminiService.getSpellingCorrections(base64Data, mimeType, initialExtractedText);
                setCorrectionSuggestions(corrections);
            }
        } catch (e) {
            console.error("Failed to fetch suggestions:", e);
            // Optionally set a local error state
        } finally {
            setIsFetchingSuggestions(false);
        }
    }, [initialExtractedText, panelImageUrl, mode]);

    useEffect(() => {
        if (initialExtractedText) {
            setDeleteText(initialExtractedText);
            // Fetch suggestions for the initial mode
            fetchSuggestions();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [initialExtractedText]);

    useEffect(() => {
        // Fetch new suggestions when mode changes, if initial text is available
        if (initialExtractedText) {
            setDialogueSuggestions([]); // Clear old suggestions
            setCorrectionSuggestions([]);
            fetchSuggestions();
        }
    }, [mode, initialExtractedText, fetchSuggestions]);


    const handleApplyDelete = () => {
        if (!deleteText.trim()) return;
        onApply({ 
            mode: 'delete', 
            text: deleteText, 
            deleteBalloons: deleteOption === 'textAndBalloons' 
        });
    };

    const isApplyDisabled = isLoading || isExtractingText || (mode === 'delete' && !deleteText.trim());

    const ModeButton: React.FC<{ active: boolean; onClick: () => void; children: React.ReactNode }> = ({ active, onClick, children }) => (
        <button
            onClick={onClick}
            disabled={isLoading}
            className={`w-full py-2 text-sm font-semibold rounded-md transition-colors focus:outline-none disabled:opacity-50 ${active ? 'bg-yellow-600 text-white' : 'bg-slate-600 text-slate-300 hover:bg-slate-500'}`}
        >
            {children}
        </button>
    );

    const SuggestionsDisplay: React.FC<{
        title: string;
        suggestions: string[];
        onApplySuggestion: (text: string) => void;
    }> = ({ title, suggestions, onApplySuggestion }) => (
        <div className="space-y-3">
            <p className="text-sm text-slate-400">{title}</p>
            {isFetchingSuggestions ? (
                <div className="flex items-center justify-center h-24">
                    <Spinner />
                    <span className="ml-2 text-slate-300">Gerando sugestões...</span>
                </div>
            ) : suggestions.length > 0 ? (
                suggestions.map((suggestion, index) => (
                    <div key={index} className="bg-slate-700/50 p-3 rounded-md flex justify-between items-center">
                        <p className="text-sm text-slate-200 flex-grow italic">"{suggestion}"</p>
                        <Button onClick={() => onApplySuggestion(suggestion)} isLoading={isLoading} className="px-4 py-1 text-xs ml-4">
                            Aplicar
                        </Button>
                    </div>
                ))
            ) : (
                <p className="text-sm text-slate-500 text-center py-4">Não foi possível gerar sugestões.</p>
            )}
        </div>
    );

    return (
        <Modal title="Corrigir Texto do Painel" onClose={onClose} size="3xl">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex flex-col items-center">
                    <h3 className="text-lg font-semibold mb-2 text-slate-300">Painel Original</h3>
                    <img src={panelImageUrl} alt="Panel to correct" className="rounded-md w-full max-w-md object-contain bg-white" />
                     {initialExtractedText && (
                        <div className="mt-4 p-3 bg-slate-900/50 w-full rounded-md">
                            <h4 className="text-xs font-semibold text-yellow-400 mb-1">Texto Original Extraído</h4>
                            <p className="text-sm text-slate-300 italic">"{initialExtractedText}"</p>
                        </div>
                    )}
                </div>
                <div className="flex flex-col space-y-4">
                     <h3 className="text-lg font-semibold text-slate-300">Método de Correção</h3>
                     <div className="flex bg-slate-700 rounded-lg p-1 space-x-1">
                        <ModeButton active={mode === 'suggestion'} onClick={() => setMode('suggestion')}>Sugestões de Diálogo</ModeButton>
                        <ModeButton active={mode === 'correction'} onClick={() => setMode('correction')}>Corrigir Ortografia</ModeButton>
                        <ModeButton active={mode === 'delete'} onClick={() => setMode('delete')}>Apagar Texto</ModeButton>
                     </div>

                    {isExtractingText && (
                         <div className="flex items-center justify-center h-24">
                            <Spinner />
                            <span className="ml-2 text-slate-300">Extraindo texto do painel...</span>
                        </div>
                    )}

                    {!isExtractingText && mode === 'suggestion' && (
                        <SuggestionsDisplay
                            title="A IA analisou o painel e sugere estes diálogos alternativos:"
                            suggestions={dialogueSuggestions}
                            onApplySuggestion={(text) => onApply({ mode: 'suggestion', text })}
                        />
                    )}

                    {!isExtractingText && mode === 'correction' && (
                         <SuggestionsDisplay
                            title="A IA analisou o texto e sugere as seguintes correções:"
                            suggestions={correctionSuggestions}
                            onApplySuggestion={(text) => onApply({ mode: 'suggestion', text })}
                        />
                    )}

                    {!isExtractingText && mode === 'delete' && (
                         <div className="space-y-4">
                            <div>
                                <label htmlFor="delete-text" className="block text-sm font-medium text-slate-300 mb-1">Texto a Apagar</label>
                                <textarea
                                    id="delete-text"
                                    value={deleteText}
                                    onChange={(e) => setDeleteText(e.target.value)}
                                    placeholder="Texto extraído..."
                                    className="w-full flex-grow p-2 bg-slate-700 border border-slate-600 rounded-md focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors min-h-[80px]"
                                    disabled={isLoading}
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="block text-sm font-medium text-slate-300">Opções</label>
                                <div className="flex items-center space-x-3 p-3 bg-slate-700/50 rounded-md">
                                    <input type="radio" id="delete-text-only" name="delete-option" value="textOnly" checked={deleteOption === 'textOnly'} onChange={(e) => setDeleteOption(e.target.value as any)} />
                                    <label htmlFor="delete-text-only" className="text-sm text-slate-300">Apagar somente o texto (manter balões)</label>
                                </div>
                                <div className="flex items-center space-x-3 p-3 bg-slate-700/50 rounded-md">
                                    <input type="radio" id="delete-text-balloons" name="delete-option" value="textAndBalloons" checked={deleteOption === 'textAndBalloons'} onChange={(e) => setDeleteOption(e.target.value as any)} />
                                    <label htmlFor="delete-text-balloons" className="text-sm text-slate-300">Apagar texto e balões</label>
                                </div>
                            </div>
                        </div>
                    )}
                    
                    {error && (
                        <p className="text-sm text-red-400 bg-red-900/50 p-3 rounded-md">{error}</p>
                    )}
                    <div className="flex justify-end space-x-4 pt-2">
                        <Button onClick={onClose} variant="secondary" disabled={isLoading}>Cancelar</Button>
                        {mode === 'delete' && (
                            <Button onClick={handleApplyDelete} isLoading={isLoading} disabled={isApplyDisabled}>
                                Aplicar Exclusão
                            </Button>
                        )}
                    </div>
                </div>
            </div>
        </Modal>
    );
};

export default TextCorrectionModal;