





import React, { useState } from 'react';
import { TextCharacter, PanelOutput, ImageData } from '../types';
import Button from './Button';
import * as geminiService from '../services/geminiService';
import Spinner from './Spinner';

interface TextCharacterCreatorProps {
    characters: TextCharacter[];
    onAdd: () => void;
    onRemove: (id: string) => void;
    onUpdate: (id: string, field: keyof Omit<TextCharacter, 'id' | 'personas' | 'clothingReference'>, value: string) => void;
    onUpdatePersona: (id: string, index: number, value: string) => void;
    onClear: () => void;
    characterDetailsEnabled: boolean;
    disabled?: boolean;
    appearanceMemory: { [characterName: string]: PanelOutput | null };
    onClearAppearanceMemory: (characterName: string) => void;
    onSetClothingReference: (characterId: string, characterType: 'text', file: File) => void;
    onRemoveClothingReference: (characterId: string, characterType: 'text') => void;
}

const TranslateIcon = () => ( <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}> <path strokeLinecap="round" strokeLinejoin="round" d="M3 5h12M9 3v2m4 13l4-4M19 17l-4-4M3 19h12a2 2 0 002-2V7a2 2 0 00-2-2H3a2 2 0 00-2 2v10a2 2 0 002 2z" /> </svg> );

const TextCharacterCreator: React.FC<TextCharacterCreatorProps> = (props) => {
    const {
        characters, onAdd, onRemove, onUpdate, onClear, characterDetailsEnabled, disabled, onUpdatePersona,
        appearanceMemory, onClearAppearanceMemory, onSetClothingReference, onRemoveClothingReference
    } = props;
    const [translatingId, setTranslatingId] = useState<string | null>(null);
    const [clothingDescriptions, setClothingDescriptions] = useState<Record<string, string>>({});
    const [describingClothingId, setDescribingClothingId] = useState<string | null>(null);
    const [descriptionError, setDescriptionError] = useState<string | null>(null);
    const [translatingDescriptionId, setTranslatingDescriptionId] = useState<string | null>(null);

    const handleTranslate = async (id: string, field: 'appearance' | 'persona', text: string, personaIndex?: number) => {
        if (!text || translatingId) return;
        const uniqueId = field === 'persona' ? `${id}-persona-${personaIndex}` : `${id}-${field}`;
        setTranslatingId(uniqueId);
        try {
            const namesToPreserve = characters.map(c => c.name).filter(Boolean);
            const translatedText = await geminiService.translateText(text, namesToPreserve);
            if (field === 'appearance') {
                onUpdate(id, 'appearance', translatedText);
            } else if (field === 'persona' && typeof personaIndex === 'number') {
                onUpdatePersona(id, personaIndex, translatedText);
            }
        } catch (error) {
            console.error(`Translation for ${uniqueId} failed`, error);
        } finally {
            setTranslatingId(null);
        }
    };
    
    const handleClothingReferenceUpload = (e: React.ChangeEvent<HTMLInputElement>, characterId: string) => {
        if (e.target.files && e.target.files[0]) {
            onSetClothingReference(characterId, 'text', e.target.files[0]);
        }
        e.target.value = '';
    };

    const handleDescribeClothing = async (charId: string, image: ImageData) => {
        setDescribingClothingId(charId);
        setDescriptionError(null);
        try {
            const description = await geminiService.describeClothing(image.dataUrl.split(',')[1], image.mimeType);
            setClothingDescriptions(prev => ({...prev, [charId]: description}));
        } catch(error: any) {
             console.error("Failed to describe clothing", error);
            const errorMessage = error?.message || 'Falha ao descrever a roupa.';
            setDescriptionError(errorMessage);
        } finally {
            setDescribingClothingId(null);
        }
    };

    const handleTranslateDescription = async (id: string, text: string) => {
        if (!text || translatingDescriptionId) return;
        setTranslatingDescriptionId(id);
        try {
            const translatedText = await geminiService.translateText(text, []);
            setClothingDescriptions(prev => ({...prev, [id]: translatedText}));
        } catch (error) {
            console.error(`Translation for description ${id} failed`, error);
        } finally {
            setTranslatingDescriptionId(null);
        }
    };


    if (characters.length === 0) {
        return (
            <div className="mt-4">
                <Button onClick={onAdd} variant="secondary" fullWidth disabled={disabled}>
                    Criar Personagens por Texto
                </Button>
            </div>
        );
    }

    return (
        <div className="space-y-4 mt-4 p-4 border border-slate-700 rounded-lg">
            <div className="flex justify-between items-center">
                <h3 className="text-sm font-medium text-slate-300">Personagens (Criados por Texto)</h3>
                <button onClick={onClear} className="text-xs text-slate-400 hover:text-red-400" disabled={disabled}>
                    Remover todos e usar imagens
                </button>
            </div>
            {descriptionError && <p className="text-xs text-red-400 mt-1">{descriptionError}</p>}
            {characters.map((char) => {
                const memorizedAppearance = char.name ? appearanceMemory[char.name] : null;
                return (
                <div key={char.id} className="p-3 bg-slate-800/50 rounded-md space-y-3 relative">
                     <button
                        onClick={() => onRemove(char.id)}
                        className="absolute top-2 right-2 bg-slate-700/50 text-slate-400 rounded-full p-0 w-5 h-5 flex items-center justify-center leading-none text-md hover:bg-red-500 hover:text-white"
                        disabled={disabled}
                    >
                        &times;
                    </button>
                    <div className="grid grid-cols-1">
                        <div>
                            <label className="block text-xs font-medium text-slate-400 mb-1">Nome</label>
                            <div className="relative">
                                <input
                                    type="text"
                                    placeholder="Nome do Personagem..."
                                    value={char.name}
                                    onChange={(e) => onUpdate(char.id, 'name', e.target.value)}
                                    disabled={disabled}
                                    className="w-full text-sm p-2 bg-slate-700 border border-slate-600 rounded-md text-slate-200 placeholder-slate-500 focus:ring-1 focus:ring-yellow-500 focus:border-yellow-500"
                                />
                            </div>
                        </div>
                    </div>
                     <div>
                        <label className="block text-xs font-medium text-slate-400 mb-1">Aparência Física</label>
                        <div className="relative">
                            <textarea
                                placeholder="Descreva a aparência do personagem..."
                                value={char.appearance}
                                onChange={(e) => onUpdate(char.id, 'appearance', e.target.value)}
                                disabled={disabled}
                                rows={3}
                                className="w-full text-sm p-2 bg-slate-700 border border-slate-600 rounded-md text-slate-200 placeholder-slate-500 focus:ring-1 focus:ring-yellow-500 focus:border-yellow-500 pr-8"
                            />
                            <button
                                onClick={() => handleTranslate(char.id, 'appearance', char.appearance)}
                                disabled={!char.appearance.trim() || !!translatingId || disabled}
                                className="absolute top-2 right-2 text-slate-400 hover:text-yellow-400 disabled:opacity-50 disabled:cursor-not-allowed"
                                title="Traduzir para Inglês"
                            >
                                {translatingId === `${char.id}-appearance` ? <Spinner className="h-4 w-4" /> : <TranslateIcon />}
                            </button>
                        </div>
                    </div>
                     <div>
                        <label className="block text-xs font-medium text-slate-400 mb-1">Personas (Opcional)</label>
                         <div className={`grid grid-cols-1 md:grid-cols-3 gap-2 transition-opacity ${!characterDetailsEnabled ? 'opacity-60' : ''}`}>
                            {(char.personas || ['', '', '']).map((persona, index) => (
                                <div key={index} className="relative">
                                    <input
                                        type="text"
                                        placeholder={`Persona ${index + 1}...`}
                                        value={persona}
                                        onChange={(e) => onUpdatePersona(char.id, index, e.target.value)}
                                        disabled={disabled || !characterDetailsEnabled}
                                        title={!characterDetailsEnabled ? 'Habilite "Detalhes do Personagem" para editar' : ''}
                                        className="w-full text-sm p-2 bg-slate-700 border border-slate-600 rounded-md text-slate-200 placeholder-slate-500 focus:ring-1 focus:ring-yellow-500 focus:border-yellow-500 pr-8 disabled:cursor-not-allowed"
                                    />
                                    <button
                                        onClick={() => handleTranslate(char.id, 'persona', persona, index)}
                                        disabled={!persona.trim() || !!translatingId || disabled || !characterDetailsEnabled}
                                        className="absolute top-1/2 right-2 -translate-y-1/2 text-slate-400 hover:text-yellow-400 disabled:opacity-50 disabled:cursor-not-allowed"
                                        title="Traduzir para Inglês"
                                    >
                                        {translatingId === `${char.id}-persona-${index}` ? <Spinner className="h-4 w-4" /> : <TranslateIcon />}
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                     {memorizedAppearance && char.name && (
                        <div className="mt-1 p-2 bg-slate-900/50 rounded-md space-y-2">
                            <h4 className="text-xs font-semibold text-yellow-400">Aparência Memorizada</h4>
                            <img src={memorizedAppearance.url} alt={`Aparência memorizada para ${char.name}`} className="w-full aspect-video object-contain rounded-md bg-slate-700" />
                            <Button onClick={() => onClearAppearanceMemory(char.name!)} disabled={disabled} fullWidth variant="secondary" className="text-xs p-1">Esquecer</Button>
                        </div>
                    )}
                    {/* Clothing Reference Section */}
                    <div className="mt-2 pt-2 border-t border-slate-700 space-y-2">
                        <h4 className="text-xs font-semibold text-center text-slate-400">Roupa Casual (Referência)</h4>
                        {char.clothingReference ? (
                            <div className="space-y-2">
                                <div className="relative aspect-square">
                                    <img src={char.clothingReference.dataUrl} alt="Clothing Reference" className="w-full h-full object-cover rounded-md" />
                                    <button onClick={() => onRemoveClothingReference(char.id, 'text')} className="absolute top-1 right-1 bg-black/50 text-white rounded-full p-0 w-5 h-5 flex items-center justify-center">&times;</button>
                                </div>
                                <Button onClick={() => handleDescribeClothing(char.id, char.clothingReference!)} disabled={disabled || !!describingClothingId} isLoading={describingClothingId === char.id} fullWidth variant="secondary" className="text-xs p-1.5">
                                    Descrever Roupa
                                </Button>
                            </div>
                        ) : (
                            <label htmlFor={`text-clothing-upload-${char.id}`} className={`group block w-full p-3 text-center border-2 border-dashed rounded-md transition-colors border-slate-600 ${disabled ? 'cursor-not-allowed opacity-50' : 'cursor-pointer hover:border-yellow-500 hover:bg-slate-800'}`}>
                                <p className="text-[10px] text-slate-500 mb-2">Se não anexada, a IA usará a roupa da descrição de aparência.</p>
                                <div className="inline-block text-xs px-4 py-1.5 bg-slate-700 group-hover:bg-slate-600 rounded-md text-slate-300 font-semibold">
                                    Carregar Roupa
                                </div>
                            </label>
                        )}
                        <input type="file" id={`text-clothing-upload-${char.id}`} className="hidden" accept="image/png, image/jpeg, image/webp" onChange={(e) => handleClothingReferenceUpload(e, char.id)} disabled={disabled} />
                        {clothingDescriptions[char.id] && (
                            <div className="p-2 bg-slate-900/50 rounded-md">
                                <div className="flex justify-between items-center mb-1">
                                    <h4 className="text-xs font-semibold text-yellow-400">Descrição da Roupa</h4>
                                    <button onClick={() => setClothingDescriptions(p => ({...p, [char.id]: ''}))} className="text-slate-500 hover:text-white" title="Fechar">&times;</button>
                                </div>
                                <textarea value={clothingDescriptions[char.id]} onChange={(e) => setClothingDescriptions(p => ({ ...p, [char.id]: e.target.value }))} className="w-full h-24 p-1.5 text-xs bg-slate-700 border-slate-600 rounded-md text-slate-300 resize-none" />
                                <div className="mt-1 flex space-x-2">
                                    <button onClick={() => navigator.clipboard.writeText(clothingDescriptions[char.id])} className="w-1/2 text-xs p-1 bg-slate-600 hover:bg-slate-500 rounded-md">Copiar</button>
                                    <button onClick={() => handleTranslateDescription(char.id, clothingDescriptions[char.id])} disabled={disabled || !!translatingDescriptionId} className="w-1/2 text-xs p-1 bg-slate-600 hover:bg-slate-500 rounded-md flex items-center justify-center"> {translatingDescriptionId === char.id ? <Spinner className="h-4 w-4" /> : <><TranslateIcon /> <span className="ml-1">Traduzir</span></>} </button>
                                </div>
                            </div>
                        )}
                    </div>

                </div>
            )})}

            <Button onClick={onAdd} variant="secondary" fullWidth disabled={disabled}>
                Adicionar Outro Personagem
            </Button>
        </div>
    );
};

export default TextCharacterCreator;