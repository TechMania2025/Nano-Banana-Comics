
import React, { ReactNode } from 'react';
import Spinner from './Spinner';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
    children: ReactNode;
    isLoading?: boolean;
    variant?: 'primary' | 'secondary';
    fullWidth?: boolean;
}

const Button: React.FC<ButtonProps> = ({ children, isLoading, variant = 'primary', fullWidth, ...props }) => {
    const baseClasses = 'inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed';

    const variantClasses = {
        primary: 'text-white bg-yellow-600 hover:bg-yellow-700 focus:ring-yellow-500',
        secondary: 'text-slate-300 bg-slate-700 hover:bg-slate-600 focus:ring-slate-500',
    };

    const widthClass = fullWidth ? 'w-full' : '';

    return (
        <button
            {...props}
            disabled={isLoading || props.disabled}
            className={`${baseClasses} ${variantClasses[variant]} ${widthClass}`}
        >
            {isLoading ? <Spinner /> : children}
        </button>
    );
};

export default Button;
