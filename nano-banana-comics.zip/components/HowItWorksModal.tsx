import React from 'react';
import Modal from './Modal';

const content = {
    title: "Como Funciona",

    step1Title: "Passo 1: A Base da Sua História",
    step1Content: `Aqui você define os fundamentos da sua obra:
- **Título do Quadrinho**: O nome da sua história. Ative "Exibir no painel" para que ele apareça de forma estilizada na primeira página.
- **Tipo de Quadrinho**: Define a identidade visual e o modo de cor padrão. Estilos como 'Manga', 'American (Underground)' e 'Indie/Alternative' são P&B por padrão; os outros são coloridos.
- **Gênero**: Crucial para o tom geral e para habilitar opções de 'Atmosfera' relevantes (ex: 'Caos' para Ação, 'Romântico' para Romance).
- **Estilo do Artista**: Inspira o traço da IA. Deixar em branco dá liberdade criativa à IA. Se usar imagens de referência com "Manter estilo", este campo é ignorado.
- **Páginas**: Quantas páginas sua história terá.
- **Preencher painel completamente**: Uma opção nas configurações principais que remove as bordas brancas, fazendo a arte preencher todo o painel. É ideal para um visual moderno e já vem ativado por padrão.
- **Gerar em Cores**: Permite forçar a geração em cores. Esta opção está disponível apenas para os estilos 'Manga' e 'Manga (Mecha)', que são P&B por padrão.
- **Texto em Português**: Garante que todos os textos (diálogos, onomatopeias) sejam gerados em Português do Brasil.`,

    step2Title: "Passo 2: Criando Personagens Consistentes",
    step2Content: `Você tem duas formas de criar personagens (uma exclui a outra):
1.  **Imagens de Referência**: Envie uma ou mais imagens de um personagem. **Dica crucial**: Dê um nome a ele! É assim que a IA o reconhecerá e o manterá consistente.
2.  **Criação por Texto**: Se não tiver imagens, clique em "Criar Personagens por Texto". Descreva o nome (essencial!) e a aparência física.

Para ambos os métodos:
- **Manter Estilo de Arte**: Com imagens de referência, esta opção força a IA a imitar o estilo da sua imagem, ignorando o "Estilo do Artista".
- **Habilitar Detalhes do Personagem**: Libera os campos "Personas", onde você pode adicionar até três traços de personalidade (ex: 'arrogante', 'tímido'). Isso guiará as expressões e ações do personagem. Se deixado em branco, a IA deduzirá a personalidade da aparência.
- **Roupa Casual (Referência)**: Para cada personagem, você pode anexar uma imagem específica de sua roupa casual. Esta imagem terá prioridade máxima para definir o vestuário do personagem, sobrepondo-se à roupa da imagem de referência principal ou a qualquer outra instrução.`,

    step3Title: "Passo 3: Dando Vida a Cada Painel",
    step3Content: `Cada painel é uma cena, e você tem controle total. Lembre-se: qualquer campo deixado em "Automático" ou vazio dá liberdade criativa para a IA decidir o melhor para a cena.

- **Descrição da Cena**: Este é o comando mais importante. O que você escreve aqui tem prioridade sobre todas as outras configurações.
- **Cenário (Descrição ou Imagem)**: Descreva o ambiente ou envie uma imagem de fundo. No Painel 1, você pode usar a opção "Cenário Mestre" para que ele se aplique a todos os outros painéis da página. **Importante**: Para evitar conflitos, se você digitar uma descrição, os campos para enviar imagens de fundo e de objetos ficarão ocultos. Apague o texto para que eles reapareçam.
- **Controles de Personagem**: Para cada personagem nomeado, você pode especificar seu **Diálogo** (o que ele diz), **Comportamento** (o que ele faz ou sente) e **Emoção** (a expressão facial que ele deve ter).
- **Comportamento dos Figurantes**: Descreva o que os personagens de fundo estão fazendo.
- **Direção de Arte e Câmera**: Use os menus para definir o **Enquadramento** (Close-up, Plano Geral), **Tamanho do Painel**, **Ângulo do Personagem** e **Nível de Detalhe**.
- **Contexto e Atmosfera**:
    - **Contexto do Conteúdo**: Define um traje padrão (ex: 'Roupas de Verão', 'Yukata', 'Uniforme Esportivo'), mas só se a "Descrição da Cena" não mencionar roupas.
    - **Atmosfera**: Cria o clima emocional. 'Caos' adiciona destruição ao cenário; 'Tensão' usa sombras e ângulos opressivos.
- **Regras e Exceções**: No novo layout de Controles de Personagem, você pode excluir personagens de um painel específico usando a caixa de seleção ao lado do nome deles. Use também as caixas de seleção inferiores para remover diálogos, efeitos sonoros ou acessórios.
- **Ferramentas de IA**:
    - **Traduzir**: Converte seu texto para Inglês (preservando nomes de personagens) para melhor interpretação da IA.
    - **Detalhar**: Expande uma ideia simples ("herói olha para o vilão") em uma descrição rica e vívida para a IA.`,

    step4Title: "Passo 4: Geração e Pós-Produção",
    step4Content: `Antes de a geração começar, a IA faz uma verificação final. Se ela detectar que uma imagem de cenário parece um personagem, ou um objeto parece um cenário, um aviso aparecerá. Você pode então escolher corrigir ou continuar mesmo assim.

Após clicar em "Gerar Quadrinho", suas páginas aparecerão. Selecione qualquer painel para abrir as ferramentas de edição:
- **Ver Painel Completo**: Abre uma visualização em tela cheia com botão para baixar a imagem.
- **Refazer**: Gera novamente apenas o painel selecionado usando as mesmas configurações.
- **Analisar Incoerência**: Uma ferramenta especial que instrui a IA a examinar o painel selecionado em busca de erros lógicos ou físicos (como uma TV ao contrário, alguém nadando na areia) e tentar corrigi-los, mantendo o estilo e a intenção da cena.
- **Lembrar Aparência**: Uma ferramenta poderosa para manter a consistência das roupas. Ao selecionar um painel gerado, o botão "Lembrar Aparência" mostrará uma lista de seus personagens nomeados. Ao escolher um personagem, a imagem daquele painel é salva como uma referência visual para ele. Esta referência aparecerá como uma miniatura abaixo do personagem no painel de controle esquerdo. Enquanto essa miniatura estiver ativa, a IA será instruída a replicar exatamente aquela roupa em todas as gerações futuras para aquele personagem, ignorando qualquer outra instrução de vestuário. Você pode "Esquecer" a aparência a qualquer momento para liberar a IA, ou substituí-la selecionando um novo painel.
- **Corrigir Texto**: Esta ferramenta foi transformada em um assistente de roteiro inteligente:
    - **Sugestões de Diálogo**: A IA lê o diálogo original e oferece até três alternativas mais criativas e impactantes para a cena.
    - **Corrigir Ortografia**: A IA detecta erros no seu texto e sugere até três formas de corrigi-los.
    - **Apagar Texto**: Oferece duas opções. Você pode apagar **apenas o texto**, deixando os balões de diálogo vazios, ou apagar **texto e balões**, fazendo a IA reconstruir a arte do fundo como se nunca tivessem existido.
- **Editar Painel**: A ferramenta de edição mais direta. Ao clicar, abre uma janela onde você pode simplesmente escrever o que quer mudar na imagem (ex: "Adicione óculos de sol no personagem", "Faça a cena ficar chuvosa"). A IA tentará aplicar sua alteração em tempo real.`,

    finalTip: `Sua criatividade é o motor. A IA é sua ferramenta. A combinação dos dois é ilimitada. Deixar campos em "Automático" ou vazios convida a IA a colaborar criativamente, enquanto preenchê-los dá a você controle total. Experimente para encontrar o balanço perfeito!`,
};


interface HowItWorksModalProps {
    onClose: () => void;
}

const HowItWorksModal: React.FC<HowItWorksModalProps> = ({ onClose }) => {
    const Section: React.FC<{ title: string; children: string }> = ({ title, children }) => {
        // Parse the string for markdown-style bold (`**text**`) and replace with <strong> tags.
        const parts = children.split(/(\*\*.*?\*\*)/g);
        const formattedContent = parts.map((part, index) => {
            if (part.startsWith('**') && part.endsWith('**')) {
                return <strong key={index}>{part.slice(2, -2)}</strong>;
            }
            return part;
        });

        return (
            <div className="mb-6">
                <h3 className="text-xl font-semibold text-yellow-400 mb-2">{title}</h3>
                <p className="text-slate-300 leading-relaxed whitespace-pre-wrap">
                    {formattedContent}
                </p>
            </div>
        );
    };

    return (
        <Modal title={content.title} onClose={onClose} size="3xl">
            <div>
                <Section title={content.step1Title}>{content.step1Content}</Section>
                <Section title={content.step2Title}>{content.step2Content}</Section>
                <Section title={content.step3Title}>{content.step3Content}</Section>
                <Section title={content.step4Title}>{content.step4Content}</Section>

                <div className="mt-6 p-4 bg-slate-900/50 rounded-lg border-l-4 border-yellow-500">
                    <p className="text-slate-300 font-medium">{content.finalTip}</p>
                </div>
            </div>
        </Modal>
    );
};

export default HowItWorksModal;