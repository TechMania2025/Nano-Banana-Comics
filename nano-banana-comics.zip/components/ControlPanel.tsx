

import React from 'react';
import { AppState, PanelConfig, ContentContext, TextCharacter } from '../types';
import Button from './Button';
import MultiImageUploader from './MultiImageUploader';
import PanelConfiguration from './PanelConfiguration';
import TextCharacterCreator from './TextCharacterCreator';
import { fileToBase64 } from '../utils';
import { ARTIST_STYLES_MAP, GENRE_OPTIONS, GENRE_MAP } from '../constants';
import * as geminiService from '../services/geminiService';
import Spinner from './Spinner';

interface ControlPanelProps {
    appState: AppState;
    onStateChange: <K extends keyof AppState>(key: K, value: AppState[K]) => void;
    onGenerate: () => void;
    onClearAll: () => void;
    onImageNameChange: (id: string, name: string) => void;
    onImagePersonaChange: (id: string, index: number, value: string) => void;
    onImageDetailChange: (id: string, field: 'age' | 'height', value: string) => void;
    onAddPanel: () => void;
    onRemovePanel: (index: number) => void;
    onPanelConfigChange: (index: number, newConfig: PanelConfig) => void;
    onSplitPanel: (index: number, direction: 'Split Horizontally' | 'Split Vertically') => void;
    onTranslatePanel: (text: string, panelIndex: number) => void;
    onDetailPanel: (panelIndex: number) => void;
    onOpenPromptEditor: (panelIndex: number) => void;
    onOpenPromptHelper: (panelIndex: number) => void;
    onAddTextCharacter: () => void;
    onRemoveTextCharacter: (id: string) => void;
    onUpdateTextCharacter: (id: string, field: 'name' | 'appearance' | 'age' | 'height', value: string) => void;
    onUpdateTextCharacterPersona: (id: string, index: number, value: string) => void;
    onClearTextCharacters: () => void;
    onClearAppearanceMemory: (characterName: string) => void;
    onSetClothingReference: (characterId: string, characterType: 'image' | 'text', file: File) => void;
    onRemoveClothingReference: (characterId: string, characterType: 'image' | 'text') => void;
}

const TranslateIcon = () => ( <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}> <path strokeLinecap="round" strokeLinejoin="round" d="M3 5h12M9 3v2m4 13l4-4M19 17l-4-4M3 19h12a2 2 0 002-2V7a2 2 0 00-2-2H3a2 2 0 00-2 2v10a2 2 0 002 2z" /> </svg> );

const ControlPanel: React.FC<ControlPanelProps> = (props) => {
    const { 
        appState, onStateChange, onGenerate, onClearAll, onImageNameChange, onImagePersonaChange,
        onImageDetailChange,
        onAddPanel, onRemovePanel, onPanelConfigChange, onSplitPanel, onTranslatePanel,
        onDetailPanel, onOpenPromptEditor, onOpenPromptHelper,
        onAddTextCharacter, onRemoveTextCharacter, onUpdateTextCharacter, onClearTextCharacters,
        onUpdateTextCharacterPersona, onClearAppearanceMemory,
        onSetClothingReference, onRemoveClothingReference
    } = props;
    const { 
        comicTitle, artistStyle, referenceImages, numPages, panelConfigs, isLoading, 
        maintainReferenceStyle, generateInPortuguese, comicStyle, isColor,
        genre, appearanceMemory, displayTitleOnPanel, characterDetailsEnabled,
        useGlobalScenario, textCharacters, fillPanelCompletely
    } = appState;
    const [selectedArtistWork, setSelectedArtistWork] = React.useState<string | null>(null);
    const [translatingField, setTranslatingField] = React.useState<string | null>(null);

    const currentArtistList = React.useMemo(() => {
        return ARTIST_STYLES_MAP[comicStyle] || [];
    }, [comicStyle]);

    React.useEffect(() => {
        // Find artist in the current dynamic list
        const artist = currentArtistList.find(a => a.name === artistStyle);
        setSelectedArtistWork(artist ? artist.work : null);

        // If the selected artist is not in the new list, clear it
        if (artistStyle && !artist) {
            onStateChange('artistStyle', '');
        }
    }, [artistStyle, currentArtistList, onStateChange]);


    React.useEffect(() => {
        // Automatically set color based on comic style, but allow user override.
        // This effect runs only when comicStyle changes.
        switch (comicStyle) {
            case 'Manga':
            case 'Mecha Manga':
            case 'Indie/Alternative':
            case 'American (Underground)':
            case 'European (Underground)':
            case 'Italian Fumetti':
            case 'Argentine Historietas':
                onStateChange('isColor', false);
                break;
            case 'Manhwa':
            case 'Manhua':
            case 'Webtoon':
            case 'American (Modern)':
            case 'American (Golden Age)':
            case 'American (Silver Age)':
            case 'Franco-Belgian':
            case 'Brazilian HQ':
            case 'Disney Style':
                onStateChange('isColor', true);
                break;
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [comicStyle]);
    
    const handleTranslate = async (field: 'comicTitle' | 'artistStyle', value: string) => {
        if (!value || translatingField) return;
        setTranslatingField(field);
        try {
            const translatedText = await geminiService.translateText(value, []);
            onStateChange(field, translatedText);
        } catch (error) {
            console.error(`Translation for ${field} failed`, error);
        } finally {
            setTranslatingField(null);
        }
    };

    const handleImageUpload = async (files: FileList) => {
        if (files.length > 0) {
            const imagePromises = Array.from(files).map(file => fileToBase64(file));
            const newImages = await Promise.all(imagePromises);
            onStateChange('referenceImages', [...referenceImages, ...newImages]);
            onStateChange('textCharacters', []); // Enforce mutual exclusivity
        }
    };
    
    const handleImageClear = (id: string) => {
        onStateChange('referenceImages', referenceImages.filter(img => img.id !== id));
    };

    return (
        <div className="bg-slate-800/50 rounded-lg shadow-lg p-4 space-y-4">
            <h2 className="text-xl font-bold text-center text-slate-200">Painel de Controle</h2>
            
             {/* Global Settings */}
            <div className="space-y-3">
                <h3 className="text-md font-semibold text-slate-200 border-b border-slate-700 pb-2">Configurações Globais</h3>
                
                <div className="relative">
                    <label htmlFor="comic-title" className="text-sm font-medium text-slate-300">Título do Quadrinho</label>
                    <input
                        id="comic-title"
                        type="text"
                        value={comicTitle}
                        onChange={(e) => onStateChange('comicTitle', e.target.value)}
                        placeholder="Ex: A Lenda da Banana de Cristal"
                        className="w-full mt-1 p-2 bg-slate-700 border border-slate-600 rounded-md focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors pr-8"
                        disabled={isLoading}
                    />
                     <button
                        onClick={() => handleTranslate('comicTitle', comicTitle)}
                        disabled={!comicTitle.trim() || !!translatingField || isLoading}
                        className="absolute top-8 right-2 text-slate-400 hover:text-yellow-400 disabled:opacity-50 disabled:cursor-not-allowed"
                        title="Traduzir para o inglês"
                    >
                        {translatingField === 'comicTitle' ? <Spinner className="h-4 w-4" /> : <TranslateIcon />}
                    </button>
                </div>
                 <div className="flex items-start space-x-2">
                    <input
                        type="checkbox"
                        id="display-title-toggle"
                        checked={displayTitleOnPanel}
                        onChange={(e) => onStateChange('displayTitleOnPanel', e.target.checked)}
                        disabled={isLoading}
                        className="mt-1 w-4 h-4 text-yellow-600 bg-slate-700 border-slate-600 rounded focus:ring-yellow-500"
                    />
                    <label htmlFor="display-title-toggle" className="text-sm text-slate-300">Exibir título no primeiro painel</label>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="comic-style" className="text-sm font-medium text-slate-300">Tipo de Quadrinho</label>
                         <select
                            id="comic-style"
                            value={comicStyle}
                            onChange={(e) => onStateChange('comicStyle', e.target.value as AppState['comicStyle'])}
                            className="w-full mt-1 p-2 bg-slate-700 border border-slate-600 rounded-md focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
                            disabled={isLoading}
                        >
                            <option value="Manga">Manga</option>
                            <option value="Mecha Manga">Manga (Mecha)</option>
                            <option value="Manhwa">Manhwa (Coreano)</option>
                            <option value="Manhua">Manhua (Chinês)</option>
                            <option value="Webtoon">Webtoon</option>
                            <option value="American (Modern)">Americano (Moderno)</option>
                            <option value="American (Golden Age)">Americano (Era de Ouro)</option>
                            <option value="American (Silver Age)">Americano (Era de Prata)</option>
                            <option value="American (Underground)">Americano (Underground)</option>
                            <option value="Franco-Belgian">Franco-Belga</option>
                            <option value="European (Underground)">Europeu (Underground)</option>
                            <option value="Italian Fumetti">Italiano (Fumetti)</option>
                            <option value="Argentine Historietas">Argentino (Historietas)</option>
                            <option value="Brazilian HQ">Brasileiro (HQ)</option>
                            <option value="Disney Style">Estilo Disney</option>
                            <option value="Indie/Alternative">Indie/Alternativo</option>
                        </select>
                    </div>
                     <div>
                        <label htmlFor="genre" className="text-sm font-medium text-slate-300">Gênero</label>
                        <select
                            id="genre"
                            value={genre}
                            onChange={(e) => onStateChange('genre', e.target.value)}
                            className="w-full mt-1 p-2 bg-slate-700 border border-slate-600 rounded-md focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
                            disabled={isLoading}
                        >
                            {GENRE_OPTIONS.map(g => <option key={g} value={g}>{GENRE_MAP[g] || g}</option>)}
                        </select>
                    </div>
                </div>

                <div>
                    <div className="flex items-center justify-between">
                        <label htmlFor="artist-style" className="text-sm font-medium text-slate-300">Estilo do Artista (Opcional)</label>
                        {selectedArtistWork && <span className="text-xs text-slate-400">Trabalho Notável: {selectedArtistWork}</span>}
                    </div>
                    <div className="relative">
                        <input
                            id="artist-style"
                            type="text"
                            value={artistStyle}
                            onChange={(e) => onStateChange('artistStyle', e.target.value)}
                            placeholder="Ex: Kentaro Miura, Akira Toriyama"
                            list="artist-styles-list"
                            className="w-full mt-1 p-2 bg-slate-700 border border-slate-600 rounded-md focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors pr-8"
                            disabled={isLoading}
                        />
                         <button
                            onClick={() => handleTranslate('artistStyle', artistStyle)}
                            disabled={!artistStyle.trim() || !!translatingField || isLoading}
                            className="absolute top-2 right-2 text-slate-400 hover:text-yellow-400 disabled:opacity-50 disabled:cursor-not-allowed"
                            title="Traduzir para o inglês"
                        >
                            {translatingField === 'artistStyle' ? <Spinner className="h-4 w-4" /> : <TranslateIcon />}
                        </button>
                        <datalist id="artist-styles-list">
                            {currentArtistList.map(style => <option key={style.name} value={style.name} />)}
                        </datalist>
                    </div>
                </div>

                <div>
                    <label htmlFor="num-pages" className="text-sm font-medium text-slate-300">Páginas</label>
                    <input
                        id="num-pages"
                        type="number"
                        value={numPages}
                        onChange={(e) => onStateChange('numPages', parseInt(e.target.value, 10) || 1)}
                        min="1"
                        max="5"
                        className="w-full mt-1 p-2 bg-slate-700 border border-slate-600 rounded-md"
                        disabled={isLoading}
                    />
                </div>
                 <div className="flex flex-col space-y-2">
                    {(comicStyle === 'Manga' || comicStyle === 'Mecha Manga') && (
                        <div className="flex items-start space-x-2">
                            <input
                                type="checkbox"
                                id="color-toggle"
                                checked={isColor}
                                onChange={(e) => onStateChange('isColor', e.target.checked)}
                                disabled={isLoading}
                                className="mt-1 w-4 h-4 text-yellow-600 bg-slate-700 border-slate-600 rounded focus:ring-yellow-500"
                            />
                            <label htmlFor="color-toggle" className="text-sm text-slate-300">Gerar em Cores</label>
                        </div>
                    )}
                     <div className="flex items-start space-x-2">
                        <input
                            type="checkbox"
                            id="language-toggle"
                            checked={generateInPortuguese}
                            onChange={(e) => onStateChange('generateInPortuguese', e.target.checked)}
                            disabled={isLoading}
                            className="mt-1 w-4 h-4 text-yellow-600 bg-slate-700 border-slate-600 rounded focus:ring-yellow-500"
                        />
                        <label htmlFor="language-toggle" className="text-sm text-slate-300">Gerar textos em Português</label>
                    </div>
                     <div className="flex items-start space-x-2">
                        <input
                            type="checkbox"
                            id="fill-panel-toggle"
                            checked={fillPanelCompletely}
                            onChange={(e) => onStateChange('fillPanelCompletely', e.target.checked)}
                            disabled={isLoading}
                            className="mt-1 w-4 h-4 text-yellow-600 bg-slate-700 border-slate-600 rounded focus:ring-yellow-500"
                        />
                        <label htmlFor="fill-panel-toggle" className="text-sm text-slate-300">Preencher painel completamente</label>
                    </div>
                </div>
            </div>

            {/* Character Controls */}
            <div className="space-y-3">
                 <h3 className="text-md font-semibold text-slate-200 border-b border-slate-700 pb-2">Personagens e Referências</h3>
                 {referenceImages.length > 0 && (
                     <div className="flex items-start space-x-2">
                        <input
                            type="checkbox"
                            id="maintain-style-toggle"
                            checked={maintainReferenceStyle}
                            onChange={(e) => onStateChange('maintainReferenceStyle', e.target.checked)}
                            disabled={isLoading}
                            className="mt-1 w-4 h-4 text-yellow-600 bg-slate-700 border-slate-600 rounded focus:ring-yellow-500"
                        />
                        <label htmlFor="maintain-style-toggle" className="text-sm text-slate-300">Manter estilo de arte da imagem de referência</label>
                    </div>
                 )}
                 <div className="flex items-start space-x-2">
                    <input
                        type="checkbox"
                        id="character-details-toggle"
                        checked={characterDetailsEnabled}
                        onChange={(e) => onStateChange('characterDetailsEnabled', e.target.checked)}
                        disabled={isLoading}
                        className="mt-1 w-4 h-4 text-yellow-600 bg-slate-700 border-slate-600 rounded focus:ring-yellow-500"
                    />
                    <label htmlFor="character-details-toggle" className="text-sm text-slate-300">Habilitar detalhes do personagem (Personas)</label>
                </div>

                <MultiImageUploader
                    images={referenceImages}
                    onImageUpload={handleImageUpload}
                    onImageClear={handleImageClear}
                    onImageNameChange={onImageNameChange}
                    onImagePersonaChange={onImagePersonaChange}
                    onImageDetailChange={onImageDetailChange}
                    characterDetailsEnabled={characterDetailsEnabled}
                    disabled={isLoading || textCharacters.length > 0}
                    appearanceMemory={appearanceMemory}
                    onClearAppearanceMemory={onClearAppearanceMemory}
                    onSetClothingReference={(id, type, file) => onSetClothingReference(id, 'image', file)}
                    onRemoveClothingReference={(id, type) => onRemoveClothingReference(id, 'image')}
                />

                <TextCharacterCreator
                    characters={textCharacters}
                    onAdd={onAddTextCharacter}
                    onRemove={onRemoveTextCharacter}
                    onUpdate={onUpdateTextCharacter}
                    onUpdatePersona={onUpdateTextCharacterPersona}
                    onClear={onClearTextCharacters}
                    characterDetailsEnabled={characterDetailsEnabled}
                    disabled={isLoading || referenceImages.length > 0}
                    appearanceMemory={appearanceMemory}
                    onClearAppearanceMemory={onClearAppearanceMemory}
                    onSetClothingReference={(id, type, file) => onSetClothingReference(id, 'text', file)}
                    onRemoveClothingReference={(id, type) => onRemoveClothingReference(id, 'text')}
                />
            </div>
            
            {/* Panel Configuration */}
            <PanelConfiguration
                configs={panelConfigs}
                referenceImages={referenceImages}
                textCharacters={textCharacters}
                genre={genre}
                onConfigChange={onPanelConfigChange}
                onAddPanel={onAddPanel}
                onRemovePanel={onRemovePanel}
                onSplitPanel={onSplitPanel}
                onTranslatePanel={onTranslatePanel}
                onDetailPanel={onDetailPanel}
                onOpenPromptEditor={onOpenPromptEditor}
                onOpenPromptHelper={onOpenPromptHelper}
                isLoading={isLoading}
                useGlobalScenario={useGlobalScenario}
                onStateChange={onStateChange}
            />

            {/* Main Generation Controls */}
            <div className="flex space-x-2 pt-4 border-t border-slate-700">
                <Button onClick={onGenerate} isLoading={isLoading} fullWidth>
                    Gerar Imagens do Quadrinho
                </Button>
                <Button onClick={onClearAll} variant="secondary" disabled={isLoading} fullWidth>
                    Limpar Tudo
                </Button>
            </div>
        </div>
    );
};

export default ControlPanel;