
import React, { useState } from 'react';
import Modal from './Modal';
import Button from './Button';

interface PromptEditorModalProps {
    initialPrompt: string;
    onSave: (prompt: string) => void;
    onClose: () => void;
}

const PromptEditorModal: React.FC<PromptEditorModalProps> = ({ initialPrompt, onSave, onClose }) => {
    const [prompt, setPrompt] = useState(initialPrompt);

    const handleSave = () => {
        onSave(prompt);
        onClose();
    };

    return (
        <Modal title="Editor de Prompt" onClose={onClose} size="2xl">
            <div className="flex flex-col h-[60vh]">
                <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    className="w-full flex-grow p-2 bg-slate-700 border border-slate-600 rounded-md focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 transition-colors"
                    placeholder="Descreva sua visão em detalhes..."
                />
                <div className="mt-4 flex justify-end">
                    <Button onClick={handleSave}>Salvar e Fechar</Button>
                </div>
            </div>
        </Modal>
    );
};

export default PromptEditorModal;
