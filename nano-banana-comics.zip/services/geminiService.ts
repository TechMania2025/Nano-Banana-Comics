import { GoogleGenAI, GenerateContentResponse, Modality, Type } from "@google/genai";
// FIX: Added 'PanelOutput' to the import list to resolve a type error.
import { AppState, CorrectionPayload, PanelConfig, TextCharacter, ImageData, PanelOutput } from '../types';

const API_KEY = process.env.API_KEY;
if (!API_KEY) {
    throw new Error("API_KEY environment variable not set");
}
const ai = new GoogleGenAI({ apiKey: API_KEY });

const dataUrlToPart = (dataUrl: string, mimeType: string) => ({
    inlineData: {
        data: dataUrl.split(',')[1],
        mimeType: mimeType,
    },
});

const buildPanelPayload = (appState: AppState, panelConfig: PanelConfig, index: number) => {
    const allCharacters = (appState.referenceImages.length > 0 ? appState.referenceImages : appState.textCharacters) as (ImageData | TextCharacter)[];

    let characterInfo = '';
    const namedImages = appState.referenceImages.filter(img => img.name && img.name.trim() !== '');
    
    if (namedImages.length > 0) {
        characterInfo = 'Reference Character/Object Information:\n';
        appState.referenceImages.forEach((img, idx) => {
            if (img.name && img.name.trim() !== '') {
                let charInfo = `- The character/object in reference image ${idx + 1} is named '${img.name}'.`;
                if (img.age) charInfo += ` Age: ${img.age}.`;
                if (img.height) charInfo += ` Height: ${img.height}.`;
                if (appState.characterDetailsEnabled) {
                    const definedPersonas = (img.personas || []).filter(p => p && p.trim() !== '').join(', ');
                    if (definedPersonas) {
                        charInfo += ` Personas: ${definedPersonas}. These personas guide their actions, expressions, and behavior.`;
                    } else {
                        charInfo += ` No personas provided; you have creative freedom to assign a personality fitting their appearance.`;
                    }
                }
                characterInfo += charInfo + '\n';
            }
        });
        characterInfo += 'Use these names and personality traits to inform character actions, expressions, and dialogue.\n\n';

        if (appState.maintainReferenceStyle) {
            characterInfo += 'CRITICAL CHARACTER CONSISTENCY: The appearance of any character provided in the reference images MUST be replicated with absolute precision in every detail (face, hair, build, etc.). Do not deviate from their established design.\n\n';
        }

    } else if (appState.textCharacters && appState.textCharacters.length > 0) {
        characterInfo = 'Character Descriptions (You MUST create and maintain these appearances consistently across all panels):\n';
        appState.textCharacters.forEach(char => {
            if (char.name && char.name.trim() !== '') {
                let charDesc = `- Name: '${char.name}'.`;
                if (char.appearance) {
                    charDesc += ` Appearance: '${char.appearance}'.`;
                }
                if (char.age) charDesc += ` Age: ${char.age}.`;
                if (char.height) charDesc += ` Height: ${char.height}.`;
                if (appState.characterDetailsEnabled) {
                    const definedPersonas = (char.personas || []).filter(p => p && p.trim() !== '').join(', ');
                     if (definedPersonas) {
                        charDesc += ` Personas: '${definedPersonas}'. This guides their actions, expressions, and behavior.`;
                    }
                }
                characterInfo += charDesc + '\n';
            }
        });
        characterInfo += 'Use these names, appearances, and personas to inform character actions, expressions, and dialogue.\n\n';
    }

    const styleInstruction = appState.maintainReferenceStyle && appState.referenceImages.length > 0
        ? 'The art style MUST strictly match the style of the provided reference image(s).'
        : `The art style should be inspired by ${appState.artistStyle || 'a generic modern shonen manga style'}.`;

    const languageInstruction = appState.generateInPortuguese
        ? 'You are generating a comic for a Brazilian audience. IMPORTANT: Any dialogue, narration, sound effects, or other text within the panel MUST be written in Brazilian Portuguese, including all accents and diacritics (e.g., á, ç, ã, ê). For example, "I am powerful" should be translated as "Eu sou poderoso/a".'
        : 'All text inside the panel, such as dialogue or sound effects, should be in English.';

    const colorInstruction = appState.isColor
        ? 'The panel MUST be in full color.'
        : 'The panel MUST be in black and white. Use screen tones, clean line art, and high contrast.';
    
    const comicStyleInstruction = {
        'Manga': 'in the style of a professional Japanese manga.',
        'Mecha Manga': 'in the style of a classic Japanese mecha or super sentai manga. Focus on detailed, powerful giant robots, dynamic action scenes, and a sense of immense scale.',
        'Manhwa': 'in the style of a professional full-color Korean webtoon (manhwa).',
        'Manhua': 'in the style of a professional full-color Chinese comic (manhua).',
        'Webtoon': 'in the style of a modern digital webtoon, designed for vertical scrolling on mobile devices. Use long vertical panels, vibrant colors, and a clean, polished art style.',
        'American (Modern)': 'in the style of a modern, full-color American superhero comic (e.g., DC, Marvel). Use dynamic paneling and a clean, detailed art style.',
        'American (Golden Age)': 'in the style of a classic American comic book from the Golden Age (late 1930s to early 1950s). Use bold, simple line art, a limited color palette with Ben-Day dots, and a more theatrical, heroic tone.',
        'American (Silver Age)': 'in the style of an American comic book from the Silver Age (mid-1950s to 1970s). The art should be more dynamic and refined than the Golden Age, with brighter colors and more sci-fi or fantastical elements.',
        'American (Underground)': 'in the style of American underground comix from the 1960s and 70s (like Robert Crumb). Use a raw, often grotesque, heavily cross-hatched, black and white style with a focus on satire and counter-culture themes.',
        'Franco-Belgian': 'in the style of a classic Franco-Belgian "bande dessinée" comic (e.g., Tintin, Asterix). Use the "ligne claire" (clear line) style with strong, clear lines and uniform colors.',
        'European (Underground)': 'in the style of European underground "comix". The art should be politically charged, experimental, and often surreal, in a black and white, high-contrast style.',
        'Italian Fumetti': 'in the style of a classic Italian "fumetti neri" or adventure comic. Use a dramatic, high-contrast black and white style with heavy use of shadows, cinematic angles, and a realistic yet stylized approach to figures.',
        'Argentine Historietas': 'in the style of a classic Argentine "historietas". The art should be dense, detailed, and often feature social or political commentary, rendered in a gritty, high-contrast black and white style.',
        'Brazilian HQ': 'in the style of a classic Brazilian comic book ("HQ"), like "Turma da Mônica". Use a clean, rounded, cartoonish art style with bright, solid colors, suitable for all ages.',
        'Disney Style': 'in the style of classic Disney comics. Use a very clean, expressive, and bouncy "rubber hose" or cartoon animation style with clear outlines and solid colors.',
        'Indie/Alternative': 'in the style of a black and white independent or alternative comic. Use a more experimental, gritty, or personal art style with heavy use of shadow and texture.'
    }[appState.comicStyle];
    
    const contentContexts = [];
    
    const createClothingContextInstruction = (description: string): string => {
        return `This scene has a specific clothing context. ${description}. This is a strict directive that applies ONLY if the main scene description for this panel does NOT specify what the characters are wearing. If the prompt mentions clothing, the prompt takes absolute priority.`;
    };

    switch (panelConfig.contentContext) {
        case 'Intense Action/Battle':
            contentContexts.push('This specific scene depicts a shounen-style battle or fight. The composition should be dynamic, conveying high energy and action with dramatic impact effects.');
            break;
        case 'Mahou Shoujo Outfit':
            contentContexts.push(createClothingContextInstruction("Characters are in Mahou Shoujo (Magical Girl) outfits. They MUST wear these outfits. The clothing should be fantastical, ornate, and reflect the magical girl theme, often with frills, ribbons, and a specific color scheme for the character."));
            break;
        case 'Superhero Costume':
            contentContexts.push(createClothingContextInstruction("Characters are in superhero costumes. They MUST wear their costumes. The outfits should be iconic, practical for combat or their powers, and reflect the character's theme and identity (e.g., capes, masks, emblems)."));
            break;
        case 'School Uniform':
             contentContexts.push(createClothingContextInstruction("Characters MUST be wearing appropriate school uniforms. For a Japanese setting (Manga), this is typically a 'seifuku' (sailor outfit) or 'gakuran' (blazer style). Adapt the uniform style to the comic's setting and tone."));
            break;
        case 'Casual Wear':
             contentContexts.push(createClothingContextInstruction("Characters MUST be wearing modern, everyday casual clothing suitable for their age and personality. Avoid uniforms or costumes."));
            break;
        case 'Gym Clothes':
             contentContexts.push(createClothingContextInstruction("Characters are exercising or in a gym setting and MUST be wearing appropriate athletic or gym clothes (e.g., tracksuits, shorts, t-shirts)."));
            break;
        case 'Pajamas':
            contentContexts.push(createClothingContextInstruction("Characters MUST be wearing appropriate pajamas or sleepwear."));
            break;
        case 'Kimono':
            contentContexts.push(createClothingContextInstruction("Characters MUST be wearing traditional Japanese kimonos."));
            break;
        case 'Summer Clothes':
            contentContexts.push(createClothingContextInstruction("Characters MUST be wearing modern, light summer clothing suitable for warm weather (e.g., shorts, t-shirts, sundresses)."));
            break;
        case 'Adventure Gear':
            contentContexts.push(createClothingContextInstruction("Characters MUST be wearing practical adventure or exploration gear (e.g., hiking boots, cargo pants, durable jackets)."));
            break;
        case 'Camping Outfit':
            contentContexts.push(createClothingContextInstruction("Characters MUST be wearing appropriate and comfortable camping attire (e.g., flannel shirts, sturdy pants, vests)."));
            break;
        case 'Rain Gear':
            contentContexts.push(createClothingContextInstruction("Characters MUST be wearing raincoats, boots, or other rain protection."));
            break;
        case 'Winter Clothes':
            contentContexts.push(createClothingContextInstruction("Characters MUST be wearing heavy winter clothing like coats, scarves, and hats."));
            break;
        case 'One-Piece Swimsuit':
            contentContexts.push(createClothingContextInstruction("The setting involves swimwear. Characters present MUST be dressed in one-piece swimsuits."));
            break;
        case 'Two-Piece Swimsuit':
            contentContexts.push(createClothingContextInstruction("The setting involves swimwear. Characters present MUST be dressed in two-piece swimsuits (bikinis)."));
            break;
        case 'Tropical Beachwear':
            contentContexts.push(createClothingContextInstruction("Characters MUST be dressed in tropical-style beachwear (e.g., Hawaiian shirts, sarongs, shorts)."));
            break;
        case 'Yukata':
            contentContexts.push(createClothingContextInstruction("Characters MUST be wearing traditional Japanese yukatas, which are lighter and more casual than kimonos, often worn at summer festivals."));
            break;
        case 'Sports Uniform':
            contentContexts.push(createClothingContextInstruction("Characters MUST be wearing specific sports uniforms (e.g., for soccer, baseball, basketball). The uniform should match the sport relevant to the scene."));
            break;
        case 'Christmas Outfit':
            contentContexts.push(createClothingContextInstruction("Characters MUST be wearing festive Christmas-themed clothing (e.g., Santa hats, ugly sweaters)."));
            break;
        case 'Travel Outfit':
            contentContexts.push(createClothingContextInstruction("Characters MUST be wearing practical and comfortable travel clothes suitable for a journey (e.g., comfortable pants, layered tops, sturdy shoes, perhaps a backpack or travel bag)."));
            break;
        case 'Party Outfit':
            contentContexts.push(createClothingContextInstruction("Characters MUST be wearing festive party clothes, such as dresses, suits, or other celebratory attire suitable for the event's formality."));
            break;
    }
    
    const contextInstruction = contentContexts.length > 0 ? `SPECIAL CONTEXT:\n- ${contentContexts.join('\n- ')}\n\n` : '';

    let atmosphereInstruction = '';
    const atmosphereContext = panelConfig.atmosphere;
    const currentGenre = appState.genre;
    const isBW = !appState.isColor;

    if (atmosphereContext && atmosphereContext !== 'Automatic' && atmosphereContext !== 'None') {
        let specificInstruction = '';
        switch (atmosphereContext) {
            case 'Tension':
                specificInstruction = 'The atmosphere is one of extreme TENSION. The environment must reflect this with dark, heavy, and charged tones, using shadows and claustrophobic framing to reinforce a sense of imminent danger or psychological distress.';
                if (isBW) specificInstruction += ' For black and white, emphasize this with dense cross-hatching, dramatic shadows, and tilted \'Dutch\' angles.';
                break;
            case 'Chaos':
                if (currentGenre === 'Superhero' || currentGenre === 'Mecha') {
                    specificInstruction = 'The atmosphere is utter CHAOS. The environment must reflect epic-scale destruction appropriate for a battle between super-powered beings. Show ruined buildings, widespread debris, smoke-filled air, and craters. Any background characters must be shown in a state of panic, fleeing for their lives. The devastation is widespread and immense.';
                } else { // Action, Martial Arts
                    specificInstruction = 'The atmosphere is CHAOS. The environment must show signs of destruction and disorder from the ongoing fight. Include visible damage to the surroundings, like cracked walls, shattered windows, scattered debris, and some smoke. Any background characters must be shown in a state of panic, fleeing the scene. The scale of destruction is contained and plausible for the setting.';
                }
                if (isBW) specificInstruction += ' For black and white, use heavy, impactful black areas, strong action lines, and high-contrast debris.';
                break;
            case 'Romantic':
                specificInstruction = 'The atmosphere is ROMANTIC. Use soft lighting (like golden hour or moonlight), a gentle focus, and an environment that enhances feelings of intimacy and affection. Consider elements like flowers, a beautiful sunset, or a cozy setting.';
                if (isBW) specificInstruction += ' For black and white, achieve this with soft, clean lines, close-ups on expressions, and using screen tones for gentle background textures like sparkles, flowers, or bubbles on empty or simple backgrounds.';
                break;
            case 'Peaceful':
                specificInstruction = 'The atmosphere is PEACEFUL and serene. The scene should be calm and tranquil. Use gentle lighting, stable compositions, and a quiet setting (e.g., a sunlit field, a calm library, a quiet morning).';
                if (isBW) specificInstruction += ' For black and white, this translates to clean lines, balanced compositions, and less heavy use of solid blacks.';
                break;
            case 'Mysterious':
                specificInstruction = 'The atmosphere is MYSTERIOUS. Use fog, shadows, obscured details, and a muted color palette (if in color) to create a sense of intrigue, secrecy, or the unknown. The environment should feel like it holds secrets.';
                if (isBW) specificInstruction += ' For black and white, use heavy shadows, partial silhouettes, and elements that obscure the view like fog or darkness to enhance the mystery.';
                break;
            case 'Somber':
                specificInstruction = 'The atmosphere is SOMBER and melancholic. Use subdued lighting (like an overcast day), a desaturated color palette (if in color), and imagery that conveys sadness, loss, or quiet reflection (e.g., rain, empty spaces).';
                if (isBW) specificInstruction += ' For black and white, convey this with stark compositions, large areas of empty white space, fine-line details like rain, and characters with distant or downcast expressions.';
                break;
            case 'Energetic':
                specificInstruction = 'The atmosphere is ENERGETIC and vibrant. The scene should feel full of life, motion, and excitement. Use dynamic angles, bright lighting, and a setting bustling with activity (e.g., a festival, a packed stadium, a busy street).';
                if (isBW) specificInstruction += ' For black and white, use bold speed lines, dynamic compositions, and high-contrast artwork to create a sense of motion and excitement.';
                break;
            case 'Dark':
                specificInstruction = 'The atmosphere is DARK and oppressive, in the style of a thriller or horror manga. Use heavy, dramatic shadows, dense cross-hatching, and partial silhouettes to create a sense of dread or evil.';
                if (isBW) specificInstruction += ' Emphasize this with tilted \'Dutch\' angles and a high-contrast, gritty style.';
                break;
            case 'Playful':
                specificInstruction = 'The atmosphere is PLAYFUL and lighthearted. The art style should be more loose and exaggerated, with a fun, comedic tone.';
                if (isBW) specificInstruction += ' Use caricatured distortion of faces, loose, expressive lines, and simplified backgrounds with fun symbols like stars or spirals.';
                break;
            case 'Epic':
                specificInstruction = 'The atmosphere is EPIC and grand in scale. The composition must convey a sense of awe and magnitude. Use sweeping, detailed scenarios, strong dynamic motion lines and framing that makes the subjects look powerful.';
                if (isBW) specificInstruction += ' Emphasize this with large or wide panels and low-angle shots to enhance the scale.';
                break;
            case 'Intimate':
                specificInstruction = 'The atmosphere is INTIMATE and personal, focusing on subtle emotions. The scene should be quiet and suggest a close connection or private moment.';
                if (isBW) specificInstruction += ' Achieve this with tight close-ups on eyes or hands, delicate, fine line work, and suggesting silence with empty or minimalist backgrounds.';
                break;
        }
        if (specificInstruction) {
            atmosphereInstruction = `ATMOSPHERE DIRECTIVE:\n- ${specificInstruction}\n\n`;
        }
    }

    let panelSpecifics = '';
    if (panelConfig.noDialogue) panelSpecifics += 'This panel must NOT contain any dialogue balloons, speech bubbles, or narration boxes.\n';
    if (panelConfig.noOnomatopoeia) panelSpecifics += 'This panel must NOT contain any onomatopoeia or sound effects.\n';
    if (panelConfig.removeAccessories) panelSpecifics += 'CRITICAL DIRECTIVE: Characters in this panel MUST NOT wear any accessories. This includes hair ties, ribbons, earrings, necklaces, bracelets, rings, glasses, hats, etc. Ensure characters appear without these items.\n';
    if (panelConfig.excludedCharacters && panelConfig.excludedCharacters.length > 0) {
        panelSpecifics += `The following characters MUST NOT appear in this panel: ${panelConfig.excludedCharacters.join(', ')}.\n`;
    }
    
    if (panelConfig.detailLevel !== 'Automatic') {
        panelSpecifics += `The level of detail in the artwork for this panel should be ${panelConfig.detailLevel}.\n`;
    }
    if (panelConfig.characterAngle !== 'Automatic') {
        panelSpecifics += `The main characters in this scene should be viewed from this perspective: ${panelConfig.characterAngle}.\n`;
    }
    
    const extrasInstruction = {
        'Automatic': 'Decide the appropriate number of extras for the scene.',
        'None': 'Do not include any extras or random bystanders. Only show characters mentioned in the scene description.',
        'A few (1-3)': 'Include a few background characters (1-3 people).',
        'A small crowd (4-10)': 'Include a small crowd of background characters (4-10 people).'
    }[panelConfig.extrasCount];
    panelSpecifics += `Regarding background characters (extras): ${extrasInstruction}\n`;
    
    const panelSizeInstruction = {
        'Automatic': 'Choose the most dramatic and emotionally fitting panel shape and aspect ratio for the scene.',
        'Standard': 'Draw this panel with a standard vertical manga panel aspect ratio, approximately 1:1.4 (taller than it is wide, like a B6 or A5 paper size).',
        'Tall': 'Draw this panel with a very tall and narrow aspect ratio, much taller than a standard panel (e.g., 1:2 or taller).',
        'Wide': 'Draw this panel with a wide, cinematic aspect ratio, much wider than it is tall (e.g., 2:1 or wider).',
        'Small Square': 'Draw this panel with a square aspect ratio (1:1).'
    }[panelConfig.panelSize];
    
    let scenarioInstruction = '';
    const masterConfig = appState.panelConfigs[0];
    const useMaster = appState.useGlobalScenario && index > 0;

    const scenarioImage = useMaster ? masterConfig?.scenarioImage : panelConfig.scenarioImage;
    const scenarioDescription = useMaster ? masterConfig?.scenarioDescription : panelConfig.scenarioDescription;
    const objectImages = panelConfig.objectImages || [];

    if (scenarioImage) {
        if (appState.maintainReferenceStyle) {
            scenarioInstruction = 'A scenario/background reference image is provided. The art style of the environment MUST strictly match the style of this reference image. However, you have creative freedom to EXPAND upon this environment. You can show different areas, angles, or extensions of the location shown in the reference image to avoid a static background, while maintaining the same architectural style, mood, and overall feel.';
        } else {
            scenarioInstruction = 'A scenario/background reference image is provided. The scene described MUST take place within this background. Integrate the characters and actions seamlessly into the provided scenario.';
        }
        if (objectImages.length > 0) {
            scenarioInstruction += ' Additionally, the scene MUST prominently feature the object(s) shown in the separate object reference image(s). Integrate them naturally into the environment.';
        }
    } else if (objectImages.length > 0) {
        scenarioInstruction = 'A specific background/scenario image has NOT been provided. Instead, one or more key objects are provided as images. You MUST create a plausible and fitting background scenario that justifies the presence of these important objects. The objects are central to the scene. You have creative freedom to expand the environment around them.';
        if (scenarioDescription) {
            scenarioInstruction += ` The user has provided this context for the environment: "${scenarioDescription}". Use this to guide your creation of the background.`;
        }
    } else if (scenarioDescription) {
        scenarioInstruction = `The scene takes place in this environment: "${scenarioDescription}".`;
    }

    let characterInstructions = '';
    if (allCharacters.length > 0) {
        let instructionsAdded = false;
        let tempInstructions = 'Character-Specific Instructions for this Panel:\n';
        
        allCharacters.forEach(char => {
            if (!char.name) return;
            const dialogue = panelConfig.characterDialogues?.[char.name];
            const behavior = panelConfig.characterBehaviors?.[char.name];
            const emotion = panelConfig.characterEmotions?.[char.name];
            const balloon = panelConfig.characterBalloons?.[char.name];

            if (dialogue || behavior || (emotion && emotion !== 'Automatic') || (balloon && balloon !== 'Automatic')) {
                tempInstructions += `- ${char.name}:`;
                if (behavior) {
                    tempInstructions += ` Behavior: "${behavior}".`;
                    instructionsAdded = true;
                }
                if (emotion && emotion !== 'Automatic') {
                    tempInstructions += ` Emotion: MUST be expressing "${emotion}".`;
                    instructionsAdded = true;
                }
                if (dialogue) {
                    tempInstructions += ` Dialogue: MUST say exactly "${dialogue}".`;
                    if (balloon && balloon !== 'Automatic') {
                        tempInstructions += ` Speech Balloon Style: Draw a "${balloon}"-style balloon. ('Shout' is spiky, 'Whisper' is dashed, 'Thought' is a cloud, 'Electronic' is square, 'Monstrous' is jagged, 'Flashback' is wavy, 'Narration Box' is a rectangle).`;
                    }
                    instructionsAdded = true;
                }
                tempInstructions += '\n';
            }
        });
        
        if (instructionsAdded) {
            characterInstructions = tempInstructions;
        }
    }

    let extrasBehaviorInstruction = '';
    if (panelConfig.extrasBehavior) {
        extrasBehaviorInstruction = `The background characters (extras) should behave in this manner: "${panelConfig.extrasBehavior}". If no extras are specified to be in the scene, this instruction can be ignored.`;
    }
    
    let appearanceMemoryInstruction = '';
    const appearanceMemoryCharacters = allCharacters
        .filter(char => char.name && appState.appearanceMemory[char.name]);

    if (appearanceMemoryCharacters.length > 0) {
        appearanceMemoryInstruction = `\n--- CRITICAL APPEARANCE DIRECTIVES ---\n`;
        appearanceMemoryCharacters.forEach(char => {
            appearanceMemoryInstruction += `For character '${char.name}', their clothing, accessories, and overall appearance MUST perfectly match their appearance in the corresponding "Appearance Memory" image provided. This directive is absolute and overrides all other clothing descriptions for this character.\n`;
        });
        appearanceMemoryInstruction += `--- END DIRECTIVES ---\n`;
    }

    let clothingReferenceInstruction = '';
    const clothingReferenceCharacters = allCharacters
        .filter(char => char.name && char.clothingReference);

    if (clothingReferenceCharacters.length > 0) {
        clothingReferenceInstruction = `\n--- CRITICAL CLOTHING DIRECTIVES ---\n`;
        clothingReferenceCharacters.forEach(char => {
            clothingReferenceInstruction += `For character '${char.name}', their clothing and accessories MUST perfectly match their appearance in the corresponding "Clothing Reference" image provided. This directive is absolute and overrides ALL other clothing descriptions for this character, including appearance memory and scene descriptions.\n`;
        });
        clothingReferenceInstruction += `--- END DIRECTIVES ---\n`;
    }


    const titleInstruction = (appState.displayTitleOnPanel && appState.comicTitle)
        ? `CRITICAL: The comic title "${appState.comicTitle}" MUST be written prominently and stylistically somewhere within the panel artwork, usually at the top. Do NOT write the genre name as text.`
        : 'CRITICAL: Do NOT write the comic title or genre name as text inside the panel artwork. They are for context only.';

    const fillPanelInstruction = appState.fillPanelCompletely
        ? 'CRITICAL VISUAL REQUIREMENT: The artwork MUST fill the entire image canvas from edge to edge. There must be absolutely NO white borders, padding, or framing around the image. The image must be "full bleed".'
        : '';

    const framingInstruction = panelConfig.framing !== 'Automatic'
        ? `- This panel must be an "${panelConfig.framing}" shot.`
        : '- Choose the most dramatic and fitting camera shot (e.g., Close-up, Wide Shot) for the scene.';

    const prompt = `
${atmosphereInstruction}
${contextInstruction}
${characterInfo}
${appearanceMemoryInstruction}
${clothingReferenceInstruction}
Overall Comic Title (for context): "${appState.comicTitle}"
Overall Comic Genre (for context): "${appState.genre}"

Generate a single, high-quality comic panel.
${colorInstruction}
Generate the panel ${comicStyleInstruction}
${styleInstruction}
${languageInstruction}
${scenarioInstruction ? scenarioInstruction + '\n' : ''}
${titleInstruction}
${fillPanelInstruction}

This is Panel ${index + 1} of ${appState.numPanels} for the page.

Panel Shape and Framing:
- ${panelSizeInstruction}
${framingInstruction}

Scene description for this panel:
${panelConfig.prompt}

${characterInstructions}
${extrasBehaviorInstruction ? extrasBehaviorInstruction + '\n' : ''}
${panelSpecifics ? 'Additional rules for this specific panel:\n' + panelSpecifics : ''}
`;
    const referenceImageParts = appState.referenceImages.map(img => dataUrlToPart(img.dataUrl, img.mimeType));
    const scenarioImagePart = scenarioImage ? [dataUrlToPart(scenarioImage.dataUrl, scenarioImage.mimeType)] : [];
    const objectImageParts = objectImages.map(img => dataUrlToPart(img.dataUrl, img.mimeType));
    
    const appearanceMemoryParts = appearanceMemoryCharacters
        .map(char => appState.appearanceMemory[char.name!])
        .filter((panel): panel is PanelOutput => panel !== null && panel !== undefined)
        .map(panel => dataUrlToPart(panel.url, panel.mimeType));
    
    const clothingReferenceParts = clothingReferenceCharacters
        .map(char => char.clothingReference)
        .filter((ref): ref is ImageData => ref !== undefined)
        .map(ref => dataUrlToPart(ref.dataUrl, ref.mimeType));

    const parts: any[] = [
        { text: prompt },
        ...referenceImageParts,
        ...scenarioImagePart,
        ...objectImageParts,
        ...appearanceMemoryParts,
        ...clothingReferenceParts,
    ];

    return { parts };
};

const callImageGenerationApi = async (parts: any[], panelIndex: number): Promise<{ url: string, mimeType: string }[]> => {
    const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image-preview',
        contents: { parts },
        config: {
            responseModalities: [Modality.IMAGE, Modality.TEXT],
        },
    });

    const candidate = response.candidates?.[0];

    if (!candidate || !candidate.content || !candidate.content.parts) {
        const blockReason = response.promptFeedback?.blockReason;
        let errorMessage = `API response for panel ${panelIndex + 1} was blocked or empty.`;
        if (blockReason) {
            errorMessage += ` Reason: ${blockReason}.`;
        }
        const textResponse = response.text?.trim();
        if(textResponse) {
            errorMessage += `\nAI Response: ${textResponse}`;
        }
        console.error(errorMessage, response);
        throw new Error(errorMessage);
    }

    const imageParts = candidate.content.parts
        .filter(part => part.inlineData)
        .map(part => ({
            url: part.inlineData!.data,
            mimeType: part.inlineData!.mimeType
        }));

    if (imageParts.length === 0) {
        const textResponse = response.text?.trim();
        let errorMessage = `API did not return an image for panel ${panelIndex + 1}.`;
        if(textResponse) {
            errorMessage += `\nAI Response: ${textResponse}`;
        }
        throw new Error(errorMessage);
    }
    return imageParts;
};

export const generateMangaPage = async (
    appState: AppState,
    onProgress: (panelIndex: number) => void
): Promise<{ url: string, mimeType: string }[][]> => {
    const pagePromises = appState.panelConfigs.map(async (panelConfig, index) => {
        onProgress(index);
        const { parts } = buildPanelPayload(appState, panelConfig, index);
        return callImageGenerationApi(parts, index);
    });

    return Promise.all(pagePromises);
};

export const generateSinglePanel = async (
    appState: AppState,
    panelConfig: PanelConfig,
    panelIndex: number
): Promise<{ url: string, mimeType: string }[]> => {
    // FIX: Changed 'index' to 'panelIndex' to match the function parameter name.
    const { parts } = buildPanelPayload(appState, panelConfig, panelIndex);
    return callImageGenerationApi(parts, panelIndex);
};


export const correctPanelText = async (
    base64ImageData: string,
    mimeType: string,
    correction: CorrectionPayload
): Promise<{ url: string, mimeType: string }> => {
    let prompt: string;

    if (correction.mode === 'suggestion') {
        prompt = `
You are an expert manga in-painter.
Your task is to correct or replace the text in the provided manga panel.
The user will provide the corrected/new text. You must replace all text in the image with this new text.

IMPORTANT RULES:
1.  ONLY change the text.
2.  The new text MUST perfectly match the font, style, size, and position of the original text.
3.  The art style of the rest of the panel must be preserved exactly. Do not alter the artwork.
4.  The output must be a single image in the same black and white manga style.
5.  If the text is in Portuguese, pay extremely close attention to correct Brazilian Portuguese orthography, including all accents and diacritics (e.g., á, ç, ã, ê).

New Text: "${correction.text}"
`;
    } else { // delete mode
        if (correction.deleteBalloons) {
            prompt = `
You are an expert manga in-painter.
Your task is to completely remove specific text AND its containing speech balloon/narration box from the provided manga panel.

IMPORTANT RULES:
1.  Find and completely delete the following text: "${correction.text}".
2.  Also, completely delete the speech balloon or narration box that contains this text.
3.  After removing the text and balloon/box, seamlessly inpaint the background area. The final image should look as if the text and its container were never there.
4.  ONLY remove the specified text and its direct container. All other text, balloons, and artwork must remain untouched.
5.  The output must be a single image in the same black and white manga style.
`;
        } else {
            prompt = `
You are an expert manga in-painter.
Your task is to remove specific text from a speech balloon in the provided manga panel, but LEAVE THE BALLOON EMPTY.

IMPORTANT RULES:
1.  Find and completely delete the following text: "${correction.text}".
2.  The speech balloon or narration box that contained the text MUST remain in the image, completely empty. Do NOT remove the balloon.
3.  Seamlessly inpaint the interior of the balloon so it appears blank.
4.  ONLY remove the specified text. All other artwork (including the balloon itself) must remain untouched.
5.  The output must be a single image in the same black and white manga style.
`;
        }
    }

    const imagePart = {
        inlineData: {
            data: base64ImageData,
            mimeType: mimeType,
        },
    };

    const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image-preview',
        contents: {
            parts: [
                { text: prompt },
                imagePart,
            ],
        },
        config: {
            responseModalities: [Modality.IMAGE, Modality.TEXT],
        },
    });

    const candidate = response.candidates?.[0];

    if (!candidate || !candidate.content || !candidate.content.parts) {
        const blockReason = response.promptFeedback?.blockReason;
        let errorMessage = `Text correction failed. The API response was blocked or empty.`;
        if (blockReason) {
            errorMessage += ` Reason: ${blockReason}.`;
        }
        const textResponse = response.text?.trim();
        if(textResponse) {
            errorMessage += `\nAI Response: ${textResponse}`;
        }
        console.error(errorMessage, response);
        throw new Error(errorMessage);
    }

    const imagePartOutput = candidate.content.parts.find(part => part.inlineData);

    if (!imagePartOutput || !imagePartOutput.inlineData) {
        const textResponse = response.text?.trim();
        let errorMessage = 'API did not return a corrected image.';
        if(textResponse) {
           errorMessage += `\nAI Response: ${textResponse}`;
        }
        throw new Error(errorMessage);
    }


    return {
        url: imagePartOutput.inlineData.data,
        mimeType: imagePartOutput.inlineData.mimeType,
    };
};

export const analyzeAndCorrectInconsistency = async (
    base64ImageData: string,
    mimeType: string
): Promise<{ url: string, mimeType: string }> => {
    const prompt = `
You are an expert comic book quality assurance AI. Your task is to meticulously analyze the provided image for any inconsistencies and errors, and then regenerate it with the flaws corrected.

**Analysis Checklist (in order of priority):**

1.  **Instruction Adherence:** Does the panel accurately reflect all user-provided instructions (character presence, actions, expressions, clothing, background)?
2.  **Anatomy & Deformities:** Are there any anatomical errors, distortions, or deformities (e.g., extra limbs, incorrect proportions, strange facial features)?
3.  **Character Proportions:** Are characters depicted with consistent and appropriate heights? Is there any unnecessary gigantism or incorrect scaling between characters?
4.  **Object & Scenery Logic:** Are objects positioned correctly within the scene's context (e.g., a TV is facing the viewer, reflections are accurate)? Is the proportion of objects relative to characters and the environment correct?
5.  **Text & Dialogue:** Is any text in the panel well-written, free of typos, and grammatically correct?
6.  **Speech Balloons:** Are speech balloons drawn correctly, matching the style requested by the user (e.g., spiky for shouting, cloud for thought)?
7.  **Behavior & Expressions:** Do the facial expressions and body language of characters and extras match the requested emotions and behaviors?
8.  **General Strangeness:** Are there any other bizarre, out-of-place, or strange alterations that deviate from a professional comic book standard?

**Your Task:**

-   **Analyze:** Perform a rigorous check against the list above.
-   **Correct:** If you identify ANY problem, your primary goal is to **FIX it**. Regenerate the image to correct all identified flaws.
-   **Preserve:** While correcting, you MUST preserve the original characters, art style, composition, and overall intent of the scene as closely as possible. The correction should be seamless.

The output MUST be a single, corrected image. Do not describe the changes you made; just provide the finished, corrected panel.
`;

    const imagePart = {
        inlineData: {
            data: base64ImageData,
            mimeType: mimeType,
        },
    };

    const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image-preview',
        contents: {
            parts: [
                { text: prompt },
                imagePart,
            ],
        },
        config: {
            responseModalities: [Modality.IMAGE, Modality.TEXT],
        },
    });

    const candidate = response.candidates?.[0];

    if (!candidate || !candidate.content || !candidate.content.parts) {
        const blockReason = response.promptFeedback?.blockReason;
        let errorMessage = `Inconsistency analysis failed. The API response was blocked or empty.`;
        if (blockReason) {
            errorMessage += ` Reason: ${blockReason}.`;
        }
        const textResponse = response.text?.trim();
        if(textResponse) {
            errorMessage += `\nAI Response: ${textResponse}`;
        }
        console.error(errorMessage, response);
        throw new Error(errorMessage);
    }

    const imagePartOutput = candidate.content.parts.find(part => part.inlineData);

    if (!imagePartOutput || !imagePartOutput.inlineData) {
        const textResponse = response.text?.trim();
        let errorMessage = 'API did not return a corrected image after analysis.';
        if(textResponse) {
           errorMessage += `\nAI Response: ${textResponse}`;
        }
        throw new Error(errorMessage);
    }

    return {
        url: imagePartOutput.inlineData.data,
        mimeType: imagePartOutput.inlineData.mimeType,
    };
};

export const editPanelWithText = async (
    base64ImageData: string,
    mimeType: string,
    editText: string
): Promise<{ url: string, mimeType: string }> => {
    const prompt = `
You are an expert comic book in-painter and editor. Your task is to execute the user's edit instruction with absolute precision. The user's request is a command, not a suggestion.

**CRITICAL RULES:**
1.  **Execute the Edit:** Apply the user's requested change directly and effectively. The edit is the most important part of this task.
2.  **Preserve Style:** The final image's art style, characters (unless instructed otherwise), and overall composition MUST be preserved. The change must be seamless and look natural within the panel.
3.  **Single Image Output:** The output must be a single image.
4.  **Language Context:** If the request is in Portuguese, ensure any added text or modified elements respect Brazilian Portuguese context.

User's Command: "${editText}"
`;

    const imagePart = {
        inlineData: {
            data: base64ImageData,
            mimeType: mimeType,
        },
    };

    const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image-preview',
        contents: {
            parts: [
                { text: prompt },
                imagePart,
            ],
        },
        config: {
            responseModalities: [Modality.IMAGE, Modality.TEXT],
        },
    });

    const candidate = response.candidates?.[0];

    if (!candidate || !candidate.content || !candidate.content.parts) {
        const blockReason = response.promptFeedback?.blockReason;
        let errorMessage = `Panel editing failed. The API response was blocked or empty.`;
        if (blockReason) {
            errorMessage += ` Reason: ${blockReason}.`;
        }
        const textResponse = response.text?.trim();
        if(textResponse) {
            errorMessage += `\nAI Response: ${textResponse}`;
        }
        console.error(errorMessage, response);
        throw new Error(errorMessage);
    }

    const imagePartOutput = candidate.content.parts.find(part => part.inlineData);

    if (!imagePartOutput || !imagePartOutput.inlineData) {
        const textResponse = response.text?.trim();
        let errorMessage = 'API did not return an edited image.';
        if(textResponse) {
           errorMessage += `\nAI Response: ${textResponse}`;
        }
        throw new Error(errorMessage);
    }

    return {
        url: imagePartOutput.inlineData.data,
        mimeType: imagePartOutput.inlineData.mimeType,
    };
};

export const extractTextFromPanel = async (base64ImageData: string, mimeType: string): Promise<string> => {
    const imagePart = {
        inlineData: {
            data: base64ImageData,
            mimeType: mimeType,
        },
    };
    const prompt = "Transcribe all text from this image. Return only the transcribed text, with no preamble or explanation.";

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [{ text: prompt }, imagePart] },
    });

    return response.text?.trim() || '';
};

export const getDialogueSuggestions = async (base64ImageData: string, mimeType: string, originalText: string): Promise<string[]> => {
    const imagePart = dataUrlToPart(`data:${mimeType};base64,${base64ImageData}`, mimeType);
    const prompt = `Analyze the context of the provided comic panel image and its original dialogue. The original dialogue is: "${originalText}".
Based on the visual context (character expressions, setting, action), generate exactly three creative, alternative lines of dialogue in Brazilian Portuguese. The suggestions should be more interesting, impactful, or fitting than the original.`;
    
    const response = await ai.models.generateContent({
        // FIX: Updated model name to align with API guidelines.
        model: 'gemini-2.5-flash',
        contents: { parts: [{ text: prompt }, imagePart] },
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    suggestions: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING }
                    }
                }
            }
        }
    });

    try {
        const json = JSON.parse(response.text);
        return json.suggestions || [];
    } catch (e) {
        console.error("Failed to parse dialogue suggestions JSON:", e);
        return [];
    }
};


export const getSpellingCorrections = async (base64ImageData: string, mimeType: string, originalText: string): Promise<string[]> => {
    const imagePart = dataUrlToPart(`data:${mimeType};base64,${base64ImageData}`, mimeType);
    const prompt = `Analyze the following text from a comic panel and identify any spelling or grammatical errors. The text is in Brazilian Portuguese. The text is: "${originalText}".
Provide up to three corrected versions of the text. If there are no errors, just return the original text.`;

    const response = await ai.models.generateContent({
        // FIX: Updated model name to align with API guidelines.
        model: 'gemini-2.5-flash',
        contents: { parts: [{ text: prompt }, imagePart] },
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    corrections: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING }
                    }
                }
            }
        }
    });

    try {
        const json = JSON.parse(response.text);
        return json.corrections || [];
    } catch (e) {
        console.error("Failed to parse spelling corrections JSON:", e);
        return [];
    }
};

export const describeCharacterAppearance = async (base64ImageData: string, mimeType: string): Promise<string> => {
    const imagePart = {
        inlineData: {
            data: base64ImageData,
            mimeType: mimeType,
        },
    };
    const prompt = `Descreva detalhadamente a aparência do personagem nesta imagem, se houver um. Comece com as características físicas (cabelo, olhos, tipo de corpo, características faciais) e depois descreva as roupas e acessórios em detalhes. Se não houver um personagem claro, indique isso. O resultado deve ser apenas a descrição. Não use formatação de negrito.`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [{ text: prompt }, imagePart] },
    });

    const text = response.text?.trim();
    if (!text) {
        const blockReason = response.promptFeedback?.blockReason;
        if (blockReason) {
            throw new Error(`A IA bloqueou a resposta. Motivo: ${blockReason}`);
        }
        throw new Error("A IA não retornou uma descrição.");
    }

    return text;
};

export const describeClothing = async (base64ImageData: string, mimeType: string): Promise<string> => {
    const imagePart = {
        inlineData: {
            data: base64ImageData,
            mimeType: mimeType,
        },
    };
    const prompt = `Descreva em detalhes apenas as roupas e acessórios usados pelo personagem nesta imagem. Ignore as características físicas do personagem. Se a imagem mostrar apenas roupas sem uma pessoa, descreva as peças de roupa. O resultado deve ser apenas a descrição, em português. Não use formatação de negrito.`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [{ text: prompt }, imagePart] },
    });

    const text = response.text?.trim();
    if (!text) {
        const blockReason = response.promptFeedback?.blockReason;
        if (blockReason) {
            throw new Error(`A IA bloqueou a resposta. Motivo: ${blockReason}`);
        }
        throw new Error("A IA não retornou uma descrição.");
    }

    return text;
};

export const describeScenarioOrObject = async (base64ImageData: string, mimeType: string): Promise<string> => {
    const imagePart = {
        inlineData: {
            data: base64ImageData,
            mimeType: mimeType,
        },
    };
    const prompt = `Descreva esta imagem em detalhes. Se for um objeto, foque em seus atributos (forma, cor, textura, função aparente). Se for um cenário, descreva o ambiente, a atmosfera e os elementos presentes. O resultado deve ser apenas a descrição, em português. Não use formatação de negrito.`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [{ text: prompt }, imagePart] },
    });

    const text = response.text?.trim();
    if (!text) {
        const blockReason = response.promptFeedback?.blockReason;
        if (blockReason) {
            throw new Error(`A IA bloqueou a resposta. Motivo: ${blockReason}`);
        }
        throw new Error("A IA não retornou uma descrição.");
    }

    return text;
};

export const classifyImageContent = async (base64ImageData: string, mimeType: string): Promise<'CHARACTER' | 'SCENARIO' | 'OBJECT' | 'UNKNOWN'> => {
    const imagePart = {
        inlineData: {
            data: base64ImageData,
            mimeType: mimeType,
        },
    };
    const prompt = `Analyze the provided image and classify its primary subject. Respond with ONLY one of the following keywords: 'CHARACTER', 'SCENARIO', or 'OBJECT'.
- 'CHARACTER': The main focus is a person, humanoid, or anthropomorphic creature.
- 'SCENARIO': The image is primarily a background, landscape, architectural interior/exterior, or environment.
- 'OBJECT': The main focus is a distinct, inanimate item (like a sword, a cup, a vehicle).
If the image is too ambiguous or contains a mix, prioritize the most prominent element. Your response must be a single word.`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [{ text: prompt }, imagePart] },
    });
    
    const text = response.text?.trim().toUpperCase();

    if (response.promptFeedback?.blockReason) {
        console.warn(`Image classification was blocked. Reason: ${response.promptFeedback.blockReason}`);
        return 'UNKNOWN';
    }
    
    if (text === 'CHARACTER' || text === 'SCENARIO' || text === 'OBJECT') {
        return text;
    }
    
    console.warn(`Unexpected classification from AI: ${text}`);
    return 'UNKNOWN';
};


// Helper Tasks
export const detailPrompt = async (text: string): Promise<string> => {
    if (!text.trim()) {
        return text;
    }
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Take the following manga scene description and expand upon it. Add more sensory details, character actions, and environmental descriptions to make it more vivid and compelling for an AI image generator. The output should be a single, cohesive paragraph. Original description: "${text}"`,
        config: {
            systemInstruction: 'You are a creative assistant that helps users write amazing scene descriptions for manga.'
        }
    });
    return response.text?.trim() || '';
};

export const detailExtrasBehavior = async (behaviorText: string, sceneContext: string): Promise<string> => {
    if (!behaviorText.trim()) {
        return behaviorText;
    }
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Given the main scene context, expand upon the following description for background characters (extras). Make their behavior more realistic and integrated with the scene. Add specific actions and reactions that fit the context. The output should be a single, cohesive paragraph. Main Scene Context: "${sceneContext}". Extras Behavior Description: "${behaviorText}"`,
        config: {
            systemInstruction: 'You are a creative assistant that helps writers flesh out the background details of their manga scenes.'
        }
    });
    return response.text?.trim() || '';
};

export const detailScenario = async (text: string): Promise<string> => {
    if (!text.trim()) {
        return text;
    }
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Take the following environment description and expand upon it. Add more sensory details, specific objects, and atmospheric elements to make it more vivid for an AI image generator. CRITICAL: Do NOT add any people, characters, or living beings. The focus must remain strictly on the inanimate environment. The output should be a single, cohesive paragraph. Original description: "${text}"`,
        config: {
            systemInstruction: 'You are a creative assistant that helps users write amazing environmental descriptions for manga, focusing only on the setting.'
        }
    });
    return response.text?.trim() || '';
};

export const detailCharacterDialogue = async (dialogue: string, personas: string[], sceneContext: string): Promise<string> => {
    if (!dialogue.trim()) {
        return dialogue;
    }
    const personaText = personas.filter(p => p.trim()).length > 0
        ? `The character has the following personas: ${personas.join(', ')}. The dialogue should reflect these traits.`
        : `The character has no defined personas, so you have creative freedom.`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Given the scene context and character personas, refine and improve the following line of dialogue to make it more impactful and in-character. The output should be only the improved dialogue, without quotes or preamble.
Scene Context: "${sceneContext}"
${personaText}
Original Dialogue: "${dialogue}"`,
        config: {
            systemInstruction: 'You are a dialogue writer for manga, skilled at making character speech compelling and natural.'
        }
    });
    const result = response.text?.trim() || '';
    // Remove quotes that the model might add
    return result.replace(/^"(.*)"$/, '$1');
};

export const detailCharacterBehavior = async (behavior: string, sceneContext:string): Promise<string> => {
    if (!behavior.trim()) {
        return behavior;
    }
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Given the scene context, expand upon the following character behavior description. Add more specific actions, gestures, and expressions to make it more vivid and compelling for an AI image generator. The output should be a single, cohesive paragraph.
Scene Context: "${sceneContext}"
Original Behavior: "${behavior}"`,
        config: {
            systemInstruction: 'You are a creative assistant that helps users write detailed character actions for manga scenes.'
        }
    });
    return response.text?.trim() || '';
};


export const translateText = async (text: string, characterNames: string[]): Promise<string> => {
    let prompt = `Translate the following text to English, even if it already appears to be in English.`;

    if (characterNames && characterNames.length > 0) {
        const namesString = characterNames.map(name => `"${name}"`).join(', ');
        prompt += ` IMPORTANT: The following proper names must NOT be translated and must be preserved exactly: ${namesString}.`;
    }

    prompt += ` Only return the translated text itself, with no preamble or explanation: "${text}"`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });
    return response.text?.trim() || '';
};

export const buildPrompt = async (keywords: string): Promise<string> => {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Based on these keywords, create a creative, well-structured, and detailed scene description for a manga page. The prompt should be a single, cohesive paragraph. Keywords: ${keywords}`,
        config: {
            systemInstruction: 'You are a creative assistant that helps users write amazing scene descriptions for manga.'
        }
    });
    return response.text?.trim() || '';
};