


export type CameraFraming = 
    'Automatic' |
    'Extreme Close-up' | 
    'Close-up' | 
    'Medium Shot' | 
    'Full Shot' | 
    'Wide Shot' | 
    'Establishing Shot' |
    'Dutch Angle' |
    'Over-the-Shoulder Shot' |
    'Point of View (POV)' |
    'Low-Angle Shot' |
    'High-Angle Shot' |
    'Worm\'s-eye View';

export interface ImageData {
    dataUrl: string;
    mimeType: string;
    id: string;
    name?: string;
    personas?: string[]; // Up to 3 personas
    clothingReference?: ImageData;
}

export interface TextCharacter {
    id: string;
    name: string;
    appearance: string;
    personas?: string[];
    clothingReference?: ImageData;
}

export type ContentContext = 
    | 'Automatic'
    | 'None' 
    | 'Intense Action/Battle' 
    | 'School Uniform'
    | 'Casual Wear'
    | 'Gym Clothes'
    | 'Mahou Shoujo Outfit'
    | 'Superhero Costume'
    | 'Pajamas'
    | 'Kimono'
    | 'Summer Clothes'
    | 'Adventure Gear'
    | 'Camping Outfit'
    | 'Rain Gear'
    | 'Winter Clothes'
    | 'One-Piece Swimsuit'
    | 'Two-Piece Swimsuit'
    | 'Tropical Beachwear'
    | 'Yukata'
    | 'Sports Uniform'
    | 'Christmas Outfit';


export type Atmosphere = 
    | 'Automatic'
    | 'None'
    | 'Tension'
    | 'Chaos'
    | 'Romantic'
    | 'Peaceful'
    | 'Mysterious'
    | 'Somber'
    | 'Energetic';

export type CharacterEmotion = 
    | 'Automatic'
    | 'Neutral'
    | 'Happy'
    | 'Joyful'
    | 'Sad'
    | 'Crying'
    | 'Angry'
    | 'Furious'
    | 'Surprised'
    | 'Shocked'
    | 'Scared'
    | 'Terrified'
    | 'Confused'
    | 'Determined'
    | 'Smirking'
    | 'Shy / Blushing'
    | 'Arrogant / Smug';

export type SpeechBalloonType = 
    | 'Automatic'
    | 'Normal'
    | 'Shout'
    | 'Whisper'
    | 'Thought'
    | 'Electronic'
    | 'Monstrous'
    | 'Flashback'
    | 'Narration Box';

export interface PanelConfig {
    prompt: string;
    framing: CameraFraming;
    contentContext: ContentContext;
    atmosphere: Atmosphere;
    scenarioImage?: ImageData;
    objectImages?: ImageData[];
    scenarioDescription?: string;
    characterDialogues?: { [characterName: string]: string };
    characterBehaviors?: { [characterName: string]: string };
    characterEmotions?: { [characterName: string]: CharacterEmotion };
    characterBalloons?: { [characterName: string]: SpeechBalloonType };
    extrasBehavior?: string;
    removeAccessories?: boolean;
    noDialogue?: boolean;
    noOnomatopoeia?: boolean;
    excludedCharacters?: string[]; // character names
    panelSize: 'Automatic' | 'Standard' | 'Tall' | 'Wide' | 'Small Square' | 'Split Horizontally' | 'Split Vertically';
    extrasCount: 'Automatic' | 'None' | 'A few (1-3)' | 'A small crowd (4-10)';
    detailLevel: 'Automatic' | 'Medium' | 'Low' | 'High';
    characterAngle: 'Automatic' | 'Front-facing' | 'From behind' | 'Side view';
}

export interface PanelOutput {
    url: string;
    mimeType: string;
}

export interface ArtistStyle {
    name: string;
    work: string;
}

export type CorrectionMode = 'suggestion' | 'correction' | 'delete';

export type CorrectionPayload = 
    | { mode: 'suggestion'; text: string; }
    | { mode: 'delete'; text: string; deleteBalloons?: boolean; };

export interface AppState {
    comicTitle: string;
    displayTitleOnPanel: boolean;
    artistStyle: string;
    maintainReferenceStyle: boolean;
    generateInPortuguese: boolean;
    referenceImages: ImageData[];
    textCharacters: TextCharacter[];
    characterDetailsEnabled: boolean;
    numPages: number;
    numPanels: number;
    panelConfigs: PanelConfig[];
    isLoading: boolean;
    loadingMessage: string;
    output: PanelOutput[][] | null;
    error: string | null;
    currentCreationId: number | null;
    isColor: boolean;
    comicStyle: 'Manga' | 'Mecha Manga' | 'Manhwa' | 'Manhua' | 'Webtoon' | 'American (Modern)' | 'American (Golden Age)' | 'American (Silver Age)' | 'American (Underground)' | 'Franco-Belgian' | 'European (Underground)' | 'Italian Fumetti' | 'Argentine Historietas' | 'Brazilian HQ' | 'Disney Style' | 'Indie/Alternative';
    genre: string;
    appearanceMemory: { [characterName: string]: PanelOutput | null };
    useGlobalScenario: boolean;
    fillPanelCompletely: boolean;
}

export interface Creation extends AppState {
    id?: number;
    timestamp: number;
    globalScenario?: string; // For backwards compatibility
    clothingMemory?: string; // For backwards compatibility
}