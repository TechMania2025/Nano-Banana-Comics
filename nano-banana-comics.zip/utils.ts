import { ImageData, PanelOutput } from './types';

export const fileToBase64 = (file: File): Promise<ImageData> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
            const dataUrl = reader.result as string;
            const id = `${file.name}-${file.lastModified}-${Math.random()}`;
            
            // Get filename without extension
            const fileName = file.name;
            const lastDotIndex = fileName.lastIndexOf(".");
            const name = lastDotIndex > 0 ? fileName.substring(0, lastDotIndex) : fileName;

            resolve({ dataUrl, mimeType: file.type, id, name });
        };
        reader.onerror = error => reject(error);
        reader.readAsDataURL(file);
    });
};


export const cropImageBorders = (panel: PanelOutput, threshold: number = 245): Promise<PanelOutput> => {
    return new Promise((resolve) => {
        const img = new Image();
        img.crossOrigin = "Anonymous";
        img.onload = () => {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d', { willReadFrequently: true });
            if (!ctx) return resolve(panel);

            canvas.width = img.width;
            canvas.height = img.height;
            ctx.drawImage(img, 0, 0);

            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const { data, width, height } = imageData;

            let top = 0, bottom = height, left = 0, right = width;

            // Helper function to check if a pixel is white-ish
            const isWhite = (index: number) => {
                return data[index] > threshold && data[index + 1] > threshold && data[index + 2] > threshold;
            };

            // Find top bond
            for (let y = 0; y < height; y++) {
                let allWhite = true;
                for (let x = 0; x < width; x++) {
                    if (!isWhite((y * width + x) * 4)) {
                        allWhite = false;
                        break;
                    }
                }
                if (!allWhite) {
                    top = y;
                    break;
                }
            }

            // Find bottom bond
            for (let y = height - 1; y >= 0; y--) {
                let allWhite = true;
                for (let x = 0; x < width; x++) {
                    if (!isWhite((y * width + x) * 4)) {
                        allWhite = false;
                        break;
                    }
                }
                if (!allWhite) {
                    bottom = y + 1;
                    break;
                }
            }

            // Find left bond
            for (let x = 0; x < width; x++) {
                let allWhite = true;
                for (let y = 0; y < height; y++) {
                    if (!isWhite((y * width + x) * 4)) {
                        allWhite = false;
                        break;
                    }
                }
                if (!allWhite) {
                    left = x;
                    break;
                }
            }

            // Find right bond
            for (let x = width - 1; x >= 0; x--) {
                let allWhite = true;
                for (let y = 0; y < height; y++) {
                    if (!isWhite((y * width + x) * 4)) {
                        allWhite = false;
                        break;
                    }
                }
                if (!allWhite) {
                    right = x + 1;
                    break;
                }
            }

            const cropWidth = right - left;
            const cropHeight = bottom - top;

            // If no cropping is needed, return original
            if (cropWidth === width && cropHeight === height) {
                return resolve(panel);
            }

            const cropCanvas = document.createElement('canvas');
            cropCanvas.width = cropWidth;
            cropCanvas.height = cropHeight;
            const cropCtx = cropCanvas.getContext('2d');
            if (!cropCtx) return resolve(panel);

            cropCtx.drawImage(canvas, left, top, cropWidth, cropHeight, 0, 0, cropWidth, cropHeight);
            
            const newUrl = cropCanvas.toDataURL(panel.mimeType);
            resolve({ ...panel, url: newUrl });
        };
        img.onerror = () => {
            // If there's an error loading the image, just return the original
            resolve(panel);
        };
        img.src = panel.url;
    });
};
